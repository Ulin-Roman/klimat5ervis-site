<?php
/** Shared presentation only. Native shop controllers, forms and AJAX handlers remain authoritative. */
if (!defined('HOSTCMS')) { http_response_code(404); exit; }

function klimat_unified_20261117_svg($name)
{
    $paths = array(
        'phone' => '<path d="M7 3h3l2 5-2 2c1 2 2 3 4 4l2-2 5 2v3c0 2-2 4-4 3C9 19 5 15 3 7 2 5 5 3 7 3Z"/>',
        'favorite' => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
        'cart' => '<path d="M2 3h3l3 13h11l3-9H6M9 21h.01M18 21h.01"/>',
        'search' => '<circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>'
    );
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . (isset($paths[$name]) ? $paths[$name] : '') . '</svg>';
}

function klimat_unified_20261117_fragment($kind)
{
    static $fragments = array();
    if (array_key_exists($kind, $fragments)) return $fragments[$kind];
    $baseLevel = ob_get_level();
    $html = '';
    try {
        if (Core::moduleIsActive('shop')) {
            ob_start();
            $shop = Core_Entity::factory('Shop', 1);
            if ($kind === 'favorite') {
                $controller = new Shop_Favorite_Controller_Show($shop);
                $controller->xsl(Core_Entity::factory('Xsl')->getByName('МагазинИзбранноеКраткоеСайт3'))
                    ->itemsPropertiesList(FALSE)->show();
            } elseif ($kind === 'cart') {
                $controller = new Shop_Cart_Controller_Show($shop);
                $controller->xsl(Core_Entity::factory('Xsl')->getByName('МагазинКорзинаКраткаяСайт3'))
                    ->couponText(isset($_SESSION) ? Core_Array::get($_SESSION, 'coupon_text') : '')->show();
            }
            $html = ob_get_clean();
        }
    } catch (Throwable $failure) {
        while (ob_get_level() > $baseLevel) ob_end_clean();
    }
    // Keep the existing native fragments: hostcms.js updates #little_cart with .html()
    // and replaces #little-favorite wholesale. Their surrounding slots remain stable.
    if ($kind === 'favorite') {
        if (trim($html) === '') $html = '<a class="header-favorite" href="/category/favorite/" aria-label="Избранное" title="Избранное">' . klimat_unified_20261117_svg('favorite') . '</a>';
        if (!preg_match('~\bid\s*=\s*([\x22\x27])little-favorite\1~i', $html)) $html = '<li id="little-favorite">' . $html . '</li>';
    } else {
        if (trim($html) === '') $html = '<a class="cart" href="/category/cart/" aria-label="Корзина" title="Корзина">' . klimat_unified_20261117_svg('cart') . '<span class="cart-label">Корзина</span></a>';
        $html = '<li id="little_cart">' . $html . '</li>';
    }
    $label = $kind === 'favorite' ? 'Избранное' : 'Корзина';
    $html = preg_replace('~<a\b(?![^>]*\baria-label=)~i', '<a aria-label="' . $label . '" title="' . $label . '"', $html, 1);
    $fragments[$kind] = $html;
    return $html;
}

function klimat_unified_20261117_header()
{
    $nav = array('/category/'=>'Каталог', '/company/'=>'О компании', '/delivery/'=>'Доставка и оплата', '/offers/'=>'Акции', '/blog/'=>'Блог', '/kontakty/'=>'Контакты');
    $path = (string) parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    $html = '<header class="header modern-shared-header ks-shell-header"><div class="ks-shell-wrap header-inner">'
        . '<a class="brand" href="/" aria-label="Климат-Сервис — главная"><img src="/assets/audit-20261116/22a35fd77b155587.webp" width="42" height="36" alt=""><span class="brand-copy">КЛИМАТ-СЕРВИС<small>Интернет-магазин</small></span></a>'
        . '<nav class="header-nav" id="ks-modern-menu" aria-label="Основная навигация">';
    foreach ($nav as $href => $label) {
        $active = $path === $href || ($href === '/category/' && strpos($path, '/category/') === 0 && strpos($path, '/category/cart/') !== 0 && strpos($path, '/category/favorite/') !== 0);
        $html .= '<a href="' . $href . '"' . ($active ? ' aria-current="page"' : '') . '>' . $label . '</a>';
    }
    $html .= '<a class="ks-shell-mobile-search" href="/search/">Поиск по товарам</a><a class="ks-shell-mobile-call callibri-phone" href="tel:+79054113948">Позвонить нам</a></nav><div class="header-tools">'
        . '<a class="ks-shell-search" href="/search/" aria-label="Поиск по товарам" title="Поиск по товарам">' . klimat_unified_20261117_svg('search') . '</a>'
        . '<a class="header-phone callibri-phone" href="tel:+79054113948" aria-label="Позвонить" title="Позвонить">' . klimat_unified_20261117_svg('phone') . '<span>+7 (905) 411-39-48</span></a>'
        . '<ul class="ks-shell-favorite-slot" aria-label="Избранное">' . klimat_unified_20261117_fragment('favorite') . '</ul>'
        . '<ul class="ks-shell-cart-slot" aria-label="Корзина">' . klimat_unified_20261117_fragment('cart') . '</ul>'
        . '<button class="header-menu-toggle" type="button" aria-label="Открыть меню" aria-expanded="false" aria-controls="ks-modern-menu">' . klimat_unified_20261117_svg('menu') . '</button></div></div></header>';
    return $html;
}

function klimat_unified_20261117_footer()
{
    $account = '';
    if (Core::moduleIsActive('siteuser')) {
        $loggedIn = !is_null(Core_Entity::factory('Siteuser')->getCurrent());
        $account = '<div class="ks-shell-account"><strong>Покупателю</strong><a href="/users/">Личный кабинет</a>'
            . ($loggedIn ? '<a href="/users/registration/">Мои данные</a><a href="/users/order/">Мои заказы</a><a href="/users/?action=exit">Выход</a>' : '<a href="/users/registration/">Регистрация</a>') . '</div>';
    }
    return '<footer class="ks-shell-footer"><div class="ks-shell-wrap"><div class="ks-shell-footer-grid">'
        . '<div class="ks-shell-footer-brand"><a class="brand" href="/"><img src="/assets/audit-20261116/22a35fd77b155587.webp" width="42" height="36" alt=""><span>КЛИМАТ-СЕРВИС<small>Интернет-магазин</small></span></a><p>Климатические решения для дома и бизнеса.<br>Москва и Московская область.</p><p>© 2005–' . date('Y') . ' «Климат-Сервис»</p></div>'
        . '<nav aria-label="Разделы магазина"><strong>Магазин</strong><a href="/category/">Каталог</a><a href="/offers/">Акции</a><a href="/delivery/">Доставка и оплата</a><a href="/return/">Возврат</a><a href="/category/favorite/">Избранное</a><a href="/category/cart/">Корзина</a></nav>'
        . '<nav aria-label="Информация"><strong>Информация</strong><a href="/company/">О компании</a><a href="/blog/">Блог</a><a href="/kontakty/">Контакты</a><a href="/politics/">Пользовательское соглашение</a><button class="ks-cookie-settings" type="button" data-cookie-open>О файлах cookie</button></nav>'
        . '<div class="ks-shell-footer-contact"><strong><a class="callibri-phone" href="tel:+79054113948">+7 (905) 411-39-48</a></strong><p>Москва, ул. Перовская, 20</p><a href="mailto:klimat5ervis@yandex.ru">klimat5ervis@yandex.ru</a><div class="ks-shell-messengers" role="group" aria-label="Мессенджеры"><a href="https://t.me/klimat5servis" aria-label="Написать в Telegram" title="Telegram"><img src="/assets/header-20261116/telegram.svg" width="36" height="36" alt="" loading="lazy"></a><a href="https://max.ru/u/f9LHodD0cOLjX0SKaPjyc-__Xtd96IrNpMNkx4pqxmQmNL8yuBC4ysq5LRg" aria-label="Написать в MAX" title="MAX"><img src="/assets/footer-20261116/max.webp" width="36" height="36" alt="" loading="lazy"></a></div>' . $account . '</div></div>'
        . '<div class="ks-shell-footer-bottom">Вся представленная на сайте информация о стоимости носит информационный характер и не является публичной офертой, определяемой положениями статьи 437 (2) Гражданского кодекса Российской Федерации.</div></div></footer>';
}

function klimat_unified_20261117_assets()
{
    return '<link rel="stylesheet" href="/assets/unified-shell-20261117/storefront-white.css?v=2"><script defer src="/assets/unified-shell-20261117/shared-header.js?v=2"></script><noscript><style>@media(max-width:1100px){.ks-shell-header.modern-shared-header .header-nav{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));position:static;grid-column:1/-1;grid-row:2;gap:4px 18px}.ks-shell-header.modern-shared-header .header-menu-toggle{display:none!important}}</style></noscript>';
}

function klimat_unified_20261117_html($html)
{
    $headers = 0;
    $footers = 0;
    $html = preg_replace_callback('~<header\b[^>]*>[\s\S]*?</header\s*>~i', static function ($match) use (&$headers) {
        $headers++;
        return $headers === 1 ? klimat_unified_20261117_header() : $match[0];
    }, $html, 1);
    $html = preg_replace_callback('~<footer\b[^>]*>[\s\S]*?</footer\s*>~i', static function ($match) use (&$footers) {
        $footers++;
        return $footers === 1 ? klimat_unified_20261117_footer() : $match[0];
    }, $html, 1);
    if ($headers !== 1 || $footers !== 1) throw new RuntimeException('Unified shell requires header and footer');
    $html = preg_replace('~<div\b[^>]*\bclass\s*=\s*([\x22\x27])production-footer-nav\s+wrap\1[^>]*>\s*<nav\b[^>]*>[\s\S]*?</nav>\s*</div>~i', '', $html, 1);
    return klimat_unified_20261117_finish($html);
}

/** One telephone identity and a single Callibri loader in both storefront branches. */
function klimat_unified_20261117_finish($html)
{
    // The unified head supplies the current controller before deferred body scripts.
    // Drop only the retired controller emitted by the older modern XSL templates.
    $html = preg_replace('~<script\b(?=[^>]*\bsrc\s*=\s*([\x22\x27])(?:https://klimat5ervis\.ru)?/assets/ui-finish-20261117/shared-header\.js(?:\?[^\x22\x27]*)?\1)[^>]*>[\s\S]*?</script\s*>~i', '', $html);
    // Stored article titles had been copied between posts; the visible article H1 is authoritative.
    $path = (string) parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    if ($path === '/category/cart/' && strpos($html, 'canonical-checkout.js?v=ui2') !== FALSE) {
        // The deferred head controller also initializes native checkout forms.
        $html = preg_replace('~<script\s+src="/assets/canonical-checkout-20261117/canonical-checkout\.js"(?:\s+defer(?:\s*=\s*"(?:defer)?")?)?\s*>\s*</script\s*>~i', '', $html);
    }
    if ($path === '/category/cart/' && strpos($html, 'Рубль') !== FALSE) {
        // HostCMS formats checkout totals with the currency sign but some older
        // cart templates append the currency name. Change only rendered text.
        $tokens = '~<!--[\s\S]*?-->|<(script|style|textarea|title)\b[^>]*>[\s\S]*?</\1\s*>|<(?:(?:"[^"]*")|(?:\x27[^\x27]*\x27)|[^\x27">])*+>|([^<]+)~i';
        $formatted = preg_replace_callback($tokens, static function ($match) {
            if (!isset($match[2])) return $match[0];
            return preg_replace('~(?<=\d)(?:[ \t\x{00A0}\x{202F}]|&nbsp;|&#160;)+Рубль(?![\p{L}\p{N}])~u', ' ₽', $match[2]) ?? $match[2];
        }, $html);
        if (is_string($formatted)) $html = $formatted;
    }
    if (preg_match('~^/category/(?:[^/]+/)+[0-9]+/$~', $path)) {
        // The import includes CMS metadata among customer specifications. Remove
        // only these exact flat property rows; product/gallery data stays intact.
        $hiddenProperties = array('Статус', 'Выбор вариантов товара', 'Тип товаров', 'Ссылка на витрину', 'ID товара', 'Изображения товаров');
        $html = preg_replace_callback('~<div\s+class="shop_property">([^<]*)<span>(?:(?!</?div\b)[\s\S])*?</span>\s*</div>~i', static function ($match) use ($hiddenProperties) {
            $label = html_entity_decode($match[1], ENT_QUOTES, 'UTF-8');
            $label = trim(str_replace("\xC2\xA0", ' ', $label), " \t\n\r\0\x0B:");
            return in_array($label, $hiddenProperties, TRUE) ? '' : $match[0];
        }, $html);
        // Correct the known copied shop name in text only, keeping tags, inline
        // handlers, scripts, style and textarea contents opaque.
        $parts = preg_split('~(<script\b[^>]*>[\s\S]*?</script\s*>|<style\b[^>]*>[\s\S]*?</style\s*>|<textarea\b[^>]*>[\s\S]*?</textarea\s*>|<!--[\s\S]*?-->|<[^>]*>)~i', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
        if (is_array($parts)) {
            foreach ($parts as $index => $part) {
                if ($part !== '' && $part[0] !== '<') {
                    $parts[$index] = preg_replace('~в(?:\s|\x{00A0}|&nbsp;)+магазине(?:\s|\x{00A0}|&nbsp;)+PRO(?:\s|\x{00A0}|&nbsp;)*Комфорт~u', 'в магазине «Климат-Сервис»', $part);
                }
            }
            $html = implode('', $parts);
        }
    }
    if (strpos($path, '/blog/') === 0 && preg_match('~<h1\b[^>]*>([\s\S]*?)</h1>~i', $html, $heading)) {
        $name = trim(html_entity_decode(strip_tags($heading[1]), ENT_QUOTES, 'UTF-8'));
        if ($name !== '') {
            $title = htmlspecialchars($name . ' | Блог Климат-Сервис', ENT_QUOTES, 'UTF-8');
            $html = preg_replace_callback('~<title\b[^>]*>[\s\S]*?</title>~i', static function ($match) use ($title) { return '<title>' . $title . '</title>'; }, $html, 1);
            $html = preg_replace_callback('~<meta\b[^>]*\bproperty="og:title"[^>]*>~i', static function ($match) use ($title) {
                return '<meta property="og:title" content="' . $title . '">';
            }, $html, 1);
        }
    }

    $html = str_replace(array('href="tel:89054113948"', 'href="tel:79054113948"'), 'href="tel:+79054113948"', $html);
    $html = preg_replace_callback('~<a\b[^>]*\bhref="tel:\+79054113948"[^>]*>~i', static function ($match) {
        $tag = $match[0];
        if (strpos($tag, 'callibri-phone') !== FALSE) return $tag;
        if (preg_match('~\bclass="([^"]*)"~', $tag)) return preg_replace('~\bclass="([^"]*)"~', 'class="$1 callibri-phone"', $tag, 1);
        return str_replace('<a ', '<a class="callibri-phone" ', $tag);
    }, $html);
    if (!preg_match('~<script\b[^>]*\bsrc=[\x22\x27](?:https?:)?//cdn\.callibri\.ru/callibri\.js~i', $html)) {
        $html = preg_replace('~</body\s*>~i', klimat_unified_20261117_tracking() . '</body>', $html, 1);
    }
    // Keep the native shop usable if the optional product presentation is absent.
    if (preg_match('~^/category/(?:[^/]+/)*[0-9]+/$~D', $path)
        && strpos($html, 'product-card') !== FALSE && strpos($html, 'product-tabs') !== FALSE) {
        $productUi = dirname(__DIR__) . '/product-cards-20261117/product-card-finish.php';
        if (is_file($productUi)) {
            try {
                require_once $productUi;
                $productHtml = klimat_product_cards_20261117_finish($html, $path);
                if ($productHtml !== $html) {
                    $html = str_ireplace('</head>', '<link rel="stylesheet" href="/assets/product-cards-20261117/product-cards-white.css?v=6"></head>', $productHtml);
                    $html = str_ireplace('</body>', '<script defer src="/assets/product-cards-20261117/product-cards-v5.js?v=2"></script></body>', $html);
                }
            } catch (Throwable $productUiError) {
                // The original product view is still available.
            }
        }
    }
    require_once __DIR__ . '/technical-seo-finish.php';
    require_once __DIR__ . '/technical-images.php';
    $html = klimat_technical_images_20261117_html(technical_seo_finish($html, $path));
    $catalogPhotos = __DIR__ . '/catalog-photo-delivery.php';
    if (is_file($catalogPhotos)) {
        require_once $catalogPhotos;
        $html = klimat_catalog_photo_delivery_20261117_html($html, $path);
    }
    $curatedCovers = __DIR__ . '/catalog-curated-covers.php';
    $productUi = dirname(__DIR__) . '/product-cards-20261117/product-card-finish.php';
    if ((strpos($html, 'product-image') !== FALSE || strpos($html, 'mh-feature-image') !== FALSE || strpos($path, '/search/') === 0)
        && is_file($curatedCovers) && is_file($productUi)) {
        require_once $productUi;
        require_once $curatedCovers;
        $html = klimat_catalog_curated_covers_20261117_html($html, $path);
    }
    return $html;
}
function klimat_unified_20261117_tracking()
{
    return '<script src="https://cdn.callibri.ru/callibri.js" type="text/javascript" charset="utf-8" defer></script>';
}
