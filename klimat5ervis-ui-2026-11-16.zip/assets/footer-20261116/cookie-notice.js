(function(){
  'use strict';
  var notice=document.getElementById('ks-cookie-notice');
  if(!notice)return;
  var key='ks-cookie-notice-v1', dismissed=false, returnFocus=null;
  try{dismissed=Number(localStorage.getItem(key))>Date.now();}catch(e){}
  notice.hidden=dismissed;
  var close=notice.querySelector('[data-cookie-dismiss]');
  close.addEventListener('click',function(){
    try{localStorage.setItem(key,String(Date.now()+31536000000));}catch(e){}
    notice.hidden=true;
    if(returnFocus){returnFocus.focus();returnFocus=null;}
  });
  document.querySelectorAll('[data-cookie-open]').forEach(function(button){
    button.addEventListener('click',function(){returnFocus=button;notice.hidden=false;close.focus();});
  });
  var toggle=notice.querySelector('.ks-cookie-details-toggle'),details=document.getElementById('ks-cookie-details');
  toggle.addEventListener('click',function(){var open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));details.hidden=!open;});
})();
