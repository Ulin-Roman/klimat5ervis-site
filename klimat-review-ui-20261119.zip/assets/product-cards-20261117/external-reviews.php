<?php
/** Storefront view of verified third-party reviews. PHP 7.4 / HostCMS DOM adapter. */
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

function klimat_er_string(array $row, $key)
{
    return isset($row[$key]) && is_string($row[$key]) ? trim($row[$key]) : '';
}

function klimat_er_embed_url($url)
{
    $parts = parse_url($url);
    if (!isset($parts['host'], $parts['path']) || isset($parts['port'])) return false;
    $host = strtolower($parts['host']);
    if ($host === 'www.youtube-nocookie.com') return (bool) preg_match('~^/embed/[A-Za-z0-9_-]{11}$~D', $parts['path']);
    if ($host === 'rutube.ru') return (bool) preg_match('~^/play/embed/[a-f0-9]{32}/?$~D', $parts['path']);
    return false;
}

function klimat_er_media(array $row)
{
    $media = array();
    if (!isset($row['media']) || !is_array($row['media'])) return $media;
    foreach ($row['media'] as $item) {
        if (!is_array($item)) continue;
        $url = klimat_product_cards_20261117_url(klimat_er_string($item, 'url'));
        $type = klimat_er_string($item, 'type');
        if ($url === '' || !in_array($type, array('image', 'video', 'embed'), true)) continue;
        if ($type === 'embed' && !klimat_er_embed_url($url)) continue;
        $media[$type . ' ' . $url] = array(
            'url' => $url,
            'type' => $type,
            'alt' => klimat_er_string($item, 'alt'),
            'thumbnail' => klimat_product_cards_20261117_url(klimat_er_string($item, 'thumbnail')),
        );
    }
    return array_values($media);
}

function klimat_er_read($id, $name, $dataDir = null)
{
    $id = (string) $id;
    if (!preg_match('~^[0-9]{1,12}$~D', $id) || !is_string($name) || $name === '') return array();
    $directory = $dataDir ?? __DIR__ . '/data/external-reviews-v2';
    $file = $directory . '/' . $id . '.json';
    if (is_link($directory) || is_link($file) || !is_file($file)) return array();

    $limit = 1048576;
    $raw = @file_get_contents($file, false, null, 0, $limit + 1);
    if (!is_string($raw) || strlen($raw) > $limit) return array();
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['reviews']) || !is_array($data['reviews'])) return array();
    if ((!is_int($data['productId'] ?? null) && !is_string($data['productId'] ?? null)) || (string) $data['productId'] !== $id) return array();
    if (klimat_product_cards_20261117_text(klimat_er_string($data, 'productName')) !== $name) return array();

    $reviews = array();
    foreach ($data['reviews'] as $row) {
        if (!is_array($row)) continue;
        $key = klimat_er_string($row, 'id');
        $source = klimat_er_string($row, 'source');
        $url = klimat_product_cards_20261117_url(klimat_er_string($row, 'url'));
        if ($key === '' || $url === '' || $source === '' || isset($reviews[$key])) continue;
        $rating = $row['rating'] ?? null;
        $rating = is_int($rating) && $rating >= 1 && $rating <= 5 ? $rating : null;
        $date = klimat_er_string($row, 'date');
        $date = klimat_product_cards_20261117_verified(array('source_url' => $url, 'checked_at' => $date)) ? $date : '';
        $type = klimat_er_string($row, 'summaryType');
        $summary = klimat_er_string($row, 'summary');
        $pros = klimat_er_string($row, 'pros');
        $cons = klimat_er_string($row, 'cons');
        if (($summary !== '' || $pros !== '' || $cons !== '') && !in_array($type, array('editorial', 'original'), true)) continue;
        $media = klimat_er_media($row);
        if ($summary === '' && $pros === '' && $cons === '' && $rating === null && !$media) continue;
        $reviews[$key] = array(
            'source' => $source, 'url' => $url, 'author' => klimat_er_string($row, 'author'),
            'date' => $date, 'rating' => $rating, 'summaryType' => $type, 'summary' => $summary,
            'pros' => $pros, 'cons' => $cons, 'media' => $media,
        );
    }
    $reviews = array_values($reviews);
    usort($reviews, static function ($left, $right) {
        return strcmp($right['date'], $left['date']);
    });
    return $reviews;
}

function klimat_er_stats(array $records)
{
    $distribution = array_fill(1, 5, 0);
    $ratedCount = 0;
    $sum = 0;
    foreach ($records as $review) {
        $rating = $review['rating'];
        if ($rating === null) continue;
        $distribution[$rating]++;
        $ratedCount++;
        $sum += $rating;
    }
    return array(
        'count' => count($records), 'ratedCount' => $ratedCount,
        'average' => $ratedCount ? $sum / $ratedCount : null, 'distribution' => $distribution,
    );
}

function klimat_er_score($doc, $value, $aggregate)
{
    $score = klimat_native_review_stars($doc, $value, $aggregate, true);
    if ($aggregate) $score->insertBefore($score->lastChild, $score->firstChild);
    $score->setAttribute('class', $score->getAttribute('class') . ' ks-er__score-value');
    $score->setAttribute('aria-label', 'Оценка ' . number_format($value, $aggregate ? 1 : 0, ',', '') . ' из 5');
    return $score;
}

function klimat_er_overview($doc, array $stats)
{
    $summary = klimat_native_review_node($doc, 'div', 'ks-er__summary');
    $score = klimat_native_review_node($doc, 'div', 'ks-er__score');
    if ($stats['ratedCount']) $score->appendChild(klimat_er_score($doc, $stats['average'], true));
    $score->appendChild(klimat_native_review_node($doc, 'span', '', klimat_native_review_count_label($stats['count'])));
    $label = $stats['ratedCount']
        ? klimat_native_review_count_label($stats['ratedCount'], array('оценка', 'оценки', 'оценок')) . ' в подборке'
        : 'Оценки в источниках не указаны';
    $score->appendChild(klimat_native_review_node($doc, 'span', 'ks-er__muted', $label));
    $summary->appendChild($score);
    if (!$stats['ratedCount']) return $summary;

    $histogram = klimat_native_review_node($doc, 'ul', 'ks-er__histogram', null, array('aria-label' => 'Распределение оценок'));
    foreach (array_reverse($stats['distribution'], true) as $rating => $count) {
        $row = klimat_native_review_node($doc, 'li', 'ks-er__histogram-row');
        $row->appendChild(klimat_native_review_node($doc, 'span', '', $rating . ' ★', array('aria-hidden' => 'true')));
        $row->appendChild(klimat_native_review_node($doc, 'meter', '', null, array(
            'min' => 0, 'max' => $stats['ratedCount'], 'value' => $count, 'aria-label' => $rating . ' из 5',
        )));
        $row->appendChild(klimat_native_review_node($doc, 'span', '', (string) $count));
        $histogram->appendChild($row);
    }
    $summary->appendChild($histogram);
    return $summary;
}

function klimat_er_media_node($doc, array $item)
{
    $title = $item['alt'] !== '' ? $item['alt'] : 'Материал покупателя';
    if ($item['type'] === 'image') {
        $link = klimat_native_review_node($doc, 'a', '', null, array(
            'href' => $item['url'], 'data-er-image' => '', 'target' => '_blank', 'rel' => 'noopener noreferrer',
        ));
        $link->appendChild(klimat_native_review_node($doc, 'img', '', null, array(
            'src' => $item['thumbnail'] ?: $item['url'], 'loading' => 'lazy', 'decoding' => 'async',
            'referrerpolicy' => 'no-referrer', 'width' => 88, 'height' => 88, 'alt' => $title,
        )));
        return $link;
    }
    if ($item['type'] === 'embed') {
        return klimat_native_review_node($doc, 'button', 'ks-er__play', 'Смотреть видео', array(
            'type' => 'button', 'data-er-embed' => $item['url'], 'data-er-title' => $title,
        ));
    }
    $attrs = array('controls' => 'controls', 'preload' => 'none', 'playsinline' => 'playsinline', 'src' => $item['url'], 'aria-label' => $title);
    if ($item['thumbnail']) $attrs['poster'] = $item['thumbnail'];
    return klimat_native_review_node($doc, 'video', '', null, $attrs);
}

function klimat_er_card($doc, array $review)
{
    $card = klimat_native_review_node($doc, 'article', 'ks-er__card', null, array(
        'data-er-card' => '', 'data-rating' => $review['rating'] ?? '', 'data-date' => $review['date'],
    ));
    $head = klimat_native_review_node($doc, 'header', 'ks-er__head');
    if ($review['author'] !== '') $head->appendChild(klimat_native_review_node($doc, 'strong', 'ks-er__author', $review['author']));
    if ($review['date'] !== '') {
        $head->appendChild(klimat_native_review_node($doc, 'time', 'ks-er__muted', implode('.', array_reverse(explode('-', $review['date']))), array('datetime' => $review['date'])));
    }
    if ($review['rating'] !== null) $head->appendChild(klimat_er_score($doc, $review['rating'], false));
    $source = '«' . $review['source'] . '»';
    if ($review['summaryType'] === 'editorial') $source .= ' · пересказ';
    $head->appendChild(klimat_native_review_node($doc, 'span', 'ks-er__source', $source));
    $card->appendChild($head);
    $body = $review['summary'] !== '' ? $review['summary'] : $review['pros'];
    if ($body !== '') $card->appendChild(klimat_native_review_node($doc, 'p', 'ks-er__body', $body));
    if ($review['cons'] !== '') {
        $attributes = klimat_native_review_node($doc, 'dl', 'ks-er__attributes');
        $attributes->appendChild(klimat_native_review_node($doc, 'dt', '', 'Недостатки'));
        $attributes->appendChild(klimat_native_review_node($doc, 'dd', '', $review['cons']));
        $card->appendChild($attributes);
    }
    if ($review['media']) {
        $media = klimat_native_review_node($doc, 'div', 'ks-er__media');
        foreach ($review['media'] as $item) $media->appendChild(klimat_er_media_node($doc, $item));
        $card->appendChild($media);
    }
    return $card;
}

function klimat_er_section($doc, array $records, array $stats)
{
    $section = klimat_native_review_node($doc, 'section', 'ks-er', null, array('data-ks-external-reviews' => '', 'aria-labelledby' => 'ks-er-title'));
    $section->appendChild(klimat_native_review_node($doc, 'h2', '', 'Отзывы с других площадок', array('id' => 'ks-er-title')));
    if (!$records) {
        $section->appendChild(klimat_native_review_node($doc, 'p', 'ks-er__empty', 'Пока нет подтверждённых сторонних отзывов об этой модели.'));
        return $section;
    }

    $section->appendChild(klimat_er_overview($doc, $stats));
    $section->appendChild(klimat_native_review_node($doc, 'p', 'ks-er__muted', '', array('data-er-count' => '', 'role' => 'status', 'hidden' => 'hidden')));
    $list = klimat_native_review_node($doc, 'div', 'ks-er__list', null, array('data-er-list' => ''));
    foreach ($records as $record) $list->appendChild(klimat_er_card($doc, $record));
    $section->appendChild($list);
    $section->appendChild(klimat_native_review_node($doc, 'button', 'ks-er__more', 'Показать ещё', array('type' => 'button', 'data-er-more' => '', 'hidden' => 'hidden')));
    return $section;
}
