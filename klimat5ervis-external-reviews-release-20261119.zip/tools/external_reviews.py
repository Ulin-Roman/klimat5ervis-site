#!/usr/bin/env python3
"""Maintain the private, resumable product-review journal and export public data."""

import argparse
import csv
import hashlib
import json
import os
import re
import sqlite3
import sys
import tempfile
import unicodedata
from collections import Counter
from datetime import date
from pathlib import Path
from urllib.parse import urlsplit


ID_FIELD = 'ID товара в HostCMS'
SKU_FIELD = 'Артикул на сайте'
STATES = ('reviewed', 'partial', 'no_reviews', 'restricted', 'error')
REVIEW_RIGHTS = {'permission', 'license', 'summary', 'blocked', 'unknown'}
MEDIA_RIGHTS = {'permission', 'license', 'embed', 'blocked', 'unknown'}
ALLOWED_RIGHTS = {'permission', 'license', 'summary'}
MAX_PUBLIC_BYTES = 1024 * 1024
EMBED_PROVIDERS = {
    'www.youtube-nocookie.com': '/embed/',
    'rutube.ru': '/play/embed/',
}

SCHEMA = '''
CREATE TABLE IF NOT EXISTS product (
    id INTEGER PRIMARY KEY,
    sku TEXT NOT NULL,
    manufacturer_sku TEXT NOT NULL,
    model TEXT NOT NULL,
    brand TEXT NOT NULL,
    url TEXT NOT NULL,
    state TEXT NOT NULL,
    reason TEXT NOT NULL,
    checked_at TEXT NOT NULL,
    legacy_publication_status TEXT NOT NULL DEFAULT '',
    updated_by_import INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS source_check (
    product_id INTEGER NOT NULL REFERENCES product(id),
    source TEXT NOT NULL,
    url TEXT NOT NULL,
    checked_at TEXT NOT NULL,
    result TEXT NOT NULL,
    note TEXT NOT NULL,
    PRIMARY KEY (product_id, source, url)
);
CREATE TABLE IF NOT EXISTS review (
    product_id INTEGER NOT NULL REFERENCES product(id),
    source TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_url TEXT NOT NULL,
    checked_at TEXT NOT NULL,
    matched_model TEXT NOT NULL,
    match_evidence TEXT NOT NULL,
    rights_mode TEXT NOT NULL,
    rights_evidence TEXT NOT NULL,
    author TEXT NOT NULL,
    review_date TEXT NOT NULL,
    rating INTEGER,
    fingerprint TEXT NOT NULL,
    public_json TEXT NOT NULL,
    media_found INTEGER NOT NULL,
    media_restricted INTEGER NOT NULL,
    PRIMARY KEY (product_id, source, source_id)
);
CREATE INDEX IF NOT EXISTS review_product_status ON review(product_id, rights_mode);
CREATE TABLE IF NOT EXISTS review_media (
    product_id INTEGER NOT NULL,
    source TEXT NOT NULL,
    source_id TEXT NOT NULL,
    url TEXT NOT NULL,
    kind TEXT NOT NULL,
    status TEXT NOT NULL,
    rights_evidence TEXT NOT NULL,
    PRIMARY KEY (product_id, source, source_id, url),
    FOREIGN KEY (product_id, source, source_id) REFERENCES review(product_id, source, source_id)
);
CREATE TABLE IF NOT EXISTS publication (
    product_id INTEGER PRIMARY KEY REFERENCES product(id),
    sha256 TEXT NOT NULL,
    reviews INTEGER NOT NULL,
    photos INTEGER NOT NULL,
    videos INTEGER NOT NULL,
    published_at TEXT NOT NULL
);
'''


def json_text(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def normalize(value):
    return ' '.join(unicodedata.normalize('NFKC', value).casefold().split())


def string(record, key, *, required=False):
    value = record.get(key, '')
    if not isinstance(value, str) or (required and not value.strip()):
        raise ValueError(f'{key}: expected a nonempty string' if required else f'{key}: expected a string')
    return value.strip()


def positive_id(value):
    if type(value) is int and value > 0:
        return value
    if isinstance(value, str) and re.fullmatch(r'[1-9][0-9]*', value):
        return int(value)
    raise ValueError(f'Invalid product ID {value!r}')


def https_url(value):
    parsed = urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError(f'Expected a public HTTPS URL: {value!r}')
    if re.search(r'\s|[\x00-\x1f\x7f]', value):
        raise ValueError(f'Invalid whitespace in URL: {value!r}')
    return value


def iso_date(value, *, optional=False):
    if not value and optional:
        return ''
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        raise ValueError(f'Expected date YYYY-MM-DD: {value!r}')
    return date.fromisoformat(value).isoformat()


def import_catalog(db, path, sources_path):
    with path.open(encoding='utf-8-sig', newline='') as file:
        rows = list(csv.DictReader(file, delimiter=';'))
    ids = set()
    for row in rows:
        product_id = positive_id(row[ID_FIELD])
        if product_id in ids:
            raise ValueError(f'Duplicate HostCMS ID in catalog: {product_id}')
        ids.add(product_id)
        model = string(row, 'Модель', required=True)
        shop_url = https_url(string(row, 'Карточка на сайте', required=True))
        if urlsplit(shop_url).hostname != 'klimat5ervis.ru' or not urlsplit(shop_url).path.rstrip('/').endswith(f'/{product_id}'):
            raise ValueError(f'Product {product_id}: storefront URL does not match ID')
        status = string(row, 'Статус поиска')
        state = 'pending' if status in ('', 'Ожидает проверки') else 'legacy_checked'
        db.execute('''INSERT INTO product (id, sku, manufacturer_sku, model, brand, url, state, reason, checked_at, legacy_publication_status)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, '', ?) ON CONFLICT(id) DO UPDATE SET
                      sku=excluded.sku, manufacturer_sku=excluded.manufacturer_sku, model=excluded.model,
                      brand=excluded.brand, url=excluded.url, legacy_publication_status=excluded.legacy_publication_status,
                      state=CASE WHEN product.state='pending' THEN excluded.state ELSE product.state END,
                      reason=CASE WHEN product.state='pending' THEN excluded.reason ELSE product.reason END''',
                   (product_id, row[SKU_FIELD], row['Артикул производителя'], model, row['Бренд'], shop_url,
                    state, row['Причина отсутствия рейтинга'], row['Статус публикации']))
    if sources_path:
        with sources_path.open(encoding='utf-8-sig', newline='') as file:
            for row in csv.DictReader(file, delimiter=';'):
                product_id = positive_id(row[ID_FIELD])
                url = string(row, 'Ссылка на оригинал')
                source = string(row, 'Площадка', required=True)
                checked_at = iso_date(string(row, 'Дата проверки'), optional=True)
                if not url or not url.startswith('https://'):
                    continue
                evidence = string(row, 'Основание для решения')
                match = normalize(string(row, 'Модификация подтверждена')) == 'да'
                write_source_check(db, product_id, source, https_url(url), checked_at,
                                   'legacy_exact' if match else 'legacy_unconfirmed', evidence, overwrite=False)
                db.execute('''UPDATE product SET checked_at=max(checked_at, ?) WHERE id=? AND updated_by_import=0''',
                           (checked_at, product_id))
    return {'catalogRows': len(ids)}


def write_source_check(db, product_id, source, url, checked_at, result, note, *, overwrite=True):
    sql = '''INSERT INTO source_check VALUES (?, ?, ?, ?, ?, ?)
             ON CONFLICT(product_id, source, url) '''
    sql += ('''DO UPDATE SET checked_at=excluded.checked_at, result=excluded.result, note=excluded.note
               WHERE excluded.checked_at>=source_check.checked_at''' if overwrite else 'DO NOTHING')
    db.execute(sql, (product_id, source, url, checked_at, result, note))


def rights(record, modes):
    entry = record.get('rights')
    if not isinstance(entry, dict):
        raise ValueError('rights: expected an object')
    mode = string(entry, 'mode', required=True)
    if mode not in modes:
        raise ValueError(f'Unsupported rights mode: {mode}')
    return mode, string(entry, 'evidence', required=True)


def public_media(media, review_allowed):
    if not isinstance(media, list):
        raise ValueError('media: expected a list')
    output = []
    private = []
    seen = set()
    restricted = 0
    for entry in media:
        kind = string(entry, 'type', required=True)
        if kind not in {'image', 'video', 'embed'}:
            raise ValueError(f'Unsupported media type: {kind}')
        url = https_url(string(entry, 'url', required=True))
        if url in seen:
            raise ValueError(f'Duplicate media in one review: {url}')
        seen.add(url)
        mode, evidence = rights(entry, MEDIA_RIGHTS)
        if not review_allowed or mode in {'blocked', 'unknown'}:
            restricted += 1
            private.append((url, kind, 'restricted', evidence))
            continue
        if kind == 'embed':
            parsed = urlsplit(url)
            prefix = EMBED_PROVIDERS.get(parsed.hostname)
            valid_path = prefix and (parsed.path.startswith(prefix) if prefix.endswith('/') else parsed.path == prefix)
            if not valid_path or parsed.port not in (None, 443):
                raise ValueError(f'Unsupported embed URL: {url}')
        elif mode == 'embed':
            raise ValueError('Embed rights only apply to supported embedded players')
        public = {'type': kind, 'url': url}
        thumb = string(entry, 'thumbnail')
        if thumb:
            thumb_mode, thumb_evidence = rights({'rights': entry.get('thumbnailRights', entry['rights'])}, MEDIA_RIGHTS)
            if thumb_mode in {'permission', 'license'}:
                public['thumbnail'] = https_url(thumb)
                evidence = f'{evidence}\nThumbnail: {thumb_evidence}'
        alt = string(entry, 'alt')
        if alt:
            public['alt'] = alt
        output.append(public)
        private.append((url, kind, mode, evidence))
    return output, private, restricted


def import_review(db, record):
    product_id = positive_id(record.get('productId'))
    row = db.execute('SELECT model FROM product WHERE id=?', (product_id,)).fetchone()
    if row is None:
        raise ValueError(f'Unknown product ID: {product_id}')
    matched_model = string(record, 'matchedModel', required=True)
    if normalize(matched_model) != normalize(row['model']):
        raise ValueError(f'Product {product_id}: matchedModel must identify the exact storefront model {row["model"]!r}')
    match_evidence = string(record, 'matchEvidence', required=True)
    source = string(record, 'source', required=True)
    source_id = string(record, 'id', required=True)
    checked_at = iso_date(string(record, 'checkedAt', required=True))
    reviewed_at = iso_date(string(record, 'date'), optional=True)
    url = https_url(string(record, 'url', required=True))
    mode, evidence = rights(record, REVIEW_RIGHTS)
    publishable = mode in ALLOWED_RIGHTS
    summary, pros, cons = (string(record, key) for key in ('summary', 'pros', 'cons'))
    if not publishable and any((summary, pros, cons)):
        raise ValueError('Restricted review input must contain metadata only')
    author = string(record, 'author')
    rating = record.get('rating')
    if rating is not None and (type(rating) is not int or not 1 <= rating <= 5):
        raise ValueError('rating: expected an integer from 1 to 5 or null')
    media, private_media, media_restricted = public_media(record.get('media', []), publishable)
    if publishable and not any((summary, pros, cons, media, rating)):
        raise ValueError('A published review needs text, permitted media or an individual rating')
    stable_id = hashlib.sha256(f'{normalize(source)}\n{source_id}'.encode()).hexdigest()[:24]
    dedup_content = normalize(' '.join([summary, pros, cons]))
    dedup_key = normalize(string(record, 'dedupKey'))
    fingerprint = ''
    if dedup_key:
        fingerprint = hashlib.sha256(('verified duplicate group\n' + dedup_key).encode()).hexdigest()
    elif author and reviewed_at and len(dedup_content) >= 20:
        fingerprint = hashlib.sha256(json_text([normalize(author), reviewed_at, rating, dedup_content]).encode()).hexdigest()
    payload = {'id': stable_id, 'source': source, 'url': url, 'author': author, 'date': reviewed_at,
               'rating': rating, 'summary': summary, 'summaryType': 'editorial' if mode == 'summary' else 'original',
               'pros': pros, 'cons': cons, 'media': media}
    review_key = (product_id, normalize(source), source_id)
    changed = db.execute('''INSERT INTO review VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                  ON CONFLICT(product_id, source, source_id) DO UPDATE SET
                  source_url=excluded.source_url, checked_at=excluded.checked_at, matched_model=excluded.matched_model,
                  match_evidence=excluded.match_evidence, rights_mode=excluded.rights_mode,
                  rights_evidence=excluded.rights_evidence, author=excluded.author, review_date=excluded.review_date,
                  rating=excluded.rating, fingerprint=excluded.fingerprint,
                  public_json=excluded.public_json, media_found=excluded.media_found, media_restricted=excluded.media_restricted
                  WHERE excluded.checked_at>=review.checked_at''',
               (*review_key, url, checked_at, row['model'], match_evidence, mode, evidence, author, reviewed_at, rating,
                fingerprint, json_text(payload) if publishable else '', len(private_media), media_restricted))
    if changed.rowcount:
        db.execute('DELETE FROM review_media WHERE product_id=? AND source=? AND source_id=?', review_key)
        db.executemany('INSERT INTO review_media VALUES (?, ?, ?, ?, ?, ?, ?)',
                       [(*review_key, *item) for item in private_media])
    write_source_check(db, product_id, source, url, checked_at, 'exact_review', match_evidence)


def import_check(db, check):
    product_id = positive_id(check.get('productId'))
    status = string(check, 'status', required=True)
    if status not in STATES:
        raise ValueError(f'Product {product_id}: invalid status {status!r}')
    checked_at = iso_date(string(check, 'checkedAt', required=True))
    reason = string(check, 'reason', required=True)
    evidence = check.get('sources', [])
    if not isinstance(evidence, list):
        raise ValueError('sources: expected a list')
    if status in {'reviewed', 'no_reviews', 'restricted'} and not evidence and not db.execute(
        'SELECT 1 FROM source_check WHERE product_id=? AND checked_at=? LIMIT 1', (product_id, checked_at)
    ).fetchone():
        raise ValueError(f'Product {product_id}: terminal research status needs dated source evidence')
    for source in evidence:
        write_source_check(db, product_id, string(source, 'source', required=True),
                           https_url(string(source, 'url', required=True)), checked_at,
                           string(source, 'result', required=True), string(source, 'note', required=True))
    if not db.execute('SELECT 1 FROM product WHERE id=?', (product_id,)).fetchone():
        raise ValueError(f'Unknown product ID: {product_id}')
    db.execute('''UPDATE product SET state=?, reason=?, checked_at=?, updated_by_import=1
                  WHERE id=? AND checked_at<=?''', (status, reason, checked_at, product_id, checked_at))


def import_data(db, path):
    value = json.loads(path.read_text(encoding='utf-8-sig'))
    reviews = value if isinstance(value, list) else value.get('reviews', [])
    checks = [] if isinstance(value, list) else value.get('checks', [])
    seen = set()
    for review in reviews:
        key = (positive_id(review.get('productId')), normalize(string(review, 'source', required=True)),
               string(review, 'id', required=True))
        if key in seen:
            raise ValueError(f'Duplicate source review in the same batch: {key}')
        seen.add(key)
        import_review(db, review)
    for check in checks:
        import_check(db, check)
    return {'reviewsImported': len(reviews), 'checksImported': len(checks)}


def export_records(db, product_id):
    rows = db.execute('''SELECT r.fingerprint, r.public_json FROM review r JOIN product p ON p.id=r.product_id
                         WHERE r.product_id=? AND r.public_json<>'' AND r.matched_model=p.model
                         ORDER BY r.checked_at DESC, r.source, r.source_id''', (product_id,)).fetchall()
    seen = set()
    records = []
    for row in rows:
        fingerprint = row['fingerprint']
        if fingerprint and fingerprint in seen:
            continue
        seen.add(fingerprint)
        records.append(json.loads(row['public_json']))
    return sorted(records, key=lambda record: (record['date'], record['id']), reverse=True)


def atomic_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=f'.{path.name}.', delete=False) as file:
        tmp = Path(file.name)
        try:
            file.write(value)
            file.flush()
            os.fsync(file.fileno())
            os.chmod(tmp, 0o644)
            os.replace(tmp, path)
        finally:
            tmp.unlink(missing_ok=True)


def artifact(db, product_id, records):
    product_name = db.execute('SELECT model FROM product WHERE id=?', (product_id,)).fetchone()[0]
    payload = json_text({'productId': product_id, 'productName': product_name, 'reviews': records}).encode()
    if len(payload) > MAX_PUBLIC_BYTES:
        raise ValueError(f'Product {product_id}: public JSON exceeds 1 MiB')
    media = Counter(entry['type'] for record in records for entry in record['media'])
    return payload, {'productId': product_id, 'sha256': hashlib.sha256(payload).hexdigest(),
                     'reviews': len(records), 'photos': media['image'], 'videos': media['video'] + media['embed']}


def export_batch(db, directory, product_ids, manifest_path):
    if not product_ids:
        product_ids = [row[0] for row in db.execute('''SELECT product_id FROM review
                                                      UNION SELECT product_id FROM publication ORDER BY product_id''')]
    elif set(product_ids) - {row[0] for row in db.execute('SELECT id FROM product')}:
        raise ValueError('Export includes an unknown product ID')
    result = []
    for product_id in sorted(set(product_ids)):
        payload, info = artifact(db, product_id, export_records(db, product_id))
        atomic_write(directory / f'{product_id}.json', payload)
        result.append(info)
    manifest = {'products': result}
    if manifest_path:
        atomic_write(manifest_path, json_text(manifest).encode())
    return manifest


def mark_published(db, manifest_path, published_at):
    entries = json.loads(manifest_path.read_text(encoding='utf-8'))['products']
    for entry in entries:
        product_id = positive_id(entry['productId'])
        rows = db.execute('SELECT 1 FROM product WHERE id=?', (product_id,)).fetchone()
        if rows is None:
            raise ValueError(f'Unknown product ID in manifest: {product_id}')
        _, info = artifact(db, product_id, export_records(db, product_id))
        if entry != info:
            raise ValueError(f'Export for {product_id} changed since building the manifest')
        db.execute('''INSERT INTO publication VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(product_id) DO UPDATE SET
                      sha256=excluded.sha256, reviews=excluded.reviews, photos=excluded.photos,
                      videos=excluded.videos, published_at=excluded.published_at
                      WHERE excluded.published_at>=publication.published_at''',
                   (product_id, info['sha256'], info['reviews'], info['photos'], info['videos'], published_at))
    return {'publicationRecorded': len(entries)}


def journal_status(db):
    states = dict(db.execute('SELECT state, count(*) FROM product GROUP BY state').fetchall())
    source_count = db.execute('SELECT count(*) FROM source_check').fetchone()[0]
    restricted = db.execute('''SELECT count(*) FROM (SELECT product_id FROM review
                               WHERE rights_mode IN ('blocked','unknown') OR media_restricted>0
                               UNION SELECT id FROM product WHERE state='restricted')''').fetchone()[0]
    review_count = db.execute('SELECT count(*) FROM review').fetchone()[0]
    legacy_live = db.execute("SELECT count(*) FROM product WHERE legacy_publication_status LIKE 'Опубликован%'").fetchone()[0]
    prepared = Counter()
    for row in db.execute("SELECT DISTINCT product_id FROM review WHERE public_json<>''"):
        _, info = artifact(db, row['product_id'], export_records(db, row['product_id']))
        for key in ('reviews', 'photos', 'videos'):
            prepared[key] += info[key]
    published = db.execute('''SELECT coalesce(sum(reviews),0) AS reviews, coalesce(sum(photos),0) AS photos,
                              coalesce(sum(videos),0) AS videos, count(CASE WHEN reviews>0 THEN 1 END) AS products
                              FROM publication''').fetchone()
    return {'catalogProducts': sum(states.values()), 'states': states, 'sourceChecks': source_count,
            'productsPreviouslyPublished': legacy_live,
            'reviewCandidates': review_count, 'productsWithRestrictedReviewOrMedia': restricted,
            'prepared': {key: prepared[key] for key in ('reviews', 'photos', 'videos')}, 'publicationRecorded': dict(published)}


def queue(db, limit, retry):
    states = ('partial', 'restricted', 'error') if retry else ('pending',)
    placeholders = ','.join('?' for _ in states)
    return [dict(row) for row in db.execute(f'''SELECT id AS productId, sku, manufacturer_sku AS manufacturerSku,
                                              model, brand, url, state, reason FROM product WHERE state IN ({placeholders})
                                              ORDER BY checked_at, id LIMIT ?''', (*states, limit))]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, required=True, help='private SQLite file outside the webroot')
    commands = parser.add_subparsers(dest='command', required=True)
    init = commands.add_parser('init', help='initialize or refresh catalog and historical source checks')
    init.add_argument('--catalog', type=Path, required=True)
    init.add_argument('--sources', type=Path)
    next_batch = commands.add_parser('next', help='list the next batch without advancing the journal')
    next_batch.add_argument('--limit', type=positive_id, default=25)
    next_batch.add_argument('--retry', action='store_true', help='show partial, restricted, or errored checks')
    batch = commands.add_parser('import', help='record a manually verified batch of reviews and source checks')
    batch.add_argument('file', type=Path)
    export = commands.add_parser('export', help='produce public per-product JSON files')
    export.add_argument('--out', type=Path, required=True)
    export.add_argument('--ids', type=positive_id, nargs='+', default=[])
    export.add_argument('--manifest', type=Path)
    publication = commands.add_parser('mark-published', help='record a verified production deployment')
    publication.add_argument('--manifest', type=Path, required=True)
    publication.add_argument('--date', type=iso_date, default=date.today().isoformat())
    commands.add_parser('status', help='summarize current progress')
    args = parser.parse_args()

    if args.command == 'init':
        args.db.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(args.db, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            pass
        else:
            os.close(fd)
    elif not args.db.is_file():
        parser.error('Initialize the journal with init first')
    db = sqlite3.connect(args.db, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    try:
        db.executescript(SCHEMA)
        with db:
            db.execute('BEGIN IMMEDIATE' if args.command in {'init', 'import', 'mark-published'} else 'BEGIN')
            operations = {
                'init': lambda: import_catalog(db, args.catalog, args.sources),
                'next': lambda: queue(db, args.limit, args.retry),
                'import': lambda: import_data(db, args.file),
                'export': lambda: export_batch(db, args.out, args.ids, args.manifest),
                'mark-published': lambda: mark_published(db, args.manifest, args.date),
                'status': lambda: journal_status(db),
            }
            result = operations[args.command]()
        print(json_text(result), end='')
    except (ValueError, OSError, TypeError, KeyError, AttributeError, sqlite3.Error) as exc:
        print(f'External reviews: {exc}', file=sys.stderr)
        return 1
    finally:
        db.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
