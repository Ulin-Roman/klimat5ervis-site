(() => {
  'use strict';

  const pageSize = 6;
  const mediaButtons = 'a[data-er-image], button[data-er-embed]';

  function makeButton(className, text) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = text;
    return button;
  }

  function mediaUrl(value) {
    if (!value) return '';
    try {
      const url = new URL(value, document.baseURI);
      return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
    } catch {
      return '';
    }
  }

  function makeGallery(section) {
    const dialog = document.createElement('dialog');
    if (typeof dialog.showModal !== 'function') return null;
    dialog.className = 'ks-er-dialog';
    dialog.setAttribute('aria-label', 'Фотографии из отзыва');
    const surface = document.createElement('div');
    surface.className = 'ks-er-dialog__surface';

    const header = document.createElement('div');
    header.className = 'ks-er-dialog__header';
    const position = document.createElement('span');
    position.setAttribute('aria-live', 'polite');
    const fullscreen = makeButton('ks-er-dialog__button', 'Во весь экран');
    fullscreen.setAttribute('aria-pressed', 'false');
    const close = makeButton('ks-er-dialog__button', 'Закрыть');
    close.autofocus = true;
    header.append(position, fullscreen, close);

    const figure = document.createElement('figure');
    figure.className = 'ks-er-dialog__figure';
    const image = document.createElement('img');
    image.decoding = 'async';
    image.referrerPolicy = 'no-referrer';
    const original = document.createElement('a');
    original.textContent = 'Открыть оригинал фотографии';
    original.target = '_blank';
    original.rel = 'noopener noreferrer';
    original.hidden = true;
    figure.append(image, original);

    const controls = document.createElement('div');
    controls.className = 'ks-er-dialog__navigation';
    const previous = makeButton('ks-er-dialog__button', 'Предыдущая');
    const next = makeButton('ks-er-dialog__button', 'Следующая');
    controls.append(previous, next);
    surface.append(header, figure, controls);
    dialog.append(surface);
    section.append(dialog);

    let photos = [];
    let index = 0;
    let opener = null;

    function render() {
      const photo = photos[index];
      if (!photo) return;
      image.hidden = false;
      original.hidden = true;
      image.alt = photo.alt;
      image.src = photo.url;
      original.href = photo.url;
      position.textContent = `Фото ${index + 1} из ${photos.length}`;
      controls.hidden = photos.length < 2;
    }

    function step(direction) {
      if (photos.length < 2) return;
      index = (index + direction + photos.length) % photos.length;
      render();
    }

    function setExpanded(expanded) {
      fullscreen.setAttribute('aria-pressed', String(expanded));
      fullscreen.textContent = expanded ? 'Выйти из полноэкранного режима' : 'Во весь экран';
    }

    previous.addEventListener('click', () => step(-1));
    next.addEventListener('click', () => step(1));
    image.addEventListener('error', () => {
      image.hidden = true;
      original.hidden = false;
    });
    close.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const bounds = dialog.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
    });
    dialog.addEventListener('keydown', event => {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
      event.preventDefault();
      step(event.key === 'ArrowLeft' ? -1 : 1);
    });
    fullscreen.addEventListener('click', async () => {
      if (document.fullscreenElement === surface) {
        await document.exitFullscreen().catch(() => {});
        return;
      }
      if (dialog.classList.contains('ks-er-dialog--expanded')) {
        dialog.classList.remove('ks-er-dialog--expanded');
        setExpanded(false);
        return;
      }
      if (document.fullscreenEnabled && surface.requestFullscreen) {
        try {
          await surface.requestFullscreen();
          return;
        } catch {
          if (!dialog.open) return;
        }
      }
      dialog.classList.add('ks-er-dialog--expanded');
      setExpanded(true);
    });
    document.addEventListener('fullscreenchange', () => {
      setExpanded(document.fullscreenElement === surface || dialog.classList.contains('ks-er-dialog--expanded'));
    });
    dialog.addEventListener('close', () => {
      if (document.fullscreenElement === surface) document.exitFullscreen().catch(() => {});
      dialog.classList.remove('ks-er-dialog--expanded');
      setExpanded(false);
      photos = [];
      image.removeAttribute('src');
      if (opener?.isConnected && !opener.closest('[hidden]')) opener.focus();
      opener = null;
    });

    return link => {
      const card = link.closest('[data-er-card]');
      if (!card) return false;
      photos = Array.from(card.querySelectorAll('a[data-er-image]'), anchor => ({
        anchor,
        url: mediaUrl(anchor.getAttribute('href')),
        alt: anchor.querySelector('img')?.alt || 'Фотография покупателя'
      })).filter(photo => photo.url);
      index = photos.findIndex(photo => photo.anchor === link);
      if (index === -1) return false;
      opener = link;
      render();
      dialog.showModal();
      return true;
    };
  }

  function activateEmbed(button) {
    const url = mediaUrl(button.dataset.erEmbed);
    if (!url) return;
    const frame = document.createElement('iframe');
    frame.className = 'ks-er__player';
    frame.title = button.dataset.erTitle || 'Видео покупателя';
    frame.referrerPolicy = 'strict-origin-when-cross-origin';
    frame.allow = 'fullscreen; picture-in-picture';
    frame.allowFullscreen = true;
    frame.src = url;
    button.replaceWith(frame);
    frame.focus();
    return frame;
  }

  function compareReviews(left, right, mode) {
    const byRating = mode.startsWith('rating');
    const first = byRating ? left.rating : left.date;
    const second = byRating ? right.rating : right.date;
    if (first === null && second !== null) return 1;
    if (second === null && first !== null) return -1;
    if (first !== second) return (first < second ? -1 : 1) * (mode.endsWith('-asc') ? 1 : -1);
    return left.index - right.index;
  }

  function init(section) {
    const list = section.querySelector('[data-er-list]');
    if (!list) return;
    const controls = section.querySelector('[data-er-controls]');
    const rating = section.querySelector('[data-er-rating]');
    const sort = section.querySelector('[data-er-sort]');
    const photos = section.querySelector('[data-er-photo]');
    const videos = section.querySelector('[data-er-video]');
    const more = section.querySelector('[data-er-more]');
    const empty = section.querySelector('[data-er-filter-empty]');
    const count = section.querySelector('[data-er-count]');
    const cards = Array.from(list.children).filter(card => card.hasAttribute('data-er-card')).map((card, index) => ({
      card, index,
      rating: /^[1-5]$/.test(card.dataset.rating) ? Number(card.dataset.rating) : null,
      date: /^\d{4}-\d{2}-\d{2}$/.test(card.dataset.date) ? card.dataset.date : null,
      photo: !!card.querySelector('a[data-er-image]'),
      video: !!card.querySelector('video, button[data-er-embed], iframe.ks-er__player')
    }));
    if (!cards.length) return;
    let openGallery;
    const players = new WeakMap();
    let limit = more ? pageSize : cards.length;
    let matches = [];
    let lastOrder;

    function render() {
      const order = sort?.value || 'date-desc';
      const value = Number(rating?.value) || 0;
      if (lastOrder !== order) {
        cards.sort((left, right) => compareReviews(left, right, order));
        list.append(...cards.map(({ card }) => card));
        lastOrder = order;
      }
      matches = cards.filter(review => (!value || review.rating === value) &&
        (!photos?.checked || review.photo) && (!videos?.checked || review.video));
      const visible = new Set(matches.slice(0, limit));
      cards.forEach(review => {
        const hidden = !visible.has(review);
        if (hidden && !review.card.hidden && review.video) {
          review.card.querySelectorAll('video').forEach(video => video.pause());
          review.card.querySelectorAll('iframe.ks-er__player').forEach(frame => {
            const button = players.get(frame);
            if (button) frame.replaceWith(button);
          });
        }
        review.card.hidden = hidden;
      });
      if (more) more.hidden = matches.length <= limit;
      if (empty) empty.hidden = matches.length > 0;
      if (count) count.textContent = `Показано ${Math.min(matches.length, limit)} из ${matches.length}`;
    }

    function changeFilters() {
      limit = more ? pageSize : cards.length;
      render();
    }

    controls?.addEventListener('change', changeFilters);
    more?.addEventListener('click', () => {
      const firstNew = matches[limit]?.card;
      limit += pageSize;
      render();
      if (firstNew) {
        firstNew.tabIndex = -1;
        firstNew.focus();
      }
    });
    section.addEventListener('click', event => {
      const target = event.target.closest?.(mediaButtons);
      if (!target) return;
      if (target.hasAttribute('data-er-image')) {
        if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
        if (openGallery === undefined) openGallery = makeGallery(section);
        if (openGallery?.(target)) event.preventDefault();
      } else {
        const frame = activateEmbed(target);
        if (frame) players.set(frame, target);
      }
    });
    section.classList.add('ks-er--interactive');
    if (controls) controls.hidden = false;
    if (count) count.hidden = false;
    render();
  }

  function start() {
    document.querySelectorAll('[data-ks-external-reviews]').forEach(init);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
