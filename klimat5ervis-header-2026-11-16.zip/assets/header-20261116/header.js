/* No dependencies: the existing shop's AJAX handlers and counters remain unchanged. */
(function () {
  'use strict';
  var header = document.querySelector('.ks-header');
  if (!header) return;
  var menu = header.querySelector('.ks-menu-toggle');
  var nav = header.querySelector('.ks-navigation');
  var backdrop = document.querySelector('.ks-backdrop');
  var search = header.querySelector('.ks-search-toggle');
  var contact = header.querySelector('.ks-contact-toggle');
  var mobile = window.matchMedia('(max-width: 1289.98px)');
  function closePanels(returnFocus) {
    [search, contact].forEach(function (button) {
      var opened = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', 'false');
      document.getElementById(button.getAttribute('aria-controls')).hidden = true;
      if (opened && returnFocus) button.focus();
    });
  }
  function closeMenu(returnFocus) {
    var opened = header.classList.contains('ks-menu-open');
    header.classList.remove('ks-menu-open');
    menu.setAttribute('aria-expanded', 'false');
    menu.setAttribute('aria-label', 'Открыть меню');
    backdrop.hidden = true;
    header.querySelectorAll('.ks-submenu-toggle').forEach(function (button) {
      button.setAttribute('aria-expanded', 'false');
      button.closest('.main-nav__item').classList.remove('ks-submenu-open');
    });
    if (opened && returnFocus) menu.focus();
  }
  menu.addEventListener('click', function () {
    var open = !header.classList.contains('ks-menu-open');
    closePanels(false);
    header.classList.toggle('ks-menu-open', open);
    menu.setAttribute('aria-expanded', String(open));
    menu.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    backdrop.hidden = !open;
    if (open) { var first = Array.from(nav.querySelectorAll('input, a, button')).find(function (item) { return item.getClientRects().length; }); if (first) first.focus(); }
  });
  [search, contact].forEach(function (button) {
    button.addEventListener('click', function () {
      var open = button.getAttribute('aria-expanded') !== 'true';
      closePanels(false); closeMenu(false);
      button.setAttribute('aria-expanded', String(open));
      var panel = document.getElementById(button.getAttribute('aria-controls'));
      panel.hidden = !open;
      if (open) panel.querySelector('input, a').focus();
    });
  });
  header.querySelectorAll('.ks-submenu-toggle').forEach(function (button) {
    button.addEventListener('click', function () {
      var open = button.getAttribute('aria-expanded') !== 'true';
      button.setAttribute('aria-expanded', String(open));
      button.closest('.main-nav__item').classList.toggle('ks-submenu-open', open);
    });
  });
  backdrop.addEventListener('click', function () { closeMenu(true); });
  document.addEventListener('click', function (event) {
    if (!header.contains(event.target)) { closePanels(false); closeMenu(false); }
  });
  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') return;
    closePanels(true); closeMenu(true);
    header.querySelectorAll('.ks-submenu-toggle').forEach(function (button) {
      if (button.getAttribute('aria-expanded') === 'true') {
        button.setAttribute('aria-expanded', 'false');
        button.closest('.main-nav__item').classList.remove('ks-submenu-open');
        if (button.closest('.main-nav__item').contains(document.activeElement)) button.blur();
      }
    });
  });
  header.addEventListener('focusout', function () {
    window.setTimeout(function () {
      if (!header.contains(document.activeElement)) { closePanels(false); closeMenu(false); }
    }, 0);
  });
  mobile.addEventListener('change', function () { closeMenu(false); closePanels(false); });
  // Avoid leaving a hidden panel open when moving between compact and wide phone layouts.
  window.matchMedia('(max-width: 600px)').addEventListener('change', function () { closePanels(false); });
})();
