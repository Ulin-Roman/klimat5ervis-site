<?php
/** Native HostCMS presentation adapter. PHP 7.4; no CMS, DB or network calls. */
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}
function klimat_product_cards_20261117_text($value)
{
    return trim((string) preg_replace('~[\s\x{00a0}]+~u', ' ', (string) $value));
}

function klimat_product_cards_20261117_has_class($node, $class)
{
    return $node instanceof DOMElement && in_array($class, preg_split('~\s+~', $node->getAttribute('class')), TRUE);
}

function klimat_product_cards_20261117_class($node, $class)
{
    if (!klimat_product_cards_20261117_has_class($node, $class)) {
        $node->setAttribute('class', trim($node->getAttribute('class') . ' ' . $class));
    }
}

/** Opaque raw-text elements and comments cannot introduce fragment boundaries. */
function klimat_product_cards_20261117_tokens($html)
{
    $pattern = '~<!--[\s\S]*?-->|<(script|style|textarea)\b(?:[^>\x22\x27]|\x22[^\x22]*\x22|\x27[^\x27]*\x27)*>[\s\S]*?</\1\s*>|<(?:[^>\x22\x27]|\x22[^\x22]*\x22|\x27[^\x27]*\x27)*>~i';
    if (preg_match_all($pattern, $html, $matches, PREG_OFFSET_CAPTURE) === FALSE) return array();
    $tokens = array();
    foreach ($matches[0] as $match) {
        if (!preg_match('~^<\s*(/?)\s*([a-z][a-z0-9:-]*)\b~i', $match[0], $tag)) continue;
        $name = strtolower($tag[2]);
        $raw = in_array($name, array('script', 'style', 'textarea'), TRUE);
        $void = in_array($name, array('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'), TRUE);
        $tokens[] = array('text' => $match[0], 'start' => $match[1], 'end' => $match[1] + strlen($match[0]), 'name' => $name, 'close' => $tag[1] === '/', 'single' => $raw || $void || preg_match('~/\s*>$~', $match[0]));
    }
    return $tokens;
}

function klimat_product_cards_20261117_tag_class($tag, $class)
{
    if (!preg_match('~\sclass\s*=\s*(?:\x22([^\x22]*)\x22|\x27([^\x27]*)\x27|([^\s>]+))~i', $tag, $match)) return FALSE;
    $value = isset($match[3]) && $match[3] !== '' ? $match[3] : (isset($match[2]) && $match[2] !== '' ? $match[2] : $match[1]);
    return in_array($class, preg_split('~\s+~', html_entity_decode($value, ENT_QUOTES, 'UTF-8')), TRUE);
}

function klimat_product_cards_20261117_ranges($html, $selector)
{
    $tokens = klimat_product_cards_20261117_tokens($html);
    $ranges = array();
    foreach ($tokens as $index => $token) {
        if ($token['close'] || !$selector($token)) continue;
        if ($token['single']) { $ranges[] = $token; continue; }
        $depth = 1;
        for ($next = $index + 1, $count = count($tokens); $next < $count; $next++) {
            $candidate = $tokens[$next];
            if ($candidate['name'] !== $token['name'] || $candidate['single']) continue;
            $depth += $candidate['close'] ? -1 : 1;
            if ($depth === 0) {
                $token['end'] = $candidate['end'];
                $ranges[] = $token;
                break;
            }
        }
    }
    return $ranges;
}

/** Preserve original scripts, forms and purchase/variant blocks byte for byte. */
function klimat_product_cards_20261117_parse($fragment)
{
    if (strpos($fragment, 'KS_PDP_RAW_') !== FALSE) return NULL;
    $ranges = klimat_product_cards_20261117_ranges($fragment, static function ($token) {
        if (in_array($token['name'], array('script', 'style', 'textarea', 'form', 'input', 'button', 'select'), TRUE)) return TRUE;
        foreach (array('product-card__buttons', 'product-card__price-box', 'containeritem', 'complex') as $class) {
            if (klimat_product_cards_20261117_tag_class($token['text'], $class)) return TRUE;
        }
        return $token['name'] === 'a' && preg_match('~\bonclick\s*=~i', $token['text']);
    });
    usort($ranges, static function ($a, $b) { return $a['start'] === $b['start'] ? $b['end'] - $a['end'] : $a['start'] - $b['start']; });
    $outer = array(); $last = -1;
    foreach ($ranges as $range) {
        if ($range['start'] < $last) continue;
        $outer[] = $range; $last = $range['end'];
    }
    $restore = array();
    foreach (array_reverse($outer) as $index => $range) {
        $placeholder = '<!--KS_PDP_RAW_' . $index . '-->';
        $restore[$placeholder] = substr($fragment, $range['start'], $range['end'] - $range['start']);
        $fragment = substr_replace($fragment, $placeholder, $range['start'], $range['end'] - $range['start']);
    }
    $previous = libxml_use_internal_errors(TRUE);
    $doc = new DOMDocument('1.0', 'UTF-8');
    $loaded = $doc->loadHTML('<?xml encoding="UTF-8"><!doctype html><html><body>' . $fragment . '</body></html>', LIBXML_NONET);
    libxml_clear_errors(); libxml_use_internal_errors($previous);
    if (!$loaded) return NULL;
    $body = $doc->getElementsByTagName('body')->item(0);
    $root = NULL;
    foreach ($body->childNodes as $node) if ($node instanceof DOMElement) { $root = $node; break; }
    return $root ? array('doc' => $doc, 'root' => $root, 'restore' => $restore) : NULL;
}

function klimat_product_cards_20261117_query($parsed, $class, $root = NULL)
{
    $xp = new DOMXPath($parsed['doc']);
    return $xp->query('.//*[contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")]', $root ?: $parsed['root']);
}

function klimat_product_cards_20261117_el($doc, $tag, $class = '', $text = NULL)
{
    $node = $doc->createElement($tag);
    if ($class !== '') $node->setAttribute('class', $class);
    if ($text !== NULL) $node->appendChild($doc->createTextNode((string) $text));
    return $node;
}

function klimat_product_cards_20261117_url($value)
{
    if (!is_string($value) || !filter_var($value, FILTER_VALIDATE_URL)) return '';
    $url = parse_url($value);
    return isset($url['scheme'], $url['host']) && strtolower($url['scheme']) === 'https' && !isset($url['user']) && !isset($url['pass']) ? $value : '';
}

function klimat_product_cards_20261117_verified($row)
{
    if (!is_array($row) || !isset($row['source_url'], $row['checked_at']) || !is_string($row['checked_at']) || klimat_product_cards_20261117_url($row['source_url']) === '') return FALSE;
    if (!preg_match('~^(\d{4})-(\d{2})-(\d{2})$~D', $row['checked_at'], $date)) return FALSE;
    return checkdate((int) $date[2], (int) $date[3], (int) $date[1]);
}

/** Verified source labels and old import labels refer to the same physical field. */
function klimat_product_cards_20261117_spec_key($label)
{
    $aliases = array(
        'area' => 'площад',
        'consumption_cooling' => '(?:потребляемая мощность.*охлажд|потребление при охлажд)',
        'consumption_heating' => '(?:потребляемая мощность.*обогрев|потребление при обогрев)',
        'capacity_cooling' => '(?:охлаждение, номинальная мощность|мощность охлаждения|мощность \\(охлаждение\\)|холодопроизводительность)',
        'capacity_heating' => '(?:обогрев, номинальная мощность|мощность обогрева|мощность \\(обогрев\\)|теплопроизводительность)',
        'noise_inside' => '(?:уровень шума (?:в/б|внутреннего блока)|^уровень шума$)',
        'noise_outside' => 'уровень шума.*(?:наружн|внешн)',
        'inverter' => 'инвертор',
        'refrigerant' => 'хладагент',
        'efficiency' => '(?:класс энергоэффективности|класс энергопотребления)',
        'wifi' => 'wi.?fi',
        'airflow' => 'расход воздуха',
        'warranty' => 'гаранти',
        'line_length' => '(?:максимальная длина трассы|длина трассы.*макс)',
        'dimensions_inside' => '(?:габарит.*внутрен|размер.*внутрен)',
        'dimensions_outside' => '(?:габарит.*внешн|габарит.*наружн|размер.*внешн|размер.*наружн)',
        'weight_inside' => 'вес.*внутрен',
        'weight_outside' => 'вес.*(?:внешн|наружн)',
        'inside_type' => 'тип внутреннего блока',
        'power_supply' => 'электропитание',
        'remote' => 'пульт дистанционного управления'
    );
    foreach ($aliases as $key => $pattern) if (preg_match('~' . $pattern . '~ui', $label)) return $key;
    return klimat_product_cards_20261117_text($label);
}

function klimat_product_cards_20261117_group($label)
{
    if (preg_match('~габарит|вес|диаметр|трасс|магистра|перепад|размер|монтаж~ui', $label)) return 'Установка и габариты';
    if (preg_match('~потребляем|энерг|электропит~ui', $label)) return 'Энергоэффективность и питание';
    if (preg_match('~wi.?fi|пульт|шум|управл|режим|фильтр~ui', $label)) return 'Комфорт и управление';
    if (preg_match('~мощност|площад|производит|способност|расход воздуха|тип внутреннего~ui', $label)) return 'Основные параметры';
    return 'Дополнительные сведения';
}

function klimat_product_cards_20261117_specs($tabs, $entry)
{
    $rows = array();
    foreach (klimat_product_cards_20261117_query($tabs, 'shop_property') as $node) {
        $span = NULL; $label = '';
        foreach ($node->childNodes as $child) {
            if ($child instanceof DOMElement && strtolower($child->tagName) === 'span') { $span = $child; break; }
            $label .= $child->textContent;
        }
        if (!$span) continue;
        $label = rtrim(klimat_product_cards_20261117_text($label), ': ');
        $value = klimat_product_cards_20261117_text($span->textContent);
        if ($label === '' || $value === '') continue;
        $rows[] = array('label' => $label, 'value' => $value, 'node' => $node, 'value_node' => $span, 'group' => klimat_product_cards_20261117_group($label));
    }
    if (!empty($entry['specifications']) && is_array($entry['specifications'])) foreach ($entry['specifications'] as $extra) {
        if (!klimat_product_cards_20261117_verified($extra) || empty($extra['label']) || !isset($extra['value']) || !is_scalar($extra['value'])) continue;
        $label = klimat_product_cards_20261117_text($extra['label']); $value = klimat_product_cards_20261117_text($extra['value']);
        if ($label === '' || $value === '') continue;
        $found = NULL;
        $key = klimat_product_cards_20261117_spec_key($label);
        foreach ($rows as $index => $row) if (preg_match('~^' . preg_quote(klimat_product_cards_20261117_spec_key($row['label']), '~') . '$~ui', $key)) { $found = $index; break; }
        $row = array('label' => $label, 'value' => $value, 'group' => !empty($extra['group']) ? klimat_product_cards_20261117_text($extra['group']) : klimat_product_cards_20261117_group($label), 'source_url' => $extra['source_url'], 'checked_at' => $extra['checked_at']);
        if ($found === NULL) $rows[] = $row;
        else { if (isset($rows[$found]['node'])) $row['node'] = $rows[$found]['node']; $rows[$found] = $row; }
    }
    $verifiedArea = FALSE;
    foreach ($rows as $row) {
        if (isset($row['source_url']) && klimat_product_cards_20261117_spec_key($row['label']) === 'area') {
            $verifiedArea = TRUE;
            break;
        }
    }
    if ($verifiedArea) {
        foreach ($rows as &$row) {
            if (!isset($row['source_url']) && preg_match('~охлаждающая способность.*btu~ui', $row['label'])) {
                $row['value'] = trim(preg_replace('~\s*\([^)]*\)\s*$~u', '', $row['value']));
                unset($row['value_node']);
            }
        }
        unset($row);
    }
    return $rows;
}

function klimat_product_cards_20261117_image($row, $id)
{
    if (!is_array($row) || !isset($row['src']) || !is_string($row['src'])) return NULL;
    $pattern = '~^/assets/product-cards-20261117/images/' . preg_quote((string) $id, '~') . '/[a-zA-Z0-9_-]+\.(?:webp|jpe?g|png|avif)$~D';
    if (!preg_match($pattern, $row['src'])) return NULL;
    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : '';
    if ($docRoot !== '' && (!is_file($docRoot . $row['src']) || is_link($docRoot . $row['src']))) return NULL;
    $row['thumb'] = isset($row['thumb']) && is_string($row['thumb']) && preg_match($pattern, $row['thumb']) && ($docRoot === '' || is_file($docRoot . $row['thumb'])) ? $row['thumb'] : $row['src'];
    return $row;
}

function klimat_product_cards_20261117_set_image($image, $row, $name, $thumb = FALSE)
{
    $image->setAttribute('src', $thumb ? $row['thumb'] : $row['src']);
    $image->removeAttribute('srcset'); $image->removeAttribute('sizes');
    $image->setAttribute('alt', isset($row['alt']) && is_string($row['alt']) && $row['alt'] !== '' ? $row['alt'] : $name);
    if (isset($row['width'], $row['height']) && is_numeric($row['width']) && is_numeric($row['height']) && $row['width'] > 0 && $row['height'] > 0) {
        $image->setAttribute('width', (string) (int) $row['width']); $image->setAttribute('height', (string) (int) $row['height']);
    }
    $image->setAttribute('decoding', 'async');
    if (!$thumb) {
        $image->setAttribute('data-ks-photo-full', $row['src']);
        $image->setAttribute('data-ks-photo-source', $row['src']);
    }
}

/** Resolve only the exact native small/full pair in the current item's directory. */
function klimat_product_cards_20261117_native_full($src, $id, $documentRoot = NULL)
{
    if (!is_string($src) || !preg_match('~^/upload/shop_1/(?:[0-9]+/)*item_([0-9]+)/small_(item_image([0-9]+)|shop_property_file_[0-9]+_[0-9]+)\.(jpe?g|png|webp|avif)$~iD', $src, $match) || $match[1] !== (string) $id) return '';
    if (isset($match[3]) && $match[3] !== '' && $match[3] !== (string) $id) return '';
    $rootValue = $documentRoot === NULL ? (isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '') : $documentRoot;
    if (!is_string($rootValue) || $rootValue === '') return '';
    $root = realpath($rootValue);
    if (!$root || $root === DIRECTORY_SEPARATOR) return '';
    $full = dirname($src) . '/' . $match[2] . '.' . $match[4];
    foreach (array($src, $full) as $url) {
        $path = $root;
        foreach (explode('/', ltrim($url, '/')) as $part) {
            $path .= '/' . $part;
            if (is_link($path)) return '';
        }
        if (!is_file($path) || realpath($path) !== $path) return '';
    }
    $smallInfo = @getimagesize($root . $src); $largeInfo = @getimagesize($root . $full);
    if (!$smallInfo || !$largeInfo || $largeInfo[0] < $smallInfo[0] || $largeInfo[1] < $smallInfo[1] || !in_array($largeInfo['mime'], array('image/jpeg', 'image/png', 'image/webp', 'image/avif'), TRUE)) return '';
    return $full;
}

/** Wrap a complete known native purchase skeleton without parsing its raw controls. */
function klimat_product_cards_20261117_buy_layout($parsed)
{
    $root = $parsed['root']; $rights = klimat_product_cards_20261117_query($parsed, 'product-card__right');
    if ($rights->length !== 1) return FALSE;
    $right = $rights->item(0);
    if ($right->parentNode !== $root) return FALSE;
    $details = NULL; $summary = NULL; $price = NULL; $buttons = 0; $cartIds = 0; $move = array();
    foreach ($right->childNodes as $node) {
        if (klimat_product_cards_20261117_has_class($node, 'product-card__details')) {
            if ($details !== NULL) return FALSE;
            $details = $node; continue;
        }
        if (klimat_product_cards_20261117_has_class($node, 'ks-pdp-summary')) {
            if ($summary !== NULL) return FALSE;
            $summary = $node; continue;
        }
        if ($node instanceof DOMText && trim($node->nodeValue) === '') continue;
        if ($node instanceof DOMComment) {
            $key = '<!--' . $node->nodeValue . '-->';
            if (!isset($parsed['restore'][$key])) continue;
            $raw = $parsed['restore'][$key]; $tokens = klimat_product_cards_20261117_tokens($raw);
            if (!$tokens) return FALSE;
            $tag = $tokens[0];
            if (klimat_product_cards_20261117_tag_class($tag['text'], 'product-card__buttons')) { $buttons++; $move[] = $node; continue; }
            if (klimat_product_cards_20261117_tag_class($tag['text'], 'containeritem')) { $move[] = $node; continue; }
            if ($tag['name'] === 'input' && klimat_product_cards_20261117_tag_class($tag['text'], 'cartitemid')) { $cartIds++; $move[] = $node; continue; }
            if ($tag['name'] === 'form' && preg_match('~\sid\s*=\s*(?:\x22complex_form\x22|\x27complex_form\x27|complex_form(?=[\s>]))~i', $tag['text'])) { $move[] = $node; continue; }
            return FALSE;
        }
        if ($node instanceof DOMElement && ((strtolower($node->tagName) === 'p' && preg_match('~^Артикул\s*:~ui', klimat_product_cards_20261117_text($node->textContent))) || klimat_product_cards_20261117_has_class($node, 'product-card__informer') || klimat_product_cards_20261117_has_class($node, 'product-card__warranty'))) { $move[] = $node; continue; }
        // An unfamiliar right-column skeleton retains its original structure.
        return FALSE;
    }
    if (!$details || $buttons !== 1 || $cartIds !== 1) return FALSE;
    foreach ($details->childNodes as $node) {
        if ($node instanceof DOMText && trim($node->nodeValue) === '') continue;
        if (klimat_product_cards_20261117_has_class($node, 'product-card__name--desktop') || klimat_product_cards_20261117_has_class($node, 'ks-pdp-reviews-link') || ($node instanceof DOMElement && strtolower($node->tagName) === 'h1')) continue;
        if ($node instanceof DOMComment) {
            $key = '<!--' . $node->nodeValue . '-->';
            if (!isset($parsed['restore'][$key])) continue;
            $tokens = klimat_product_cards_20261117_tokens($parsed['restore'][$key]);
            if ($tokens && klimat_product_cards_20261117_tag_class($tokens[0]['text'], 'product-card__price-box') && $price === NULL) { $price = $node; continue; }
        }
        return FALSE;
    }
    if (!$price || !$details->getElementsByTagName('h1')->length) return FALSE;
    $box = klimat_product_cards_20261117_el($parsed['doc'], 'section', 'ks-pdp-buy-box');
    $box->setAttribute('aria-label', 'Цена и покупка');
    $right->insertBefore($box, $summary);
    $box->appendChild($price);
    foreach ($move as $node) $box->appendChild($node);
    klimat_product_cards_20261117_class($root, 'ks-pdp-has-buy-layout');
    return TRUE;
}

function klimat_product_cards_20261117_short_specs($rows)
{
    $selected = array(); $used = array();
    $coolingPattern = 'охлаждающая способность';
    $hasInsideNoise = FALSE;
    foreach ($rows as $row) {
        if (klimat_product_cards_20261117_spec_key($row['label']) === 'noise_inside') $hasInsideNoise = TRUE;
        if (klimat_product_cards_20261117_spec_key($row['label']) === 'capacity_cooling') {
            $coolingPattern = 'охлаждение, номинальная мощность|мощность охлаждения|холодопроизводительность';
        }
    }
    foreach (array('площад', $coolingPattern, 'инвертор', 'уровень шума', 'wi.?fi', 'гаранти') as $pattern) {
        foreach ($rows as $index => $row) if (!isset($used[$index]) && preg_match('~' . $pattern . '~ui', $row['label'])) {
            // The short indoor-comfort facts must not select the outdoor unit's
            // noise merely because the import placed that row first.
            if ($pattern === 'уровень шума' && $hasInsideNoise && klimat_product_cards_20261117_spec_key($row['label']) !== 'noise_inside') continue;
            $selected[] = $row; $used[$index] = TRUE; break;
        }
    }
    foreach ($rows as $index => $row) {
        if (count($selected) >= 6) break;
        if ($hasInsideNoise && preg_match('~уровень шума~ui', $row['label']) && klimat_product_cards_20261117_spec_key($row['label']) !== 'noise_inside') continue;
        if (!isset($used[$index])) $selected[] = $row;
    }
    return array_slice($selected, 0, 6);
}

function klimat_product_cards_20261117_dl($doc, $rows, $class)
{
    $dl = klimat_product_cards_20261117_el($doc, 'dl', $class);
    foreach ($rows as $row) {
        $item = klimat_product_cards_20261117_el($doc, 'div');
        $item->appendChild(klimat_product_cards_20261117_el($doc, 'dt', '', $row['label']));
        $item->appendChild(klimat_product_cards_20261117_el($doc, 'dd', '', $row['value']));
        $dl->appendChild($item);
    }
    return $dl;
}

function klimat_product_cards_20261117_action_buttons($html)
{
    $placeholder = '~\shref\s*=\s*([\x22\x27])javascript:void\(0\);?\1~i';
    $actions = klimat_product_cards_20261117_ranges($html, static function ($token) use ($placeholder) {
        if ($token['name'] !== 'a' || !preg_match($placeholder, $token['text'])) return FALSE;
        if (klimat_product_cards_20261117_tag_class($token['text'], 'product-card__button--buy')) {
            return preg_match('~\sonclick\s*=\s*[\x22\x27]\s*return\s+fastorder\(~i', $token['text']);
        }
        return klimat_product_cards_20261117_tag_class($token['text'], 'product-card__wish-list-link')
            && preg_match('~\sonclick\s*=\s*[\x22\x27]\s*return\s+\$\.addFavorite\(~', $token['text']);
    });
    foreach (array_reverse($actions) as $action) {
        $fragment = substr($html, $action['start'], $action['end'] - $action['start']);
        $opening = preg_replace($placeholder, '', $action['text'], 1);
        $opening = preg_replace('~^<a\b~i', '<button type="button"', $opening, 1);
        $replacement = $opening . preg_replace('~</a\s*>$~i', '</button>', substr($fragment, strlen($action['text'])), 1, $closed);
        if ($closed === 1) $html = substr_replace($html, $replacement, $action['start'], $action['end'] - $action['start']);
    }
    return $html;
}

function klimat_product_cards_20261117_card($parsed, $id, $name, $rows, $entry)
{
    $doc = $parsed['doc']; $root = $parsed['root'];
    klimat_product_cards_20261117_class($root, 'ks-pdp-enhanced');
    $root->setAttribute('data-ks-product-card', (string) $id);
    $headingBox = klimat_product_cards_20261117_query($parsed, 'product-card__name--desktop')->item(0);
    if (!$headingBox) $headingBox = $root->getElementsByTagName('h1')->item(0);
    if ($headingBox && $headingBox->parentNode) {
        $reviewLabel = 'Отзывы и оценки';
        // A numeric headline requires an explicitly verified exact-model pool.
        // Retain the previously verified 7701 source while old manifests lack
        // the new flag; an explicit FALSE always disables that compatibility.
        if (!empty($entry['external_reviews']) && is_array($entry['external_reviews'])) foreach ($entry['external_reviews'] as $review) {
            if (!klimat_product_cards_20261117_verified($review) || empty($review['source_name']) || !is_string($review['source_name'])) continue;
            $legacyExact = (string) $id === '7701' && $review['source_name'] === 'Технопарк' && !array_key_exists('exact_model_match', $review);
            $exact = (isset($review['exact_model_match']) && $review['exact_model_match'] === TRUE) || $legacyExact;
            $reviewCount = isset($review['review_count']) && (is_int($review['review_count']) || is_string($review['review_count'])) && filter_var($review['review_count'], FILTER_VALIDATE_INT) !== FALSE && $review['review_count'] > 0 ? (int) $review['review_count'] : 0;
            $ratingCount = isset($review['rating_count']) && (is_int($review['rating_count']) || is_string($review['rating_count'])) && filter_var($review['rating_count'], FILTER_VALIDATE_INT) !== FALSE && $review['rating_count'] > 0 ? (int) $review['rating_count'] : 0;
            if (!$exact || ($reviewCount === 0 && $ratingCount === 0) || !isset($review['rating'], $review['rating_scale']) || !is_numeric($review['rating']) || !is_numeric($review['rating_scale']) || $review['rating_scale'] <= 0 || $review['rating_scale'] > 10 || $review['rating'] <= 0 || $review['rating'] > $review['rating_scale']) continue;
            if ((string) $id === '7701' && $review['source_name'] === 'Технопарк' && $reviewCount > 0) {
                $reviewLabel = number_format((float) $review['rating'], 1, ',', '') . ' из ' . $review['rating_scale'] . ' · ' . $reviewCount . ' отзывов на Технопарке';
            } else {
                $reviewLabel = str_replace('.', ',', (string) $review['rating']) . ' из ' . $review['rating_scale'] . ' · ' . $review['source_name'];
            }
            break;
        }
        $reviewLink = klimat_product_cards_20261117_el($doc, 'a', 'ks-pdp-reviews-link', $reviewLabel);
        $reviewLink->setAttribute('href', '#tabs-ks-reviews'); $reviewLink->setAttribute('data-ks-open-tab', 'tabs-ks-reviews');
        $headingBox->parentNode->insertBefore($reviewLink, $headingBox->nextSibling);
    }
    $short = klimat_product_cards_20261117_short_specs($rows);
    $right = klimat_product_cards_20261117_query($parsed, 'product-card__right')->item(0);
    if ($right && $short) {
        $summary = klimat_product_cards_20261117_el($doc, 'section', 'ks-pdp-summary');
        $summary->appendChild(klimat_product_cards_20261117_el($doc, 'h2', '', 'Коротко о модели'));
        $summary->appendChild(klimat_product_cards_20261117_dl($doc, $short, 'ks-pdp-summary__facts'));
        $link = klimat_product_cards_20261117_el($doc, 'a', 'ks-pdp-all-specs', 'Все характеристики');
        $link->setAttribute('href', '#tabs-2'); $link->setAttribute('data-ks-open-tab', 'tabs-2');
        $summary->appendChild($link); $right->appendChild($summary);
    }
    $benefits = array(); $verifiedImages = array();
    if (!empty($entry['benefits']) && is_array($entry['benefits'])) foreach ($entry['benefits'] as $benefit) {
        if (!klimat_product_cards_20261117_verified($benefit) || empty($benefit['title']) || empty($benefit['text'])) continue;
        $benefits[] = $benefit;
        if (count($benefits) >= 4) break;
    }
    $wrapper = klimat_product_cards_20261117_query($parsed, 'product-card__gallery')->item(0);
    $gallery = klimat_product_cards_20261117_query($parsed, 'gallery')->item(0);
    $thumbs = klimat_product_cards_20261117_query($parsed, 'gallery-side')->item(0);
    if ($wrapper && $gallery) {
        $wrapper->setAttribute('data-ks-product-gallery', (string) $id);
        $photoCount = 0; $photoImages = array(); $thumbImages = array(); $variantImages = FALSE;
        foreach (klimat_product_cards_20261117_query($parsed, 'gallery__item', $gallery) as $slide) {
            $slide->setAttribute('data-ks-gallery-slide', ''); $slide->setAttribute('data-ks-slide-kind', 'photo');
            foreach ($slide->getElementsByTagName('img') as $image) {
                $photoCount++;
                $photoImages[] = $image;
                if ($image->hasAttribute('id') && $image->getAttribute('id') !== '') $variantImages = TRUE;
                if (!$image->hasAttribute('id')) $image->setAttribute('data-ks-pdp-photo', '1');
                if (!$image->hasAttribute('id') && !$image->hasAttribute('data-ks-photo-full')) {
                    $full = klimat_product_cards_20261117_native_full($image->getAttribute('src'), $id);
                    if ($full !== '') {
                        $image->setAttribute('data-ks-photo-full', $full);
                        $image->setAttribute('data-ks-photo-source', $image->getAttribute('src'));
                    }
                }
                if ($image->getAttribute('alt') === '') $image->setAttribute('alt', $name . ' — фото ' . $photoCount);
            }
        }
        if ($thumbs) foreach ($thumbs->getElementsByTagName('img') as $image) $thumbImages[] = $image;
        if (!empty($entry['images']) && is_array($entry['images']) && !klimat_product_cards_20261117_has_class($gallery, 'slick-initialized')) {
            $images = array();
            foreach ($entry['images'] as $candidate) { $valid = klimat_product_cards_20261117_image($candidate, $id); if ($valid) $images[] = $valid; }
            $verifiedImages = $images;
            $preserveNative = isset($entry['image_strategy']) && $entry['image_strategy'] === 'preserve_native';
            // A variant-specific photo must never be replaced by a generic model photo.
            // For variants, append supplementary photographs after all native images.
            $replaceCount = $variantImages ? 0 : min(count($images), count($photoImages));
            if ($preserveNative) $replaceCount = min($replaceCount, 1);
            for ($index = 0; $index < $replaceCount; $index++) {
                klimat_product_cards_20261117_set_image($photoImages[$index], $images[$index], $name);
                if (isset($thumbImages[$index])) klimat_product_cards_20261117_set_image($thumbImages[$index], $images[$index], $name, TRUE);
            }
            if ($images && !$variantImages) {
                // Enriched products use the verified gallery only. Keep originals
                // as fallback whenever no verified file is available on disk.
                for ($index = count($images), $count = count($photoImages); !$preserveNative && $index < $count; $index++) {
                    $image = $photoImages[$index]; $slide = $image->parentNode;
                    while ($slide && $slide !== $gallery && !klimat_product_cards_20261117_has_class($slide, 'gallery__item')) $slide = $slide->parentNode;
                    if ($slide && $slide !== $gallery && $slide->parentNode) $slide->parentNode->removeChild($slide);
                    if (isset($thumbImages[$index])) {
                        $thumb = $thumbImages[$index]->parentNode;
                        while ($thumb && $thumb !== $thumbs && !klimat_product_cards_20261117_has_class($thumb, 'gallery-side__item')) $thumb = $thumb->parentNode;
                        if ($thumb && $thumb !== $thumbs && $thumb->parentNode) $thumb->parentNode->removeChild($thumb);
                    }
                }
                foreach ($root->getElementsByTagName('link') as $link) if ($link->getAttribute('itemprop') === 'image') { $link->setAttribute('href', 'https://klimat5ervis.ru' . $images[0]['src']); break; }
            }
            for ($index = $replaceCount, $count = count($images); $index < $count; $index++) {
                $slide = klimat_product_cards_20261117_el($doc, 'div', 'gallery__item'); $slide->setAttribute('data-ks-gallery-slide', ''); $slide->setAttribute('data-ks-slide-kind', 'photo');
                $image = klimat_product_cards_20261117_el($doc, 'img'); klimat_product_cards_20261117_set_image($image, $images[$index], $name); $image->setAttribute('loading', 'lazy'); $slide->appendChild($image); $gallery->appendChild($slide);
                if ($thumbs) { $thumb = klimat_product_cards_20261117_el($doc, 'div', 'gallery-side__item'); $image = klimat_product_cards_20261117_el($doc, 'img'); klimat_product_cards_20261117_set_image($image, $images[$index], $name, TRUE); $image->setAttribute('loading', 'lazy'); $thumb->appendChild($image); $thumbs->appendChild($thumb); }
            }
        }
        // Existing variant indices count gallery images; information slides have no img.
        if (($short || $benefits) && !klimat_product_cards_20261117_has_class($gallery, 'slick-initialized')) {
            $slide = klimat_product_cards_20261117_el($doc, 'div', 'gallery__item ks-pdp-info-slide');
            $slide->setAttribute('data-ks-gallery-slide', ''); $slide->setAttribute('data-ks-slide-kind', 'info');
            $slide->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-info-slide__eyebrow', 'О модели'));
            $visualSrc = $verifiedImages ? $verifiedImages[0]['src'] : '';
            if ($visualSrc === '' && isset($photoImages[0])) {
                $nativeSrc = $photoImages[0]->getAttribute('src');
                $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : '';
                if (preg_match('~^/(?:assets|upload)/[a-zA-Z0-9_./%+-]+\.(?:webp|jpe?g|png|avif)$~D', $nativeSrc) && strpos(rawurldecode($nativeSrc), '..') === FALSE && ($docRoot === '' || is_file($docRoot . $nativeSrc))) $visualSrc = $nativeSrc;
            }
            if ($visualSrc !== '') {
                $visual = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-info-visual');
                $visual->setAttribute('role', 'img'); $visual->setAttribute('aria-label', $name);
                $visual->setAttribute('style', 'background-image:url(' . $visualSrc . ')');
                $slide->appendChild($visual);
                klimat_product_cards_20261117_class($slide, 'ks-pdp-info-slide--visual');
            }
            $content = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-info-slide__content');
            $content->appendChild(klimat_product_cards_20261117_el($doc, 'h3', '', $benefits ? 'Преимущества модели' : 'Главные характеристики'));
            if ($benefits) {
                $features = klimat_product_cards_20261117_el($doc, 'ul', 'ks-pdp-info-slide__benefits');
                foreach (array_slice($benefits, 0, 2) as $benefit) {
                    $feature = klimat_product_cards_20261117_el($doc, 'li');
                    $feature->appendChild(klimat_product_cards_20261117_el($doc, 'strong', '', $benefit['title']));
                    $feature->appendChild(klimat_product_cards_20261117_el($doc, 'span', '', $benefit['text']));
                    $features->appendChild($feature);
                }
                $content->appendChild($features);
            } else $content->appendChild(klimat_product_cards_20261117_dl($doc, array_slice($short, 0, 4), 'ks-pdp-info-slide__facts'));
            $slide->appendChild($content);
            $gallery->appendChild($slide);
            if ($thumbs) {
                $thumb = klimat_product_cards_20261117_el($doc, 'div', 'gallery-side__item ks-pdp-info-thumb');
                $thumb->setAttribute('aria-label', $benefits ? 'Преимущества модели' : 'Параметры модели');
                $thumb->appendChild(klimat_product_cards_20261117_el($doc, 'span', '', $benefits ? 'Преимущества' : 'Параметры'));
                $thumbs->appendChild($thumb);
            }
        }
        $help = klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-gallery-help', 'Нажмите на фотографию, чтобы увеличить');
        $wrapper->appendChild($help);
        $total = klimat_product_cards_20261117_query($parsed, 'gallery__item', $gallery)->length;
        if ($total > 0) {
            $controls = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-gallery-controls');
            foreach (array('prev' => 'Предыдущий слайд', 'next' => 'Следующий слайд') as $direction => $label) {
                if ($direction === 'next') {
                    $counter = klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-gallery-count', '1 / ' . $total);
                    $counter->setAttribute('data-ks-gallery-count', ''); $counter->setAttribute('aria-live', 'polite'); $controls->appendChild($counter);
                }
                $button = klimat_product_cards_20261117_el($doc, 'button', '', $direction === 'prev' ? '←' : '→');
                $button->setAttribute('type', 'button'); $button->setAttribute('data-ks-gallery-' . $direction, ''); $button->setAttribute('aria-label', $label); $controls->appendChild($button);
            }
            $wrapper->appendChild($controls);
        }
    }
    klimat_product_cards_20261117_buy_layout($parsed);
    return klimat_product_cards_20261117_action_buttons(strtr($doc->saveHTML($root), $parsed['restore']));
}

function klimat_product_cards_20261117_tabs($parsed, $rows, $entry)
{
    $doc = $parsed['doc']; $root = $parsed['root']; $xp = new DOMXPath($doc);
    klimat_product_cards_20261117_class($root, 'ks-pdp-tabs');
    $description = $xp->query('.//*[@id="tabs-1"]', $root)->item(0);
    if ($description && !empty($entry['description']) && is_array($entry['description']) && !empty($entry['description_source']) && klimat_product_cards_20261117_verified($entry['description_source'])) {
        $paragraphs = array();
        foreach ($entry['description'] as $paragraph) if (is_string($paragraph) && klimat_product_cards_20261117_text($paragraph) !== '') $paragraphs[] = $paragraph;
        if ($paragraphs) {
            $protected = array();
            foreach ($xp->query('.//comment()', $description) as $comment) if (strpos($comment->nodeValue, 'KS_PDP_RAW_') === 0) $protected[] = $comment->cloneNode(TRUE);
            while ($description->firstChild) $description->removeChild($description->firstChild);
            foreach ($paragraphs as $paragraph) $description->appendChild(klimat_product_cards_20261117_el($doc, 'p', '', $paragraph));
            $source = klimat_product_cards_20261117_el($doc, 'a', 'ks-pdp-description-source', 'Подробнее о модели у производителя или официального поставщика');
            $source->setAttribute('href', $entry['description_source']['source_url']); $source->setAttribute('target', '_blank'); $source->setAttribute('rel', 'noopener noreferrer'); $source->setAttribute('title', 'Проверено ' . $entry['description_source']['checked_at']); $description->appendChild($source);
            foreach ($protected as $node) $description->appendChild($node);
        }
    }
    $specs = $xp->query('.//*[@id="tabs-2"]', $root)->item(0);
    if ($specs && $rows) {
        $toolbar = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-spec-toolbar');
        $label = klimat_product_cards_20261117_el($doc, 'label', '', 'Найти характеристику');
        $search = klimat_product_cards_20261117_el($doc, 'input');
        $search->setAttribute('type', 'search'); $search->setAttribute('data-ks-spec-search', ''); $search->setAttribute('placeholder', 'Например, шум или размеры');
        $label->appendChild($search); $toolbar->appendChild($label);
        $counter = klimat_product_cards_20261117_el($doc, 'p', '', 'Характеристик: ' . count($rows));
        $counter->setAttribute('data-ks-spec-count', ''); $counter->setAttribute('aria-live', 'polite'); $toolbar->appendChild($counter);
        $specs->insertBefore($toolbar, $specs->firstChild);
        $groups = array();
        foreach ($rows as $row) $groups[$row['group']][] = $row;
        foreach ($groups as $name => $groupRows) {
            $section = klimat_product_cards_20261117_el($doc, 'section', 'ks-pdp-spec-group');
            $section->setAttribute('data-ks-spec-group', ''); $section->appendChild(klimat_product_cards_20261117_el($doc, 'h2', '', $name));
            $dl = klimat_product_cards_20261117_el($doc, 'dl');
            foreach ($groupRows as $row) {
                $item = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-spec-row'); $item->setAttribute('data-ks-spec-row', '');
                $item->appendChild(klimat_product_cards_20261117_el($doc, 'dt', '', $row['label']));
                $dd = klimat_product_cards_20261117_el($doc, 'dd');
                if (isset($row['value_node'])) foreach ($row['value_node']->childNodes as $child) $dd->appendChild($child->cloneNode(TRUE));
                else $dd->appendChild($doc->createTextNode($row['value']));
                if (isset($row['source_url'])) {
                    $link = klimat_product_cards_20261117_el($doc, 'a', 'ks-pdp-fact-source', 'Источник');
                    $link->setAttribute('href', $row['source_url']); $link->setAttribute('target', '_blank'); $link->setAttribute('rel', 'noopener noreferrer'); $link->setAttribute('title', 'Проверено ' . $row['checked_at']); $dd->appendChild($link);
                }
                $item->appendChild($dd); $dl->appendChild($item);
            }
            $section->appendChild($dl); $specs->appendChild($section);
        }
        foreach ($rows as $row) if (isset($row['node']) && $row['node']->parentNode) $row['node']->parentNode->removeChild($row['node']);
        $empty = klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-spec-empty', 'Характеристики не найдены. Попробуйте другое слово.');
        $empty->setAttribute('data-ks-spec-empty', ''); $empty->setAttribute('hidden', 'hidden'); $specs->appendChild($empty);
    }
    $head = klimat_product_cards_20261117_query($parsed, 'product-tabs__head')->item(0);
    if ($head && !$xp->query('.//*[@id="tabs-ks-reviews"]', $root)->length) {
        $li = klimat_product_cards_20261117_el($doc, 'li');
        $link = klimat_product_cards_20261117_el($doc, 'a', '', 'Отзывы и оценки'); $link->setAttribute('href', '#tabs-ks-reviews'); $li->appendChild($link); $head->appendChild($li);
        $panel = klimat_product_cards_20261117_el($doc, 'div', 'product-tabs__content ks-pdp-reviews'); $panel->setAttribute('id', 'tabs-ks-reviews');
        $panel->appendChild(klimat_product_cards_20261117_el($doc, 'h2', '', 'Отзывы на внешних площадках'));
        $verified = 0;
        if (!empty($entry['external_reviews']) && is_array($entry['external_reviews'])) foreach ($entry['external_reviews'] as $review) {
            if (!klimat_product_cards_20261117_verified($review) || empty($review['source_name'])) continue;
            $verified++;
            $item = klimat_product_cards_20261117_el($doc, 'section', 'ks-pdp-review-source');
            $h = klimat_product_cards_20261117_el($doc, 'h3');
            $a = klimat_product_cards_20261117_el($doc, 'a', '', $review['source_name']); $a->setAttribute('href', $review['source_url']); $a->setAttribute('target', '_blank'); $a->setAttribute('rel', 'noopener noreferrer'); $h->appendChild($a); $item->appendChild($h);
            if (isset($review['rating'], $review['rating_scale']) && is_numeric($review['rating']) && is_numeric($review['rating_scale']) && $review['rating_scale'] > 0 && $review['rating_scale'] <= 10 && $review['rating'] >= 0 && $review['rating'] <= $review['rating_scale']) {
                $rating = 'Оценка на площадке: ' . str_replace('.', ',', (string) $review['rating']) . ' из ' . str_replace('.', ',', (string) $review['rating_scale']);
                if (isset($review['rating_count']) && filter_var($review['rating_count'], FILTER_VALIDATE_INT) !== FALSE && $review['rating_count'] >= 0) $rating .= ' · Оценок: ' . $review['rating_count'];
                if (isset($review['review_count']) && filter_var($review['review_count'], FILTER_VALIDATE_INT) !== FALSE && $review['review_count'] >= 0) $rating .= ' · Отзывов: ' . $review['review_count'];
                $item->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-external-rating', $rating));
            }
            if (!empty($review['summary'])) $item->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-summary', $review['summary']));
            if (!empty($review['scope_note']) && is_string($review['scope_note'])) $item->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-scope', $review['scope_note']));
            if (!empty($review['review_summaries']) && is_array($review['review_summaries'])) {
                $summaries = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-review-paraphrases');
                $shown = 0;
                foreach ($review['review_summaries'] as $summary) {
                    if (!is_array($summary) || empty($summary['summary']) || !is_string($summary['summary'])) continue;
                    $sourceUrl = isset($summary['source_url']) ? klimat_product_cards_20261117_url($summary['source_url']) : '';
                    if ($sourceUrl === '') continue;
                    $card = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-review-paraphrase');
                    $card->appendChild(klimat_product_cards_20261117_el($doc, 'h4', '', 'Краткий пересказ отзыва'));
                    $card->appendChild(klimat_product_cards_20261117_el($doc, 'p', '', $summary['summary']));
                    if (!empty($summary['date_display']) && is_string($summary['date_display'])) $card->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-date', 'Дата на площадке: ' . $summary['date_display']));
                    $source = klimat_product_cards_20261117_el($doc, 'a', 'ks-pdp-review-original', 'Читать на площадке «' . $review['source_name'] . '»');
                    $source->setAttribute('href', $sourceUrl); $source->setAttribute('target', '_blank'); $source->setAttribute('rel', 'noopener noreferrer'); $card->appendChild($source);
                    $summaries->appendChild($card);
                    $shown++; if ($shown >= 2) break;
                }
                if ($shown) $item->appendChild($summaries);
            }
            $date = klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-date', 'Проверено: ');
            $time = klimat_product_cards_20261117_el($doc, 'time', '', $review['checked_at']); $time->setAttribute('datetime', $review['checked_at']); $date->appendChild($time); $item->appendChild($date); $panel->appendChild($item);
        }
        if ($verified) $note = 'Это оценки и отзывы внешних площадок. Состав модификаций уточнён у каждого источника. Данные и число отзывов могут меняться.';
        else $note = 'Проверенные внешние отзывы об этой модели пока не добавлены.';
        $panel->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-note', $note));
        $root->appendChild($panel);
    }
    return strtr($doc->saveHTML($root), $parsed['restore']);
}

/**
 * Optional single-product data. Legacy curated records remain the baseline;
 * a matching per-ID record replaces only its explicitly supplied fields.
 * This reader never creates files, directories, caches or network requests.
 */
function klimat_product_cards_20261117_load_entry($id, $name, $dataDir = NULL)
{
    $id = (string) $id;
    if (!preg_match('~^[0-9]{1,12}$~D', $id) || !is_string($name) || $name === '') return array();
    $dataDir = $dataDir === NULL ? __DIR__ . '/data' : rtrim($dataDir, '/');
    $read = static function ($file, $limit) {
        if (!is_file($file) || is_link($file)) return NULL;
        $size = @filesize($file);
        if ($size === FALSE || $size < 2 || $size >= $limit) return NULL;
        $raw = @file_get_contents($file, FALSE, NULL, 0, $limit);
        if (!is_string($raw) || strlen($raw) >= $limit) return NULL;
        $data = json_decode($raw, TRUE);
        return is_array($data) ? $data : NULL;
    };
    // Keep the existing size ceiling and schema for the small curated baseline.
    $legacy = $read($dataDir . '/products.json', 2097152);
    $base = isset($legacy['products'][$id]) && is_array($legacy['products'][$id]) ? $legacy['products'][$id] : array();
    if (!isset($base['native_name']) || !is_string($base['native_name']) || klimat_product_cards_20261117_text($base['native_name']) !== klimat_product_cards_20261117_text($name)) $base = array();
    $itemsDir = $dataDir . '/items';
    if (is_link($dataDir) || is_link($itemsDir) || !is_dir($itemsDir)) return $base;
    $entry = $read($itemsDir . '/' . $id . '.json', 262144);
    if (!is_array($entry) || !isset($entry['native_name']) || !is_string($entry['native_name']) || klimat_product_cards_20261117_text($entry['native_name']) !== klimat_product_cards_20261117_text($name)) return $base;
    if (isset($entry['item_id']) && ((!is_int($entry['item_id']) && !is_string($entry['item_id'])) || (string) $entry['item_id'] !== $id)) return $base;
    return array_replace($base, $entry);
}

/** Call once in common shell finish, before technical SEO/image transforms. */
function klimat_product_cards_20261117_finish($html, $path = NULL, $manifest = NULL)
{
    if (!is_string($html) || !class_exists('DOMDocument') || strpos($html, 'data-ks-product-card=') !== FALSE) return $html;
    if ($path === NULL) $path = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    if (!is_string($path) || !preg_match('~^/category/(?:[^/]+/)*([0-9]+)/$~D', $path, $match)) return $html;
    $id = $match[1];
    $cards = klimat_product_cards_20261117_ranges($html, static function ($token) { return $token['name'] === 'div' && klimat_product_cards_20261117_tag_class($token['text'], 'product-card'); });
    $tabRanges = klimat_product_cards_20261117_ranges($html, static function ($token) { return $token['name'] === 'div' && klimat_product_cards_20261117_tag_class($token['text'], 'product-tabs'); });
    if (count($cards) !== 1 || count($tabRanges) !== 1 || $cards[0]['end'] > $tabRanges[0]['start']) return $html;
    $original = $html;
    try {
        $card = klimat_product_cards_20261117_parse(substr($html, $cards[0]['start'], $cards[0]['end'] - $cards[0]['start']));
        $tabs = klimat_product_cards_20261117_parse(substr($html, $tabRanges[0]['start'], $tabRanges[0]['end'] - $tabRanges[0]['start']));
        if (!$card || !$tabs) return $html;
        $heading = $card['root']->getElementsByTagName('h1')->item(0);
        $name = $heading ? klimat_product_cards_20261117_text($heading->textContent) : '';
        if ($name === '') return $html;
        // Product offer URL, when present, must agree with the numeric route.
        foreach ($card['root']->getElementsByTagName('link') as $link) if ($link->getAttribute('itemprop') === 'url') {
            $offerPath = parse_url($link->getAttribute('href'), PHP_URL_PATH);
            if (is_string($offerPath) && preg_match('~/(\d+)/$~D', $offerPath, $offerId) && $offerId[1] !== $id) return $html;
        }
        if ($manifest === NULL) {
            $entry = klimat_product_cards_20261117_load_entry($id, $name);
        } else {
            $entry = isset($manifest['products'][$id]) && is_array($manifest['products'][$id]) ? $manifest['products'][$id] : array();
        }
        if (empty($entry['native_name']) || klimat_product_cards_20261117_text($entry['native_name']) !== $name) $entry = array();
        $rows = klimat_product_cards_20261117_specs($tabs, $entry);
        $replacementTabs = klimat_product_cards_20261117_tabs($tabs, $rows, $entry);
        $replacementCard = klimat_product_cards_20261117_card($card, $id, $name, $rows, $entry);
        $html = substr_replace($html, $replacementTabs, $tabRanges[0]['start'], $tabRanges[0]['end'] - $tabRanges[0]['start']);
        return substr_replace($html, $replacementCard, $cards[0]['start'], $cards[0]['end'] - $cards[0]['start']);
    } catch (Throwable $error) {
        // Presentation is optional; malformed data must never block a native purchase.
        return $original;
    }
}
