<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE xsl:stylesheet>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:hostcms="http://www.hostcms.ru/"
	exclude-result-prefixes="hostcms">
	
	<xsl:output xmlns="http://www.w3.org/TR/xhtml1/strict" doctype-public="-//W3C//DTD XHTML 1.0 Strict//EN" encoding="utf-8" indent="yes" method="html" omit-xml-declaration="no" version="1.0" media-type="text/xml"/>
	
	
	
	<xsl:template match="/">
		<xsl:apply-templates select="/informationsystem"/>
	</xsl:template>
	
	<xsl:variable name="n" select="number(3)"/>
	
	<xsl:template match="/informationsystem">
		
		
		<xsl:variable name="group" select="group"/>
		
		<xsl:if test="informationsystem_item">
			
			<div class="news__head head-section">
				<h2><xsl:value-of select="name"/></h2>
				<a href="{url}">Все новости</a>
			</div>
			
			<ul class="news__list"><xsl:apply-templates select="informationsystem_item"/></ul>
		</xsl:if>
		
	</xsl:template>
	
	
	
	<xsl:template match="informationsystem_item">
		
		<xsl:variable name="month_year" select="substring-after(date, '.')"/>
		<xsl:variable name="month" select="substring-before($month_year, '.')"/>
		
		<li class="news__item">
			<a class="news__img-box" href="{url}">
				<p class="news__date">
					<b><xsl:value-of select="substring-before(date, '.')"/></b> <span>
						
						<xsl:choose>
							<xsl:when test="$month = 1"> января </xsl:when>
							<xsl:when test="$month = 2"> февраля </xsl:when>
							<xsl:when test="$month = 3"> марта </xsl:when>
							<xsl:when test="$month = 4"> апреля </xsl:when>
							<xsl:when test="$month = 5"> мая </xsl:when>
							<xsl:when test="$month = 6"> июня </xsl:when>
							<xsl:when test="$month = 7"> июля </xsl:when>
							<xsl:when test="$month = 8"> августа </xsl:when>
							<xsl:when test="$month = 9"> сентября </xsl:when>
							<xsl:when test="$month = 10"> октября </xsl:when>
							<xsl:when test="$month = 11"> ноября </xsl:when>
							<xsl:otherwise> декабря </xsl:otherwise>
						</xsl:choose>
				</span> <span><xsl:value-of select="substring-after($month_year, '.')"/></span>
				</p>
				<xsl:if test="image_small!=''">
					<img class="news__img" src="{dir}{image_small}" width="380" height="256" alt="{name}"/>
				</xsl:if>
			</a>
			<div class="news__content">
				<a href="{url}">
					<h3><xsl:value-of select="name"/></h3>
				</a>
				<xsl:value-of disable-output-escaping="yes" select="description"/>
			</div>
		</li>
		
		
		
		
		
		
	</xsl:template>
	
</xsl:stylesheet>