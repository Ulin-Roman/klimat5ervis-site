<?php
/** Storefront presentation for first-party reviews and attributed external summaries. */
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

function klimat_native_review_node($doc, $tag, $class = '', $text = null, array $attributes = array())
{
    $node = klimat_product_cards_20261117_el($doc, $tag, $class, $text);
    foreach ($attributes as $name => $value) $node->setAttribute($name, (string) $value);
    return $node;
}

function klimat_product_cards_20261117_review_overlay($id, $nativeName)
{
    if (!preg_match('~^[0-9]{1,12}$~D', (string) $id)) return array();
    $file = __DIR__ . '/data/reviews/' . $id . '.json';
    if (!is_file($file) || is_link($file)) return array();
    $raw = @file_get_contents($file, false, null, 0, 65536);
    if (!is_string($raw) || strlen($raw) >= 65536) return array();
    $data = json_decode($raw, true);
    if (!isset($data['item_id'], $data['model'], $data['sources']) || !is_string($data['model']) || !is_array($data['sources'])) return array();
    if ((!is_int($data['item_id']) && !is_string($data['item_id'])) || (string) $data['item_id'] !== (string) $id) return array();
    return klimat_product_cards_20261117_text($data['model']) === $nativeName ? $data['sources'] : array();
}

function klimat_native_review_editorial($entry, $overlay)
{
    $themes = array('pros' => array(), 'cons' => array(), 'notes' => array());
    $curated = isset($entry['external_reviews']) && is_array($entry['external_reviews']) ? $entry['external_reviews'] : array();
    foreach (array($curated, $overlay) as $kind => $rows) foreach ($rows as $source) {
        if (!is_array($source)) continue;
        $exact = $kind === 1 ? ($source['rating_scope'] ?? '') === 'exact' : ($source['exact_model_match'] ?? false) === true;
        $url = $source[$kind === 1 ? 'url' : 'source_url'] ?? '';
        $date = $source[$kind === 1 ? 'checked_on' : 'checked_at'] ?? '';
        if (!$exact || !klimat_product_cards_20261117_verified(array('source_url' => $url, 'checked_at' => $date))) continue;
        foreach (array('pros', 'cons') as $group) {
            if (!isset($source[$group]) || !is_array($source[$group])) continue;
            foreach ($source[$group] as $text) if (is_string($text)) {
                $text = klimat_product_cards_20261117_text($text);
                if ($text !== '') $themes[$group][$text] = $text;
            }
        }
        if (!empty($source['pros']) || !empty($source['cons'])) continue;
        $entries = $source[$kind === 1 ? 'entries' : 'review_summaries'] ?? array();
        $notes = array($source['summary'] ?? '');
        if (is_array($entries)) foreach ($entries as $review) if (is_array($review)) $notes[] = $review['summary'] ?? '';
        foreach ($notes as $text) if (is_string($text)) {
            $text = klimat_product_cards_20261117_text($text);
            if ($text !== '') $themes['notes'][$text] = $text;
        }
    }
    return array_map(static function ($group) { return array_slice(array_values($group), 0, 4); }, $themes);
}

function klimat_product_cards_20261117_review_data($id, $entry, $overlay)
{
    $view = array('id' => (int) $id, 'count' => 0, 'average' => null, 'distribution' => array(), 'reviews' => array(), 'available' => false);
    $view['external'] = klimat_native_review_external_data($id);
    $view['external_rating'] = klimat_native_review_external_rating($view['external'], $overlay);
    $view['themes'] = $view['external'] ? array() : klimat_native_review_editorial($entry, $overlay);
    try {
        require_once __DIR__ . '/site-reviews-store.php';
        $store = Klimat_Reviews_Store::instance();
        $summary = $store->summary($view['id']);
        if ($summary['count'] > 0) $view['reviews'] = $store->published($view['id'], 'newest', 10);
        $view = array_replace($view, $summary, array('available' => true));
    } catch (Throwable $error) {
        // An unavailable review store must not break the product page.
    }
    return $view;
}

function klimat_native_review_external_data($id)
{
    $id = (string) $id;
    if (!preg_match('~^[0-9]{1,12}$~D', $id)) return array();
    $file = __DIR__ . '/data/external-reviews/' . $id . '.json';
    if (!is_file($file) || is_link($file)) return array();
    $raw = @file_get_contents($file, false, null, 0, 32768);
    if (!is_string($raw) || strlen($raw) >= 32768) return array();
    $data = json_decode($raw, true);
    if (!isset($data['product_id'], $data['reviews']) || !is_int($data['product_id']) || (string) $data['product_id'] !== $id || !is_array($data['reviews'])) return array();

    $reviews = array();
    foreach (array_slice($data['reviews'], 0, 50) as $row) {
        if (!isset($row['source'], $row['summary'], $row['url'], $row['date']) || !is_string($row['source']) || !is_string($row['summary'])) continue;
        if (!klimat_product_cards_20261117_verified(array('source_url' => $row['url'], 'checked_at' => $row['date']))) continue;
        $source = klimat_product_cards_20261117_text($row['source']);
        $summary = klimat_product_cards_20261117_text($row['summary']);
        if ($source === '' || $summary === '') continue;
        $reviews[$summary] = array('source' => $source, 'summary' => $summary, 'url' => $row['url'], 'date' => $row['date'], 'group' => $row['group'] ?? '');
    }
    return array_values($reviews);
}

function klimat_native_review_external_rating(array $reviews, array $sources)
{
    if (!$reviews) return null;
    $urls = array_column($reviews, 'url');
    foreach ($sources as $source) {
        if (($source['rating_scope'] ?? '') !== 'exact' || !isset($source['url'], $source['checked_on'], $source['name'], $source['rating'], $source['rating_count'])) continue;
        if (!in_array($source['url'], $urls, true) || !klimat_product_cards_20261117_verified(array('source_url' => $source['url'], 'checked_at' => $source['checked_on']))) continue;
        if (!is_string($source['name']) || !is_numeric($source['rating']) || $source['rating'] < 1 || $source['rating'] > 5 || !is_int($source['rating_count']) || $source['rating_count'] < 1) continue;
        $name = klimat_product_cards_20261117_text($source['name']);
        if ($name !== '') return array('name' => $name, 'value' => (float) $source['rating'], 'count' => $source['rating_count'], 'url' => $source['url']);
    }
    return null;
}

function klimat_native_review_count_label($count, array $forms = array('отзыв', 'отзыва', 'отзывов'))
{
    $remainder = $count % 10;
    $suffix = $count % 100;
    if ($suffix >= 11 && $suffix <= 14) return $count . ' ' . $forms[2];
    $word = $remainder === 1 ? $forms[0] : ($remainder >= 2 && $remainder <= 4 ? $forms[1] : $forms[2]);
    return $count . ' ' . $word;
}

function klimat_native_review_gold_stars($doc, $rating)
{
    $stars = klimat_native_review_node($doc, 'span', 'ks-pdp-rating-stars-gold', null, array(
        'aria-hidden' => 'true', 'style' => 'display:inline-flex;gap:2px;flex:none',
    ));
    $shape = 'polygon(50% 2%,62% 35%,98% 36%,70% 58%,80% 94%,50% 73%,20% 94%,30% 58%,2% 36%,38% 35%)';
    for ($index = 0; $index < 5; $index++) {
        $fill = (int) round(max(0, min(1, $rating - $index)) * 100);
        $style = 'width:16px;height:16px;clip-path:' . $shape . ';background-color:#e2a10b;'
            . 'background-image:linear-gradient(90deg,transparent ' . $fill . '%,#dde5ee ' . $fill . '%),linear-gradient(#ffda67,#e6a913 60%,#bb7803)';
        $stars->appendChild(klimat_native_review_node($doc, 'span', '', null, array('style' => $style)));
    }
    return $stars;
}

function klimat_native_review_stars($doc, $rating, $aggregate = false, $compact = false)
{
    $rating = (float) $rating;
    $value = number_format($rating, $aggregate ? 1 : 0, '.', '');
    $score = klimat_native_review_node($doc, 'span', 'ks-pdp-review-score');
    $stars = $compact ? klimat_native_review_gold_stars($doc, $rating) : klimat_native_review_node($doc, 'span', 'ks-pdp-rating-stars', '★★★★★', array('aria-hidden' => 'true', 'style' => '--ks-rating-fill:' . round($rating * 20) . '%'));
    $score->appendChild($stars);
    $label = str_replace('.', ',', $value) . ($compact ? '' : ' из 5');
    $score->appendChild(klimat_native_review_node($doc, 'data', 'ks-pdp-rating-value', $label, array('value' => $value)));
    return $score;
}

function klimat_product_cards_20261117_reviews_link($doc, $reviews)
{
    $link = klimat_native_review_node($doc, 'a', 'ks-pdp-reviews-link', null, array('href' => '#tabs-ks-reviews', 'data-ks-open-tab' => 'tabs-ks-reviews'));
    if ($reviews['count'] > 0 && $reviews['average'] !== null) {
        $value = $reviews['average'];
        $count = klimat_native_review_count_label($reviews['count']);
    } elseif ($reviews['external_rating']) {
        $rating = $reviews['external_rating'];
        $value = $rating['value'];
        $count = klimat_native_review_count_label($rating['count'], array('оценка', 'оценки', 'оценок'));
    } else {
        $link->appendChild(klimat_native_review_node($doc, 'span', 'ks-pdp-review-link-label', 'Отзывы'));
        return $link;
    }
    $link->setAttribute('class', 'ks-pdp-reviews-link ks-pdp-reviews-link--rated');
    $link->setAttribute('style', 'text-decoration:none');
    $link->setAttribute('aria-label', 'Рейтинг ' . number_format($value, 1, ',', '') . ', ' . $count . '. Открыть отзывы');
    $link->appendChild(klimat_native_review_stars($doc, $value, true, true));
    $link->appendChild(klimat_native_review_node($doc, 'span', '', '· ' . $count));
    return $link;
}

function klimat_native_review_meta($doc, $property, $content)
{
    return klimat_native_review_node($doc, 'meta', '', null, array('itemprop' => $property, 'content' => $content));
}

function klimat_product_cards_20261117_reviews_product_schema($doc, $root, $reviews)
{
    if (!$reviews['count'] || $reviews['average'] === null) return;
    $xpath = new DOMXPath($doc);
    $condition = '@itemscope and (@itemtype="https://schema.org/Product" or @itemtype="http://schema.org/Product")';
    $product = $xpath->query('self::*[' . $condition . '] | .//*[' . $condition . ']', $root)->item(0);
    if (!$product instanceof DOMElement) return;
    $ref = preg_split('~\s+~', trim($product->getAttribute('itemref')), -1, PREG_SPLIT_NO_EMPTY);
    $ref[] = 'ks-first-party-review-content';
    $product->setAttribute('itemref', implode(' ', array_unique($ref)));
}

function klimat_native_review_summary($doc, array $reviews)
{
    $summary = klimat_native_review_node($doc, 'div', 'ks-own-review-summary', null, array('itemprop' => 'aggregateRating', 'itemscope' => '', 'itemtype' => 'https://schema.org/AggregateRating'));
    $overview = klimat_native_review_node($doc, 'div', 'ks-own-review-overview');
    $score = klimat_native_review_stars($doc, $reviews['average'], true);
    $score->getElementsByTagName('data')->item(0)->setAttribute('itemprop', 'ratingValue');
    $overview->appendChild($score);
    $overview->appendChild(klimat_native_review_node($doc, 'data', 'ks-own-review-total', klimat_native_review_count_label($reviews['count']), array('itemprop' => 'reviewCount', 'value' => $reviews['count'])));
    $overview->appendChild(klimat_native_review_meta($doc, 'bestRating', 5));
    $overview->appendChild(klimat_native_review_meta($doc, 'worstRating', 1));
    $summary->appendChild($overview);
    $bars = klimat_native_review_node($doc, 'ul', 'ks-own-review-bars', null, array('aria-label' => 'Распределение оценок'));
    for ($rating = 5; $rating >= 1; $rating--) {
        $count = (int) ($reviews['distribution'][$rating] ?? 0);
        $row = klimat_native_review_node($doc, 'li', '', null, array('aria-label' => $rating . ' из 5, ' . klimat_native_review_count_label($count)));
        $row->appendChild(klimat_native_review_node($doc, 'span', 'ks-own-review-bar-label', $rating . ' ★', array('aria-hidden' => 'true')));
        $bar = klimat_native_review_node($doc, 'span', 'ks-own-review-bar', null, array('aria-hidden' => 'true'));
        $bar->appendChild(klimat_native_review_node($doc, 'span', '', null, array('style' => 'width:' . round(100 * min(1, $count / $reviews['count'])) . '%')));
        $row->appendChild($bar);
        $row->appendChild(klimat_native_review_node($doc, 'span', 'ks-own-review-bar-value', $count, array('aria-hidden' => 'true')));
        $bars->appendChild($row);
    }
    $summary->appendChild($bars);
    return $summary;
}

function klimat_native_review_article($doc, array $review)
{
    $article = klimat_native_review_node($doc, 'article', 'ks-own-review-card', null, array('itemprop' => 'review', 'itemscope' => '', 'itemtype' => 'https://schema.org/Review'));
    $header = klimat_native_review_node($doc, 'header', 'ks-own-review-card-head');
    $author = klimat_native_review_node($doc, 'span', 'ks-own-review-author', null, array('itemprop' => 'author', 'itemscope' => '', 'itemtype' => 'https://schema.org/Person'));
    $author->appendChild(klimat_native_review_node($doc, 'strong', '', $review['author'], array('itemprop' => 'name')));
    $header->appendChild($author);
    $published = (new DateTimeImmutable($review['published_at']))->setTimezone(new DateTimeZone('Europe/Moscow'));
    $header->appendChild(klimat_native_review_node($doc, 'time', '', $published->format('d.m.Y'), array('datetime' => $review['published_at'], 'itemprop' => 'datePublished')));
    $score = klimat_native_review_stars($doc, $review['rating']);
    $score->setAttribute('itemprop', 'reviewRating');
    $score->setAttribute('itemscope', '');
    $score->setAttribute('itemtype', 'https://schema.org/Rating');
    $score->getElementsByTagName('data')->item(0)->setAttribute('itemprop', 'ratingValue');
    $header->appendChild($score);
    if (!empty($review['verified_purchase'])) $header->appendChild(klimat_native_review_node($doc, 'span', 'ks-own-review-verified', 'Подтверждённая покупка'));
    $article->appendChild($header);
    $article->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-body', $review['body'], array('itemprop' => 'reviewBody')));
    foreach (array('pros' => 'Достоинства', 'cons' => 'Недостатки') as $field => $label) if ($review[$field] !== '') {
        $detail = klimat_native_review_node($doc, 'div', 'ks-own-review-detail');
        $detail->appendChild(klimat_native_review_node($doc, 'strong', '', $label));
        $detail->appendChild(klimat_native_review_node($doc, 'p', '', $review[$field]));
        $article->appendChild($detail);
    }
    if ($review['photos']) {
        $photos = klimat_native_review_node($doc, 'div', 'ks-own-review-photos');
        foreach ($review['photos'] as $index => $photo) {
            if (!preg_match('~^/assets/product-cards-20261117/site-reviews-api\.php\?action=photo&id=[a-f0-9]{32}$~D', $photo['url'])) continue;
            $alt = 'Фото покупателя ' . ($index + 1);
            $link = klimat_native_review_node($doc, 'a', '', null, array('href' => $photo['url'], 'data-ks-review-photo' => ''));
            $link->appendChild(klimat_native_review_node($doc, 'img', '', null, array('src' => $photo['url'], 'alt' => $alt, 'loading' => 'lazy', 'decoding' => 'async', 'width' => 96, 'height' => 96)));
            $photos->appendChild($link);
        }
        if ($photos->hasChildNodes()) $article->appendChild($photos);
    }
    return $article;
}

function klimat_native_review_form($doc, $id)
{
    $details = klimat_native_review_node($doc, 'details', 'ks-own-review-compose', null, array('data-ks-review-compose' => ''));
    $details->appendChild(klimat_native_review_node($doc, 'summary', 'ks-own-review-button ks-own-review-button--primary', 'Написать отзыв'));
    $form = klimat_native_review_node($doc, 'form', 'ks-own-review-form', null, array('method' => 'post', 'action' => '/assets/product-cards-20261117/site-reviews-api.php?action=submit', 'enctype' => 'multipart/form-data', 'data-ks-review-form' => ''));
    $form->appendChild(klimat_native_review_node($doc, 'input', '', null, array('type' => 'hidden', 'name' => 'product_id', 'value' => $id)));
    $rating = klimat_native_review_node($doc, 'fieldset', 'ks-own-review-picker');
    $rating->appendChild(klimat_native_review_node($doc, 'legend', '', 'Ваша оценка'));
    $stars = klimat_native_review_node($doc, 'div', 'ks-own-review-options', null, array('data-ks-review-options' => ''));
    for ($score = 1; $score <= 5; $score++) {
        $radio = klimat_native_review_node($doc, 'input', '', null, array('id' => 'ks-review-rating-' . $score, 'type' => 'radio', 'name' => 'rating', 'value' => $score, 'required' => 'required', 'aria-label' => $score . ' из 5'));
        $stars->appendChild($radio);
        $stars->appendChild(klimat_native_review_node($doc, 'label', '', '★', array('for' => 'ks-review-rating-' . $score, 'aria-hidden' => 'true', 'title' => $score . ' из 5')));
    }
    $rating->appendChild($stars);
    $form->appendChild($rating);
    $name = klimat_native_review_node($doc, 'label', '', 'Имя для публикации');
    $name->appendChild(klimat_native_review_node($doc, 'input', '', null, array('type' => 'text', 'name' => 'author', 'required' => 'required', 'minlength' => 2, 'maxlength' => 80, 'autocomplete' => 'given-name')));
    $form->appendChild($name);
    $text = klimat_native_review_node($doc, 'label', '', 'Ваш отзыв');
    $text->appendChild(klimat_native_review_node($doc, 'textarea', '', null, array('name' => 'body', 'required' => 'required', 'minlength' => 20, 'maxlength' => 3000, 'rows' => 5, 'placeholder' => 'Расскажите о своём опыте использования товара')));
    $form->appendChild($text);
    $detailsFields = klimat_native_review_node($doc, 'div', 'ks-own-review-form-details');
    foreach (array('pros' => 'Достоинства', 'cons' => 'Недостатки') as $field => $label) {
        $input = klimat_native_review_node($doc, 'label', '', $label . ' (необязательно)');
        $input->appendChild(klimat_native_review_node($doc, 'textarea', '', null, array('name' => $field, 'maxlength' => 700, 'rows' => 3)));
        $detailsFields->appendChild($input);
    }
    $form->appendChild($detailsFields);
    $attachments = klimat_native_review_node($doc, 'div', 'ks-own-review-attachments', null, array('data-ks-review-attachments' => ''));
    $photos = klimat_native_review_node($doc, 'label', '', 'Фотографии товара (необязательно)');
    $photos->appendChild(klimat_native_review_node($doc, 'input', '', null, array('type' => 'file', 'name' => 'photos[]', 'accept' => 'image/jpeg,image/png,image/webp', 'multiple' => '', 'aria-describedby' => 'ks-own-review-photo-limits')));
    $attachments->appendChild($photos);
    $attachments->appendChild(klimat_native_review_node($doc, 'small', 'ks-own-review-hint', 'До четырёх фото. JPG, PNG или WebP. До 3 МБ на фото и 7 МБ суммарно.', array('id' => 'ks-own-review-photo-limits')));
    $consent = klimat_native_review_node($doc, 'label', 'ks-own-review-consent', null, array('data-ks-review-photo-consent' => '', 'hidden' => 'hidden'));
    $consent->appendChild(klimat_native_review_node($doc, 'input', '', null, array('type' => 'checkbox', 'name' => 'photo_consent', 'value' => '1')));
    $consent->appendChild($doc->createTextNode('Подтверждаю, что это мои фотографии, и разрешаю опубликовать их вместе с отзывом.'));
    $attachments->appendChild($consent);
    $form->appendChild($attachments);
    $form->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-hint', '', array('data-ks-review-photos-unavailable' => '', 'hidden' => 'hidden')));
    $trap = klimat_native_review_node($doc, 'label', 'ks-own-review-trap', 'Веб-сайт', array('aria-hidden' => 'true'));
    $trap->appendChild(klimat_native_review_node($doc, 'input', '', null, array('name' => 'website', 'type' => 'text', 'tabindex' => '-1', 'autocomplete' => 'off')));
    $form->appendChild($trap);
    $form->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-hint', 'Имя и отзыв появятся на сайте после модерации.'));
    $form->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-status', '', array('role' => 'status', 'aria-live' => 'polite', 'data-ks-review-status' => '')));
    $form->appendChild(klimat_native_review_node($doc, 'button', 'ks-own-review-button ks-own-review-button--primary', 'Отправить на модерацию', array('type' => 'submit', 'disabled' => 'disabled')));
    $noscript = klimat_native_review_node($doc, 'noscript', '', 'Для отправки отзыва включите JavaScript в браузере.');
    $form->appendChild($noscript);
    $details->appendChild($form);
    return $details;
}

function klimat_native_review_editorial_section($doc, $themes)
{
    $section = klimat_native_review_node($doc, 'aside', 'ks-own-review-editorial');
    $section->appendChild(klimat_native_review_node($doc, 'h3', '', 'Что отмечают покупатели'));
    $section->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-hint', 'Кратко по отзывам на внешних площадках.'));
    $columns = klimat_native_review_node($doc, 'div', 'ks-own-review-editorial-columns');
    foreach (array('pros' => 'Достоинства', 'cons' => 'Недостатки', 'notes' => '') as $group => $label) if ($themes[$group]) {
        $column = klimat_native_review_node($doc, 'div');
        if ($label !== '') $column->appendChild(klimat_native_review_node($doc, 'strong', '', $label));
        $list = klimat_native_review_node($doc, 'ul');
        foreach ($themes[$group] as $text) $list->appendChild(klimat_native_review_node($doc, 'li', '', $text));
        $column->appendChild($list);
        $columns->appendChild($column);
    }
    $section->appendChild($columns);
    return $section;
}

function klimat_native_review_external_list($doc, array $reviews)
{
    $list = klimat_native_review_node($doc, 'div', 'ks-own-review-list');
    foreach ($reviews as $review) {
        $card = klimat_native_review_node($doc, 'article', 'ks-own-review-card');
        $header = klimat_native_review_node($doc, 'header', 'ks-own-review-card-head');
        $label = $review['source'];
        if ($review['group'] === 'archive') $label .= ' · архив';
        if ($review['group'] === 'variant') $label .= ' · вариант 35 м²';
        $header->appendChild(klimat_native_review_node($doc, 'strong', '', $label));
        $header->appendChild(klimat_native_review_node($doc, 'time', '', implode('.', array_reverse(explode('-', $review['date']))), array('datetime' => $review['date'])));
        $card->appendChild($header);
        $card->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-body', $review['summary']));
        $footer = klimat_native_review_node($doc, 'footer', 'ks-own-review-hint');
        $footer->appendChild(klimat_native_review_node($doc, 'a', '', 'Источник · ' . $review['source'], array('href' => $review['url'], 'target' => '_blank', 'rel' => 'noopener noreferrer')));
        $card->appendChild($footer);
        $list->appendChild($card);
    }
    return $list;
}

function klimat_native_review_external_section($doc, array $reviews, $rating)
{
    $section = klimat_native_review_node($doc, 'section', 'ks-own-review-list', null, array('aria-label' => 'Отзывы с других площадок'));
    $current = array();
    $archive = array();
    foreach ($reviews as $review) {
        if ($review['group'] === 'archive') $archive[] = $review;
        else $current[] = $review;
    }
    if ($current) $section->appendChild(klimat_native_review_external_list($doc, array_slice($current, 0, 6)));
    foreach (array('Ещё отзывы о модели' => array_slice($current, 6), 'Архивные отзывы Ozon' => $archive) as $title => $group) {
        if (!$group) continue;
        $details = klimat_native_review_node($doc, 'details');
        $details->appendChild(klimat_native_review_node($doc, 'summary', '', $title . ' (' . count($group) . ')'));
        $details->appendChild(klimat_native_review_external_list($doc, $group));
        $section->appendChild($details);
    }
    if ($rating) {
        $source = klimat_native_review_node($doc, 'footer', 'ks-own-review-hint');
        $source->appendChild(klimat_native_review_node($doc, 'a', '', 'Источник оценки · ' . $rating['name'], array('href' => $rating['url'], 'target' => '_blank', 'rel' => 'noopener noreferrer')));
        $section->appendChild($source);
    }
    return $section;
}

function klimat_product_cards_20261117_reviews_panel($doc, $head, $root, $reviews)
{
    $tab = klimat_native_review_node($doc, 'li');
    $total = $reviews['count'] + count($reviews['external']);
    $tab->appendChild(klimat_native_review_node($doc, 'a', '', 'Отзывы (' . $total . ')', array('href' => '#tabs-ks-reviews')));
    $head->appendChild($tab);
    $panel = klimat_native_review_node($doc, 'div', 'product-tabs__content ks-pdp-reviews ks-own-reviews', null, array('id' => 'tabs-ks-reviews', 'data-ks-review-product' => $reviews['id'], 'data-ks-review-pages' => max(1, (int) ceil($reviews['count'] / 10))));
    $title = $reviews['external'] ? 'Отзывы о товаре' : 'Отзывы покупателей';
    $panel->appendChild(klimat_native_review_node($doc, 'h2', '', $title));
    if ($reviews['available']) $panel->appendChild(klimat_native_review_form($doc, $reviews['id']));
    $content = klimat_native_review_node($doc, 'div', 'ks-own-review-content', null, array('id' => 'ks-first-party-review-content'));
    if (!$reviews['available'] || !$reviews['count']) {
        if (!$reviews['external']) $content->appendChild(klimat_native_review_node($doc, 'p', 'ks-pdp-review-empty', $reviews['available'] ? 'Пока нет отзывов. Будьте первым!' : 'Отзывы временно недоступны.'));
    } else {
        if ($reviews['external']) $content->appendChild(klimat_native_review_node($doc, 'h3', '', 'Отзывы на сайте «Климат-Сервис»'));
        $content->appendChild(klimat_native_review_summary($doc, $reviews));
        $toolbar = klimat_native_review_node($doc, 'div', 'ks-own-review-toolbar', null, array('data-ks-review-toolbar' => '', 'hidden' => 'hidden'));
        $label = klimat_native_review_node($doc, 'label', '', 'Сортировка');
        $select = klimat_native_review_node($doc, 'select', '', null, array('data-ks-review-sort' => ''));
        foreach (array('newest' => 'Сначала новые', 'oldest' => 'Сначала старые', 'highest' => 'Сначала высокая оценка', 'lowest' => 'Сначала низкая оценка') as $order => $title) {
            $select->appendChild(klimat_native_review_node($doc, 'option', '', $title, array('value' => $order)));
        }
        $label->appendChild($select);
        $toolbar->appendChild($label);
        $content->appendChild($toolbar);
        $content->appendChild(klimat_native_review_node($doc, 'p', 'ks-own-review-status', '', array('role' => 'status', 'data-ks-review-list-status' => '')));
        $list = klimat_native_review_node($doc, 'div', 'ks-own-review-list', null, array('data-ks-review-list' => ''));
        foreach ($reviews['reviews'] as $review) $list->appendChild(klimat_native_review_article($doc, $review));
        $content->appendChild($list);
        $pagination = klimat_native_review_node($doc, 'nav', 'ks-own-review-pagination', null, array('data-ks-review-pages-nav' => '', 'aria-label' => 'Страницы отзывов', 'hidden' => 'hidden'));
        $pagination->appendChild(klimat_native_review_node($doc, 'button', 'ks-own-review-button', 'Назад', array('type' => 'button', 'data-ks-review-page-prev' => '', 'disabled' => 'disabled')));
        $pagination->appendChild(klimat_native_review_node($doc, 'span', '', '', array('data-ks-review-page-label' => '')));
        $pagination->appendChild(klimat_native_review_node($doc, 'button', 'ks-own-review-button', 'Далее', array('type' => 'button', 'data-ks-review-page-next' => '')));
        $content->appendChild($pagination);
    }
    if ($content->hasChildNodes()) $panel->appendChild($content);
    if ($reviews['external']) $panel->appendChild(klimat_native_review_external_section($doc, $reviews['external'], $reviews['external_rating']));
    elseif (array_filter($reviews['themes'])) $panel->appendChild(klimat_native_review_editorial_section($doc, $reviews['themes']));
    $root->appendChild($panel);
}
