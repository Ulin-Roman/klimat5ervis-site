<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE xsl:stylesheet>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:hostcms="http://www.hostcms.ru/"
	exclude-result-prefixes="hostcms">
	<xsl:output xmlns="http://www.w3.org/TR/xhtml1/strict" doctype-public="-//W3C//DTD XHTML 1.0 Strict//EN" encoding="utf-8" indent="yes" method="html" omit-xml-declaration="no" version="1.0" media-type="text/xml"/>



	<xsl:decimal-format name="my" decimal-separator="," grouping-separator=" "/>

	<xsl:template match="/shop">

		<xsl:if test="not(AjaxProperties/node())">
			<xsl:apply-templates select="shop_item"/>
		</xsl:if>

		<xsl:if test="AjaxProperties/node()">

			<script>
				// Скрываем прелаудер
				$.loadingScreen('hide');
				$(document).ready(function(){

				// Устанавливаем в input id товара  с цветом по умолчанию
				$('.cartitemid').val( $('.prod_color_act').find('.input_id').val() );

				// Меняем цену
				$('.product-card__price').html('<ins><strong>' + $('.prod_color_act').attr('data-price') + '</strong> руб.</ins><del>' + $('.prod_color_act').attr('data-price-discount') + '</del>');

				// Проверяем есть ли размеры на странице
				var elements = document.getElementsByClassName('prod_size');
				if(elements.length){

				// выставляем id первого и выделение
				$('.cartitemid').val( $('.prod_size:first').find('.input_id').val() );
				$('.prod_size:first').addClass('prod_size_act');
				$('.product-card__price').html('<ins><strong>' + $('.prod_size:first').attr('data-price') + '</strong> руб.</ins><del>' + $('.prod_size:first').attr('data-price-discount') + '</del>');


				// если изменили размер
				$('.prod_size').click(function(){
				$('.prod_size').removeClass('prod_size_act');
				$('.cartitemid').val(  $(this).find('.input_id').val() );
				$(this).addClass('prod_size_act');
				// Меняем цену (берем цену размера если есть)
				$('.product-card__price').html('<ins><strong>' + $(this).attr('data-price') + '</strong> руб.</ins><del>' + $(this).attr('data-price-discount') + '</del>');
				});
				}

				$('.group__color').on('click', function () {
				let selectedColorUrl = $(this).attr('data-img');
				let previd = '#oop' + $(this).attr('data-id');
				var listItem = $('div.gallery div.gallery__item img'+previd);
				$('.gallery-side').slick('slickGoTo',  $('div.gallery div.gallery__item img').index(listItem));
				});
				});
			</script>

			<xsl:apply-templates select="shop_item" mode="AjaxProperties"/>

		</xsl:if>

	</xsl:template>



	<xsl:template match="shop_item">


		<div class="product-card">


			<div class="product-card__name product-card__name--mobile">
				<h1><xsl:value-of select="name"/></h1>

				<xsl:if test="shop_producer/image_small != ''">
					<img src="{shop_producer/dir}{shop_producer/image_small}" alt=""/>
				</xsl:if>



			</div>


			<div class="product-card__left">
				<div class="product-card__gallery">

					<xsl:if test="image_small != ''">
						<div class="gallery-side">

							<xsl:if test="image_small != ''">
								<div class="gallery-side__item">
									<img src="{dir}{image_small}" alt=""/>
								</div>
							</xsl:if>

							<xsl:if test="count(property_value[tag_name='img'])">
								<xsl:apply-templates select="property_value[tag_name='img']" mode="dopimgsmall"/>
							</xsl:if>

							<xsl:if test="count(/shop/shop_item/modifications/shop_item/property_value[tag_name='color']/value) &gt; 0">
								<xsl:apply-templates select="//shop_item_properties/property[tag_name='color']/list/list_item" mode="dopimgsmall_colors"/>
							</xsl:if>


						</div>
					</xsl:if>



					<div class="gallery">

						<xsl:if test="image_large != ''">
							<div class="gallery__item">
								<img src="{dir}{image_large}" alt=""/>
							</div>
						</xsl:if>

						<xsl:if test="image_large = ''">
							<div class="gallery__item">
								<img src="/images/t8903001/img/noimage.jpg" alt=""/>
							</div>
						</xsl:if>

						<xsl:if test="count(property_value[tag_name='img'])">
							<xsl:apply-templates select="property_value[tag_name='img']" mode="dopimgbig"/>
						</xsl:if>


						<xsl:if test="count(/shop/shop_item/modifications/shop_item/property_value[tag_name='color']/value) &gt; 0">
							<xsl:apply-templates select="//shop_item_properties/property[tag_name='color']/list/list_item" mode="dopimgbig_colors"/>
						</xsl:if>


					</div>
				</div>

				<!--
					<div class="product-card__warranty">
						<strong>Гарантия лучшей цены</strong>
						<p>
							Если вы найдете данный товар по более низкой цене, мы сделаем
							лучшее предложение или дадим такую же цену. Вам достаточно
							предоставить информацию об альтернативном предложении.
						</p>
					</div>
					-->

				</div>



				<div class="product-card__right">
					<div class="product-card__details">
						<div class="product-card__name product-card__name--desktop">
							<h1><xsl:value-of select="name"/></h1>

							<xsl:if test="shop_producer/image_small != ''">
								<a href="{/shop/url}producers/{shop_producer/path}/"><img src="{shop_producer/dir}{shop_producer/image_small}" alt=""/></a>
							</xsl:if>


						</div>
						<div class="product-card__price-box">

							<!-- Убираем цену у коллекции -->
							<xsl:if test="property_value[tag_name='collection']/value != 1 or not(property_value[tag_name='collection']/node())">
								<p class="product-card__price">
									<xsl:choose>
										<xsl:when test="price != 0">
											<ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
										</xsl:when>
										<xsl:otherwise>
											<ins class="noprice">Цену уточняйте</ins>
										</xsl:otherwise>
									</xsl:choose>

									<xsl:if test="discount != 0">
										<xsl:text> </xsl:text><del><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
									</xsl:if>
								</p>
							</xsl:if>




							<xsl:if test="rest &gt; 0">
								<div class="product-card__informer">
									<p>В наличии</p>
								</div>
							</xsl:if>

							<xsl:if test="rest = 0">
								<div class="product-card__informer norest">
									<p>Нет в наличии</p>
								</div>
							</xsl:if>



						</div>

						<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit_with_item']/value = 1">
							<p class="product-card__price_complect">
								<ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /> </ins><span class="desc_price_complect">цена с выбранными комплектующими</span>
							</p>
						</xsl:if>

					</div>


					<!-- Убираем лишние кнопки у коллекции -->
					<xsl:if test="property_value[tag_name='collection']/value != 1 or not(property_value[tag_name='collection']/node())">

						<div class="containeritem">

							<ul class="product-card__groups">

								<xsl:if test="count(/shop/shop_item/modifications/shop_item/property_value[tag_name='color']/value) &gt; 0">
									<li class="group">
										<p class="group__title">Цвет:</p>
										<ul class="group__list">
											<xsl:apply-templates select="//shop_item_properties/property[tag_name='color']/list/list_item" mode="colors"/>
										</ul>
									</li>
								</xsl:if>

								<xsl:if test="count(/shop/shop_item/modifications/shop_item/property_value[tag_name='color']/value) &gt; 0 and count(/shop/shop_item/modifications/shop_item/property_value[tag_name='size']/value) &gt; 0">
									<li class="group">
										<p class="group__title">Размер:</p>
										<ul class="group__list">
											<xsl:apply-templates select="//shop_item_properties/property[tag_name='size']/list/list_item" mode="size"/>
										</ul>
									</li>
								</xsl:if>

								<xsl:if test="count(/shop/shop_item/modifications/shop_item/property_value[tag_name='color']/value) = 0  and count(/shop/shop_item/modifications/shop_item/property_value[tag_name='size']/value) &gt; 0">
									<li class="group">
										<p class="group__title">Размер:</p>
										<ul class="group__list">
											<xsl:apply-templates select="//shop_item_properties/property[tag_name='size']/list/list_item" mode="size_not_color"/>
										</ul>
									</li>
								</xsl:if>

							</ul>
						</div>

						<div class="product-card__buttons">
							<input class="product-card__quantity quantity" type="number" value="1" min="1"  id="item-quantity" name="quantity"/>
							<a class="product-card__button button button--common"  href="{/shop/url}cart/?add={@id}" onclick="return $.addIntoCart('{/shop/url}cart/', $('.cartitemid').val(), $('#item-quantity').val())">

								<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit']/value = 1">
									<xsl:attribute name="onclick">return $.addIntoCartComplex('<xsl:value-of select="/shop/url"/>cart/', $('#complex_form'))</xsl:attribute>
								</xsl:if>

								<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit_with_item']/value = 1">
									<xsl:attribute name="onclick">$.addIntoCart('<xsl:value-of select="/shop/url"/>cart/', $('.cartitemid').val(), $('#item-quantity').val()); $.addIntoCartComplex('<xsl:value-of select="/shop/url"/>cart/', $('#complex_form'));   return false;</xsl:attribute>
								</xsl:if>


							В корзину</a>

							<xsl:if test="count(set/shop_item) = 0 and (property_value[tag_name='complect_edit']/value != 1 or not(/property_value[tag_name='complect_edit']/node()) or property_value[tag_name='complect_edit_with_item']/value != 1 or not(property_value[tag_name='complect_edit_with_item']/node()))">
								<a class="product-card__button product-card__button--buy button button--common" href="javascript:void(0);" onclick="return fastorder($('.cartitemid').val(), $('#item-quantity').val());">Купить в 1 клик</a>
							</xsl:if>

							<a class="product-card__wish-list-link" href="javascript:void(0);" title="Добавить в избранное" onclick="return $.addFavorite('{/shop/url}favorite/', {@id}, this)">
								<xsl:variable name="shop_item_id" select="@id" />
								<xsl:if test="/shop/favorite/shop_item[@id = $shop_item_id]/node()">
									<xsl:attribute name="class">product-card__wish-list-link product-card__wish-list-link--added</xsl:attribute>
								</xsl:if>

							</a>

						</div>
					</xsl:if>


					<xsl:if test="count(set/shop_item[rest &gt; 0]) != 0 and property_value[tag_name = 'complect_edit']/value = 1">
						<a href="#complect_edit_block" class="complect_edit_link">Изменить состав комплекта</a>
					</xsl:if>

					<xsl:if test="count(set/shop_item[rest &gt; 0]) != 0 and property_value[tag_name='complect_edit_with_item']/value = 1">
						<a href="#complect_edit_block" class="complect_edit_link">Выбрать комплектующие</a>
					</xsl:if>


					<xsl:if test="marking != ''">
						<p><strong>Артикул:</strong><xsl:text> </xsl:text><xsl:value-of select="marking"/></p>
					</xsl:if>

					<xsl:if test="property_value[tag_name = 'description']/value != ''">
						<div class="product-card__delivery-info">
							<xsl:value-of disable-output-escaping="yes" select="property_value[tag_name = 'description']/value "/>
						</div>
					</xsl:if>


					<input type="hidden" value="{@id}" class="cartitemid"/>








				</div>

			</div>

			<div class="product-tabs">
				<ul class="product-tabs__head">
					<li><a href="#tabs-1">Описание</a></li>
					<li><a href="#tabs-2">Характеристики</a></li>
				</ul>
				<div class="product-tabs__content" id="tabs-1">

					<xsl:if test="text != ''">
						<xsl:value-of disable-output-escaping="yes" select="text"/>
					</xsl:if>

				</div>
				<div class="product-tabs__content" id="tabs-2">


					<xsl:if test="count(property_value)">
						<xsl:apply-templates select="property_value[tag_name != 'novinka' and tag_name != 'tovar-nedeli'  and tag_name != 'complect_edit'   and tag_name != 'collection'    and tag_name != 'complect_edit_with_item' and tag_name != 'topsale' and tag_name != 'dopimg' and tag_name != 'description']"/>
					</xsl:if>

				</div>
			</div>



			<xsl:if test="count(set/shop_item[rest &gt; 0]) != 0 and (property_value[tag_name = 'complect_edit']/value = 1 or property_value[tag_name = 'complect_edit_with_item']/value = 1)">
				<div class="additional-goods additional-goods--watched" id="complect_edit_block">
					<div class="additional-goods__head head-section">

						<xsl:if test="property_value[tag_name = 'complect_edit']/value = 1">
							<h2>Товары комплекта</h2>
						</xsl:if>

						<xsl:if test="property_value[tag_name = 'complect_edit_with_item']/value = 1">
							<h2>Выбор комплектующих</h2>
						</xsl:if>

					</div>

					<div class="complex">
						<div class="container">
							<form id="complex_form">
								<xsl:apply-templates select="set/shop_item[rest &gt; 0]" mode="complect_edit"/>
							</form>
						</div>
				</div></div>
			</xsl:if>


			<xsl:if test="count(set/shop_item) &gt; 0 and (property_value[tag_name='complect_edit']/value != 1 or not(property_value[tag_name='complect_edit']/node())) and (property_value[tag_name='complect_edit_with_item']/value != 1 or not(property_value[tag_name='complect_edit_with_item']/node()))">

				<div class="additional-goods additional-goods--watched">
					<div class="additional-goods__head head-section">
						<h2>Товары комплекта</h2>
					</div>
					<div class="additional-goods__slider">
						<xsl:apply-templates select="set/shop_item"/>
					</div>
				</div>
			</xsl:if>


			<xsl:if test="count(modifications/shop_item) &gt; 0 and property_value[tag_name='collection']/value = 1">

				<div class="additional-goods additional-goods--watched">
					<div class="additional-goods__head head-section">
						<h2>Товары коллекции</h2>
					</div>
					<div class="complex">
						<div class="container">
							<form id="complex_form">
								<xsl:apply-templates select="modifications/shop_item" mode="collection"/>
					</form></div></div>
				</div>
			</xsl:if>



			<xsl:if test="count(associated/shop_item) &gt; 0">

				<div class="additional-goods additional-goods--watched">
					<div class="additional-goods__head head-section">
						<h2>Сопутствующие товары</h2>
					</div>
					<div class="additional-goods__slider">
						<xsl:apply-templates select="associated/shop_item"/>
					</div>
				</div>
			</xsl:if>



			<xsl:if test="/shop/viewed/shop_item">

				<div class="additional-goods additional-goods--watched">
					<div class="additional-goods__head head-section">
						<h2>Просмотренные товары</h2>
					</div>
					<div class="additional-goods__slider">


						<xsl:apply-templates select="/shop/viewed/shop_item[position() &lt; 8]" mode="view"/>
					</div>
				</div>
			</xsl:if>




		</xsl:template>




		<xsl:template match="property_value" mode="dopimgsmall">
			<xsl:if test="value/node() and value != '' or file/node() and file != ''">

				<div class="gallery-side__item">
					<img src="{../dir}{file_small}" alt=""/>
				</div>

			</xsl:if>
		</xsl:template>


		<xsl:template match="property_value" mode="dopimgbig">
			<xsl:if test="value/node() and value != '' or file/node() and file != ''">

				<div class="gallery__item">
					<img src="{../dir}{file_small}" alt=""/>
				</div>

			</xsl:if>
		</xsl:template>



		<xsl:template match="list/list_item" mode="dopimgsmall_colors">

			<xsl:variable name="modification_id">
				<xsl:choose>
					<xsl:when test="/shop/shop_item/modification_id = 0">
						<xsl:value-of select="/shop/shop_item/@id"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item/modification_id"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>

			<xsl:variable name="value" select="value"/>

			<xsl:variable name="nowcolor2s" select="value"/>

			<xsl:variable name="nowcolors">
				<xsl:choose>
					<xsl:when test="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value">
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/modifications/shop_item[modification_id = $modification_id]/property_value[tag_name='color']/value"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>






			<xsl:if test="count(//shop_item/modifications/shop_item[rest &gt; 0 and modification_id = $modification_id]/property_value[tag_name='color' and value = $value])">
				<xsl:choose>
					<xsl:when test="//shop_item/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large != ''">

						<div class="gallery-side__item">
							<img src="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/dir}{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large}" alt=""/>
						</div>
					</xsl:when>
					<xsl:otherwise></xsl:otherwise>
				</xsl:choose>
			</xsl:if>
		</xsl:template>

		<xsl:template match="list/list_item" mode="dopimgbig_colors">


			<xsl:variable name="modification_id">
				<xsl:choose>
					<xsl:when test="/shop/shop_item/modification_id = 0">
						<xsl:value-of select="/shop/shop_item/@id"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item/modification_id"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>

			<xsl:variable name="value" select="value"/>

			<xsl:variable name="nowcolor2s" select="value"/>

			<xsl:variable name="nowcolors">
				<xsl:choose>
					<xsl:when test="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value">
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id]/property_value[tag_name='color']/value"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>

			<xsl:if test="count(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0 and modification_id = $modification_id]/property_value[tag_name='color' and value = $value])">
				<xsl:choose>
					<xsl:when test="//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large != ''">

						<div class="gallery__item">

							<img src="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/dir}{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large}"   id="oop{@id}"  alt=""/>
						</div>
					</xsl:when>
					<xsl:otherwise></xsl:otherwise>
				</xsl:choose>
			</xsl:if>
		</xsl:template>










		<xsl:template match="shop_item" mode="AjaxProperties">

			<!-- Выделяем первый размер -->
			<script>
				$('.prod_size:first input.group__field').attr("checked", "checked");
			</script>

			<ul class="product-card__groups">
				<li class="group">
					<p class="group__title">Цвет:</p>
					<ul class="group__list">
						<xsl:apply-templates select="//shop_item_properties/property[tag_name='color']/list/list_item" mode="colors"/>
					</ul>
				</li>

				<xsl:if test="count(//shop/shop_item[rest &gt; 0]/property_value[tag_name='size']/value) &gt; 0">
					<li class="group">
						<p class="group__title">Размер: </p>
						<ul class="group__list">
							<xsl:apply-templates select="//shop_item_properties/property[tag_name='size']/list/list_item" mode="size"/>
						</ul>
				</li></xsl:if>

			</ul>
		</xsl:template>




		<xsl:template match="list/list_item" mode="colors">

			<xsl:variable name="value" select="value"/>

			<xsl:variable name="nowcolor2s" select="value"/>


			<xsl:variable name="modification_id">
				<xsl:choose>
					<xsl:when test="/shop/shop_item/modification_id = 0">
						<xsl:value-of select="/shop/shop_item/@id"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item/modification_id"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>




			<xsl:variable name="nowcolors">
				<xsl:choose>
					<xsl:when test="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value">
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0 and modification_id = $modification_id]/property_value[tag_name='color']/value"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>

			<xsl:if test="count(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0 and modification_id = $modification_id]/property_value[tag_name='color' and value = $value])">



				<xsl:variable name="imagelarge">
					<xsl:choose>
						<xsl:when test="//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large != ''">
							<xsl:value-of select="//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/dir"/><xsl:value-of select="//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large"/>
						</xsl:when>
						<xsl:otherwise></xsl:otherwise>
					</xsl:choose>
				</xsl:variable>



				<xsl:variable name="discount">
					<xsl:choose>
						<xsl:when test="format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/discount,'#.00') &gt; 0">
						<xsl:value-of select="format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/discount + //shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/price, '### ##0', 'my')"/> руб.</xsl:when>
						<xsl:otherwise></xsl:otherwise>
					</xsl:choose>
				</xsl:variable>



				<li class="group__item group__item--color button_color prod_color" style="min-height: 40px; min-width: 40px; background: {description};" onclick="javascript:changeitem('{//shop_item[rest &gt; 0]/modifications/shop_item[rest  &gt; 0  and modification_id = $modification_id  and property_value[tag_name='color' and value = $value]]/url}','{$imagelarge}');" data-price="{format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/price, '### ##0', 'my')}" data-price-discount="{$discount}">



					<xsl:if test="$nowcolors = value ">
						<xsl:attribute name="class">group__item group__item--color button_color prod_color_act</xsl:attribute>
					</xsl:if>

					<input class="group__field visually-hidden" id="group-color-{@id}" name="color" value="color-{@id}" type="radio">
						<xsl:if test="$nowcolors = value ">
							<xsl:attribute name="checked"></xsl:attribute>
						</xsl:if>
					</input>

					<label class="group__label" for="group-color-{@id}">
						<xsl:if test="//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_small != '' ">
							<img class="group__color" data-img="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/dir}{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_large}" src="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/dir}{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/image_small}" data-id="{@id}" alt=""/>
						</xsl:if>
					</label>
					<input type="hidden" value="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color' and value = $value]]/@id}" class="input_id" name="input_id"/>

				</li>



			</xsl:if>

		</xsl:template>





		<xsl:template match="list/list_item" mode="size_not_color">

			<xsl:variable name="value" select="value"/>

			<xsl:variable name="nowsize2s" select="value"/>

			<xsl:variable name="modification_id">
				<xsl:choose>
					<xsl:when test="/shop/shop_item/modification_id = 0">
						<xsl:value-of select="/shop/shop_item/@id"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item/modification_id"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>

			<xsl:variable name="nowsizes">
				<xsl:choose>
					<xsl:when test="/shop/shop_item[rest &gt; 0]/property_value[tag_name='size']/value">
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/property_value[tag_name='size']/value"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="/shop/shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0]/property_value[tag_name='size']/value"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:variable>

			<xsl:variable name="discount">
				<xsl:choose>
					<xsl:when test="format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0   and modification_id = $modification_id  and property_value[tag_name='size' and value = $value]]/discount ,'#.00') &gt; 0">

					<xsl:value-of select="format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0   and modification_id = $modification_id  and property_value[tag_name='size' and value = $value]]/discount + //shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0   and modification_id = $modification_id  and property_value[tag_name='size' and value = $value]]/price, '### ##0', 'my')"/> руб.</xsl:when>
					<xsl:otherwise></xsl:otherwise>
				</xsl:choose>
			</xsl:variable>



			<xsl:if test="count(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0   and modification_id = $modification_id]/property_value[tag_name='size' and value = $value])">

				<li class="group__item button_color prod_size"  data-price="{format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0   and modification_id = $modification_id  and property_value[tag_name='size' and value = $value]]/price, '### ##0', 'my')}" data-price-discount="{$discount}" >
					<input class="group__field visually-hidden" id="group-size-{@id}" name="size" type="radio">
						<!--<xsl:if test="position() = 1">
						<xsl:attribute name="checked">checked</xsl:attribute>
					</xsl:if>-->
				</input>
				<label class="group__label" for="group-size-{@id}"><xsl:value-of disable-output-escaping="yes" select="value"/></label>

				<input type="hidden" value="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0   and modification_id = $modification_id  and property_value[tag_name='size' and value = $value]]/@id}" class="input_id" name="input_id"/>
			</li>







		</xsl:if>

	</xsl:template>


	<xsl:template match="list/list_item" mode="size">

		<xsl:variable name="value" select="value"/>

		<xsl:variable name="modification_id">
			<xsl:choose>
				<xsl:when test="/shop/shop_item/modification_id = 0">
					<xsl:value-of select="/shop/shop_item/@id"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="/shop/shop_item/modification_id"/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>

		<xsl:variable name="nowcolors">
			<xsl:choose>
				<xsl:when test="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value">
					<xsl:value-of disable-output-escaping="yes" select="/shop/shop_item[rest &gt; 0]/property_value[tag_name='color']/value"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of disable-output-escaping="yes" select="/shop/shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0]/property_value[tag_name='color']/value"/>
				</xsl:otherwise>
				<!--<xsl:otherwise>
				<xsl:value-of disable-output-escaping="yes" select="//shop_item_properties/property[tag_name='color']/list/list_item/value"/>
			</xsl:otherwise>-->
		</xsl:choose>
	</xsl:variable>


	<xsl:variable name="discount">
		<xsl:choose>

			<xsl:when test="format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0 and modification_id = $modification_id and property_value[tag_name='size' and value = $value]]/discount ,'#.00') &gt; 0">
				<xsl:value-of select="format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='size' and value = $value]]/discount + //shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id  and property_value[tag_name='size' and value = $value]]/price, '### ##0', 'my')"/> руб.
			</xsl:when>
			<xsl:otherwise></xsl:otherwise>
		</xsl:choose>
	</xsl:variable>


	<xsl:if test="//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color']/value = $nowcolors and property_value[tag_name='size']/value = $value]">




		<li class="group__item button_color prod_size"  data-price="{format-number(//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='size' and value = $value]]/price, '### ##0', 'my')}" data-price-discount="{$discount}" >
			<input class="group__field visually-hidden" id="group-size-{@id}" name="size" type="radio">
				<!--<xsl:if test="position() = 1">
				<xsl:attribute name="checked">checked</xsl:attribute>
			</xsl:if>-->
		</input>
		<label class="group__label" for="group-size-{@id}"><xsl:value-of disable-output-escaping="yes" select="value"/></label>

		<input type="hidden" value="{//shop_item[rest &gt; 0]/modifications/shop_item[rest &gt; 0  and modification_id = $modification_id and property_value[tag_name='color']/value = $nowcolors and property_value[tag_name='size']/value = $value]/@id}" class="input_id" name="input_id"/>
	</li>




</xsl:if>

</xsl:template>




<!-- Шаблон для товара просмотренные -->
<xsl:template match="shop_item" mode="view">


<div class="additional-goods__item">
	<div class="additional-goods__card product-item product-item--extra">
		<div class="product-item__top">

			<xsl:if test="property_value[tag_name='novinka']/value = 1">
				<p class="product-item__tag product-item__tag--new">Новинка</p>
			</xsl:if>

			<xsl:if test="discount != 0">
				<p class="product-item__tag product-item__tag--stock">Акция</p>
			</xsl:if>

			<xsl:if test="marking != ''">
				<p class="product-item__tag product-item__tag--article"><xsl:value-of select="marking"/></p>
			</xsl:if>


		</div>
		<div class="product-item__body">
			<div class="product-item__img-box">
				<a href="{url}">
					<xsl:choose>
						<xsl:when test="image_small != ''">
							<img src="{dir}{image_small}" alt="{name}" title="{name}" class="product-item__img"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="/images/t8903001/img/noimage.jpg" alt="{name}" title="{name}" class="product-item__img"/>
						</xsl:otherwise>
					</xsl:choose>
				</a>

			</div>
			<div class="product-item__text">
				<a href="{url}"><xsl:value-of select="name"/></a>
				<xsl:value-of disable-output-escaping="yes" select="description" />
			</div>
			<p class="product-item__price">

				<!-- Меняем цену если у товара есть модификации: берем самую дешевую модификацию и ставим "От" -->

				<xsl:choose>
					<xsl:when test="count(modifications/shop_item[rest &gt; 0 and price &gt; 0]) &gt; 0">
						<xsl:for-each select="modifications/shop_item[rest &gt; 0 and price &gt; 0]">
							<xsl:sort select="price" data-type="number"/>
							<xsl:if test="position() = 1">
								от <ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
								<xsl:if test="discount != 0">
									<xsl:text> </xsl:text><del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
								</xsl:if>
							</xsl:if>
						</xsl:for-each>
					</xsl:when>
					<xsl:otherwise>
						<xsl:choose>
							<xsl:when test="price != 0">
								<ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
							</xsl:when>
							<xsl:otherwise>
								<ins>Цену уточняйте</ins>
							</xsl:otherwise>
						</xsl:choose>
						<xsl:if test="discount != 0">
							<del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
						</xsl:if>
					</xsl:otherwise>
				</xsl:choose>
			</p>

			<!-- Меняем кнопку если у товара есть модификации (нечего класть в корзину) на ссылку на страницу товара -->

			<div class="product-item__add-to-cart">
				<xsl:choose>
					<xsl:when test="count(modifications/shop_item) &gt; 0">
						<a class="product-item__button button" href="{url}">Перейти к выбору</a>
					</xsl:when>
					<xsl:otherwise>

						<input class="product-item__quantity quantity" type="number" id="item-quantity{@id}" value="1" min="1"/>
						<a class="product-item__button button" href="{/shop/url}cart/?add={@id}" onclick="return $.addIntoCart('{/shop/url}cart/', {@id}, $('#item-quantity{@id}').val())">

							<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit']/value = 1">
								<xsl:attribute name="onclick">return $.addIntoCartComplex('<xsl:value-of select="/shop/url"/>cart/', $('#complex_form<xsl:value-of select="@id"/>'))</xsl:attribute>
							</xsl:if>

						В корзину</a>

						<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit']/value = 1">
							<form id="complex_form{@id}" style="display:none">
								<xsl:apply-templates select="set/shop_item[rest &gt; 0]" mode="catalog_complex_set"/>
							</form>
						</xsl:if>

					</xsl:otherwise>
				</xsl:choose>
			</div>


		</div>
	</div>
</div>


</xsl:template>

<!-- Вывод строки со значением свойства -->
<xsl:template match="property_value">
<xsl:if test="value/node() and value != '' or file/node() and file != ''">
	<div class="shop_property">
		<xsl:variable name="property_id" select="property_id" />
		<xsl:variable name="property" select="/shop/shop_item_properties//property[@id=$property_id]" />

		<xsl:value-of select="$property/name"/><xsl:text>: </xsl:text>
		<span><xsl:choose>
				<xsl:when test="$property/type = 2">
					<a href="{../dir}{file}" target="_blank"><xsl:value-of select="file_name"/></a>
				</xsl:when>
				<xsl:when test="$property/type = 5">
					<a href="{informationsystem_item/url}"><xsl:value-of select="informationsystem_item/name"/></a>
				</xsl:when>
				<xsl:when test="$property/type = 7">
					<input type="checkbox" disabled="disabled">
						<xsl:if test="value = 1">
							<xsl:attribute name="checked">checked</xsl:attribute>
						</xsl:if>
					</input>
				</xsl:when>
				<xsl:when test="$property/type = 12">
					<a href="{shop_item/url}"><xsl:value-of select="shop_item/name"/></a>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of disable-output-escaping="yes" select="value"/>
					<!-- Единица измерения свойства -->
					<xsl:if test="$property/shop_measure/node()">
						<xsl:text> </xsl:text><xsl:value-of select="$property/shop_measure/name"/>
					</xsl:if>
				</xsl:otherwise>
		</xsl:choose></span>
	</div>
</xsl:if>
</xsl:template>

<!-- Метки -->
<xsl:template match="tag">
<a href="{/shop/url}tag/{urlencode}/" class="tag">
	<xsl:value-of select="name"/>
</a>
<xsl:if test="position() != last()"><xsl:text>, </xsl:text></xsl:if>
</xsl:template>

<!-- Шаблон для модификаций -->
<xsl:template match="modifications/shop_item">
<li>
	<!-- Название модификации -->
	<a href="{url}"><xsl:value-of select="@id"/> - <xsl:value-of select="name"/></a>,
	<!-- Цена модификации -->
	<xsl:value-of select="price"/><xsl:text> </xsl:text><xsl:value-of disable-output-escaping="yes" select="currency"/>
</li>
</xsl:template>

<!-- Шаблон для сопутствующих товаров -->
<xsl:template match="associated/shop_item">
<div class="additional-goods__item">
	<div class="additional-goods__card product-item product-item--extra">
		<div class="product-item__top">

			<xsl:if test="property_value[tag_name='novinka']/value = 1">
				<p class="product-item__tag product-item__tag--new">Новинка</p>
			</xsl:if>

			<xsl:if test="discount != 0">
				<p class="product-item__tag product-item__tag--stock">Акция</p>
			</xsl:if>

			<xsl:if test="marking != ''">
				<p class="product-item__tag product-item__tag--article"><xsl:value-of select="marking"/></p>
			</xsl:if>


		</div>
		<div class="product-item__body">
			<div class="product-item__img-box">
				<a href="{url}">
					<xsl:choose>
						<xsl:when test="image_small != ''">
							<img src="{dir}{image_small}" alt="{name}" title="{name}" class="product-item__img"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="/images/t8903001/img/noimage.jpg" alt="{name}" title="{name}" class="product-item__img"/>
						</xsl:otherwise>
					</xsl:choose>
				</a>

			</div>
			<div class="product-item__text">
				<a href="{url}"><xsl:value-of select="name"/></a>
				<xsl:value-of disable-output-escaping="yes" select="description" />
			</div>
			<p class="product-item__price">

				<!-- Меняем цену если у товара есть модификации: берем самую дешевую модификацию и ставим "От" -->

				<xsl:choose>
					<xsl:when test="count(modifications/shop_item[rest &gt; 0 and price &gt; 0]) &gt; 0">
						<xsl:for-each select="modifications/shop_item[rest &gt; 0 and price &gt; 0]">
							<xsl:sort select="price"  data-type="number"/>
							<xsl:if test="position() = 1">
								от <ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
								<xsl:if test="discount != 0">
									<xsl:text> </xsl:text><del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
								</xsl:if>
							</xsl:if>
						</xsl:for-each>
					</xsl:when>
					<xsl:otherwise>
						<xsl:choose>
							<xsl:when test="price != 0">
								<ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
							</xsl:when>
							<xsl:otherwise>
								<ins>Цену уточняйте</ins>
							</xsl:otherwise>
						</xsl:choose>
						<xsl:if test="discount != 0">
							<del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
						</xsl:if>
					</xsl:otherwise>
				</xsl:choose>
			</p>

			<!-- Меняем кнопку если у товара есть модификации (нечего класть в корзину) на ссылку на страницу товара -->

			<div class="product-item__add-to-cart">
				<xsl:choose>
					<xsl:when test="count(modifications/shop_item) &gt; 0">
						<a class="product-item__button button" href="{url}">Перейти к выбору</a>
					</xsl:when>
					<xsl:otherwise>

						<input class="product-item__quantity quantity" type="number" id="item-quantity{@id}" value="1" min="1"/>
						<a class="product-item__button button" href="{/shop/url}cart/?add={@id}" onclick="return $.addIntoCart('{/shop/url}cart/', {@id}, $('#item-quantity{@id}').val())">

							<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit']/value = 1">
								<xsl:attribute name="onclick">return $.addIntoCartComplex('<xsl:value-of select="/shop/url"/>cart/', $('#complex_form<xsl:value-of select="@id"/>'))</xsl:attribute>
							</xsl:if>

						В корзину</a>

						<xsl:if test="count(set/shop_item) != 0 and property_value[tag_name='complect_edit']/value = 1">
							<form id="complex_form{@id}" style="display:none">
								<xsl:apply-templates select="set/shop_item[rest &gt; 0]" mode="catalog_complex_set"/>
							</form>
						</xsl:if>

					</xsl:otherwise>
				</xsl:choose>
			</div>

		</div>
	</div>
</div>
</xsl:template>



<xsl:template match="set/shop_item" mode="complect_edit">
<xsl:variable name="shop_item_id" select="@id"/>

<div class="complex__item">

	<xsl:choose>
		<xsl:when test="image_small != ''">
			<a href="{dir}{image_large}" data-fancybox="images"><img src="{dir}{image_small}" alt="{name}" title="{name}" class="product-item__img"/></a>
		</xsl:when>
		<xsl:otherwise>
			<img src="/images/t8903001/img/noimage.jpg" alt="{name}" title="{name}" class="product-item__img"/>
		</xsl:otherwise>
	</xsl:choose>

	<h4 title="{name}">
		<a href="{url}">
			<xsl:value-of select="name"/>
		</a>
	</h4>

	<div class="complex_price">

		<span class="price_one">

			<xsl:choose>
				<xsl:when test="price != 0">
					Цена за шт.: <ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
				</xsl:when>
				<xsl:otherwise>
					<ins>Цену уточняйте</ins>
				</xsl:otherwise>
			</xsl:choose>

			<!--<xsl:if test="discount != 0">
			<del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
		</xsl:if>-->

	</span>

	<xsl:if test="price != 0">
		<span class="price" id="price_{@id}" data-price="{format-number(price, '#####0', 'my')}">
			Сумма:
			<xsl:choose>
				<xsl:when test="price != 0">
					<ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
				</xsl:when>
				<xsl:otherwise>
					<ins>уточнайте</ins>
				</xsl:otherwise>
			</xsl:choose>

			<!--<xsl:if test="discount != 0">
			<del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
		</xsl:if>-->

</span></xsl:if>

</div>

<div class="count">
<input type="hidden" id="shop_item_id_{@id}" name="add[]" value="{@id}"/>
<input type="number" min="0" id="count_{@id}" class="product-card__quantity quantity product_count" name="count[]"
value="{format-number(count, '#####0', 'my')}"  data-defoultcount="{count}" autocomplete="off"/>
</div>

<div class="links">

<a class="product-card__button button button--common"  href="{/shop/url}cart/?add={@id}" onclick="return $.addIntoCart('{/shop/url}cart/', '{@id}', $('#count_{@id}').val())"> </a>


<a class="product-card__wish-list-link" href="javascript:void(0);" title="Добавить в избранное" onclick="return $.addFavorite('{/shop/url}favorite/', '{@id}', this)">
	<xsl:variable name="shop_item_id2" select="@id" />
	<xsl:if test="/shop/favorite/shop_item[@id = $shop_item_id2]/node()">
		<xsl:attribute name="class">product-card__wish-list-link product-card__wish-list-link--added</xsl:attribute>
	</xsl:if>

</a>


</div>
<a href="javascript:void(0);" class="complex__item__remove"></a>
</div>
</xsl:template>



<!--  Шаблон для товаров коллекции -->
<xsl:template match="modifications/shop_item" mode="collection">
<xsl:variable name="shop_item_id" select="@id"/>

<div class="complex__item">

<xsl:choose>
<xsl:when test="image_small != ''">
	<a href="{dir}{image_large}" data-fancybox="images"><img src="{dir}{image_small}" alt="{name}" title="{name}" class="product-item__img"/></a>
</xsl:when>
<xsl:otherwise>
	<img src="/images/t8903001/img/noimage.jpg" alt="{name}" title="{name}" class="product-item__img"/>
</xsl:otherwise>
</xsl:choose>

<h4 title="{name}">
<a href="{url}">
	<xsl:value-of select="name"/>
</a>
</h4>



<div class="complex_price">

<span class="price_one">


	<xsl:variable name="shop_measure">
		<xsl:choose>
			<xsl:when test="shop_measure/name != ''">
				<xsl:value-of select="shop_measure/name"/>
			</xsl:when>
			<xsl:otherwise>
				шт.
			</xsl:otherwise>
		</xsl:choose>
	</xsl:variable>


	<xsl:choose>
		<xsl:when test="price != 0">
			Цена за <xsl:value-of select="$shop_measure" />: <ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
		</xsl:when>
		<xsl:otherwise>
			<ins>Цену уточняйте</ins>
		</xsl:otherwise>
	</xsl:choose>

	<!--<xsl:if test="discount != 0">
	<del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
</xsl:if>-->

</span>



</div>

<div class="count">
<input type="hidden" id="shop_item_id_{@id}" name="add[]" value="{@id}"/>
<input type="number" min="0" id="count_{@id}" class="product-card__quantity quantity product_count" name="count[]"
value="0"  data-defoultcount="0" autocomplete="off"/>
</div>

<div class="links">

<a class="product-card__button button button--common"  href="{/shop/url}cart/?add={@id}" onclick="return $.addIntoCart('{/shop/url}cart/', '{@id}', $('#count_{@id}').val())"> </a>


<a class="product-card__wish-list-link" href="javascript:void(0);" title="Добавить в избранное" onclick="return $.addFavorite('{/shop/url}favorite/', '{@id}', this)">
<xsl:variable name="shop_item_id2" select="@id" />
<xsl:if test="/shop/favorite/shop_item[@id = $shop_item_id2]/node()">
	<xsl:attribute name="class">product-card__wish-list-link product-card__wish-list-link--added</xsl:attribute>
</xsl:if>

</a>


</div>

</div>
</xsl:template>




<!-- Шаблон для товаров комплекта -->
<xsl:template match="set/shop_item">
<div class="additional-goods__item">
<div class="additional-goods__card product-item product-item--extra">
<div class="product-item__top">

<xsl:if test="property_value[tag_name='novinka']/value = 1">
	<p class="product-item__tag product-item__tag--new">Новинка</p>
</xsl:if>

<xsl:if test="discount != 0">
	<p class="product-item__tag product-item__tag--stock">Акция</p>
</xsl:if>

<xsl:if test="marking != ''">
	<p class="product-item__tag product-item__tag--article"><xsl:value-of select="marking"/></p>
</xsl:if>


</div>
<div class="product-item__body">
<div class="product-item__img-box">
	<a href="{url}">
		<xsl:choose>
			<xsl:when test="image_small != ''">
				<img src="{dir}{image_small}" alt="{name}" title="{name}" class="product-item__img"/>
			</xsl:when>
			<xsl:otherwise>
				<img src="/images/t8903001/img/noimage.jpg" alt="{name}" title="{name}" class="product-item__img"/>
			</xsl:otherwise>
		</xsl:choose>
	</a>

</div>
<div class="product-item__text">
	<a href="{url}"><xsl:value-of select="name"/></a>
	<xsl:value-of disable-output-escaping="yes" select="description" />
</div>
<p class="product-item__price">

	<xsl:choose>
		<xsl:when test="price != 0">
			<ins><strong><xsl:value-of select="format-number(price, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></ins>
		</xsl:when>
		<xsl:otherwise>
			<ins>Цену уточняйте</ins>
		</xsl:otherwise>
	</xsl:choose>

	<xsl:if test="discount != 0">
		<del><strong><xsl:value-of select="format-number(price + discount, '### ##0', 'my')"/></strong><xsl:text> </xsl:text><xsl:value-of select="currency" /></del>
	</xsl:if>
</p>

<div class="product-item__add-to-cart">
	<input class="product-item__quantity quantity" type="number" id="item-quantity{@id}" value="1" min="1"/>
	<a class="product-item__button button" href="{/shop/url}cart/?add={@id}" onclick="return $.addIntoCart('{/shop/url}cart/', '{@id}', $('#item-quantity{@id}').val())">В корзину</a>
</div>
</div>
</div>
</div>
</xsl:template>



<!-- Вывод рейтинга -->
<xsl:template name="show_average_grade">
<xsl:param name="grade" select="0"/>
<xsl:param name="const_grade" select="0"/>

<!-- Чтобы избежать зацикливания -->
<xsl:variable name="current_grade" select="$grade * 1"/>

<xsl:choose>
<!-- Если число целое -->
<xsl:when test="floor($current_grade) = $current_grade and not($const_grade &gt; ceiling($current_grade))">

<xsl:if test="$current_grade - 1 &gt; 0">
<xsl:call-template name="show_average_grade">
	<xsl:with-param name="grade" select="$current_grade - 1"/>
	<xsl:with-param name="const_grade" select="$const_grade - 1"/>
</xsl:call-template>
</xsl:if>

<xsl:if test="$current_grade != 0">
<img src="/images/star-full.png"/>
</xsl:if>
</xsl:when>
<xsl:when test="$current_grade != 0 and not($const_grade &gt; ceiling($current_grade))">

<xsl:if test="$current_grade - 0.5 &gt; 0">
<xsl:call-template name="show_average_grade">

	<xsl:with-param name="grade" select="$current_grade - 0.5"/>
	<xsl:with-param name="const_grade" select="$const_grade - 1"/>
</xsl:call-template>
</xsl:if>

<img src="/images/star-half.png"/>
</xsl:when>

<!-- Выводим серые звездочки, пока текущая позиция не дойдет то значения, увеличенного до целого -->
<xsl:otherwise>
<xsl:call-template name="show_average_grade">
<xsl:with-param name="grade" select="$current_grade"/>
<xsl:with-param name="const_grade" select="$const_grade - 1"/>
</xsl:call-template>
<img src="/images/star-empty.png"/>
</xsl:otherwise>
</xsl:choose>
</xsl:template>

<!-- Шаблон для вывода звездочек (оценки) -->
<xsl:template name="for">
<xsl:param name="i" select="0"/>
<xsl:param name="n"/>

<input type="radio" name="shop_grade" value="{$i}" id="id_shop_grade_{$i}">
<xsl:if test="/shop/shop_grade = $i">
<xsl:attribute name="checked"></xsl:attribute>
</xsl:if>
</input><xsl:text> </xsl:text>
<label for="id_shop_grade_{$i}">
<xsl:call-template name="show_average_grade">
<xsl:with-param name="grade" select="$i"/>
<xsl:with-param name="const_grade" select="5"/>
</xsl:call-template>
</label>
<br/>
<xsl:if test="$n &gt; $i and $n &gt; 1">
<xsl:call-template name="for">
<xsl:with-param name="i" select="$i + 1"/>
<xsl:with-param name="n" select="$n"/>
</xsl:call-template>
</xsl:if>
</xsl:template>

<!-- Отображение комментариев -->
<xsl:template match="comment">
<!-- Отображаем комментарий, если задан текст или тема комментария -->
<xsl:if test="text != '' or subject != ''">
<a name="comment{@id}"></a>
<div class="comment" id="comment{@id}">
<xsl:if test="subject != ''">
<div class="subject" hostcms:id="{@id}" hostcms:field="subject" hostcms:entity="comment"><xsl:value-of select="subject"/></div>
</xsl:if>

<div hostcms:id="{@id}" hostcms:field="text" hostcms:entity="comment" hostcms:type="wysiwyg"><xsl:value-of select="text" disable-output-escaping="yes"/></div>

<p class="tags">
<!-- Оценка комментария -->
<xsl:if test="grade != 0">
	<span><xsl:call-template name="show_average_grade">
			<xsl:with-param name="grade" select="grade"/>
			<xsl:with-param name="const_grade" select="5"/>
	</xsl:call-template></span>
</xsl:if>

<img src="/images/user.png" />
<xsl:choose>
	<!-- Комментарий добавил авторизированный пользователь -->
	<xsl:when test="count(siteuser) &gt; 0">
		<span><a href="/users/info/{siteuser/path}/"><xsl:value-of select="siteuser/login"/></a></span>
	</xsl:when>
	<!-- Комментарй добавил неавторизированный пользователь -->
	<xsl:otherwise>
		<span><xsl:value-of select="author" /></span>
	</xsl:otherwise>
</xsl:choose>

<xsl:if test="rate/node()">
	<span id="comment_id_{@id}" class="thumbs">
		<xsl:choose>
			<xsl:when test="/shop/siteuser_id > 0">
				<xsl:choose>
					<xsl:when test="vote/value = 1">
						<xsl:attribute name="class">thumbs up</xsl:attribute>
					</xsl:when>
					<xsl:when test="vote/value = -1">
						<xsl:attribute name="class">thumbs down</xsl:attribute>
					</xsl:when>
				</xsl:choose>

				<span id="comment_likes_{@id}"><xsl:value-of select="rate/@likes" /></span>
				<span class="inner_thumbs">
					<a onclick="return $.sendVote({@id}, 1, 'comment')" href="{/shop/url}?id={@id}&amp;vote=1&amp;entity_type=comment" alt="Нравится"></a>
					<span class="rate" id="comment_rate_{@id}"><xsl:value-of select="rate" /></span>
					<a onclick="return $.sendVote({@id}, 0, 'comment')" href="{/shop/url}?id={@id}&amp;vote=0&amp;entity_type=comment" alt="Не нравится"></a>
				</span>
				<span id="comment_dislikes_{@id}"><xsl:value-of select="rate/@dislikes" /></span>
			</xsl:when>
			<xsl:otherwise>
				<xsl:attribute name="class">thumbs inactive</xsl:attribute>
				<span id="comment_likes_{@id}"><xsl:value-of select="rate/@likes" /></span>
				<span class="inner_thumbs">
					<a alt="Нравится"></a>
					<span class="rate" id="comment_rate_{@id}"><xsl:value-of select="rate" /></span>
					<a alt="Не нравится"></a>
				</span>
				<span id="comment_dislikes_{@id}"><xsl:value-of select="rate/@dislikes" /></span>
			</xsl:otherwise>
		</xsl:choose>
	</span>
</xsl:if>

<img src="/images/calendar.png" /> <span><xsl:value-of select="datetime"/></span>

<xsl:if test="/shop/show_add_comments/node()
	and ((/shop/show_add_comments = 1 and /shop/siteuser_id > 0)
	or /shop/show_add_comments = 2)">
<span class="red" onclick="$('.comment_reply').hide('slow');$('#cr_{@id}').toggle('slow')">ответить</span></xsl:if>

<span class="red"><a href="{/shop/shop_item/url}#comment{@id}" title="Ссылка на комментарий">#</a></span>
</p>
</div>

<!-- Отображаем только авторизированным пользователям -->
<xsl:if test="/shop/show_add_comments/node() and ((/shop/show_add_comments = 1 and /shop/siteuser_id > 0) or /shop/show_add_comments = 2)">
<div class="comment_reply" id="cr_{@id}">
<xsl:call-template name="AddCommentForm">
	<xsl:with-param name="id" select="@id"/>
</xsl:call-template>
</div>
</xsl:if>

<!-- Выбираем дочерние комментарии -->
<xsl:if test="count(comment)">
<div class="comment_sub">
<xsl:apply-templates select="comment"/>
</div>
</xsl:if>
</xsl:if>
</xsl:template>

<!-- Шаблон вывода добавления комментария -->
<xsl:template name="AddCommentForm">
<xsl:param name="id" select="0"/>

<!-- Заполняем форму -->
<xsl:variable name="subject">
<xsl:if test="/shop/comment/parent_id/node() and /shop/comment/parent_id/node() and /shop/comment/parent_id= $id">
<xsl:value-of select="/shop/comment/subject"/>
</xsl:if>
</xsl:variable>
<xsl:variable name="email">
<xsl:if test="/shop/comment/email/node() and /shop/comment/parent_id/node() and /shop/comment/parent_id= $id">
<xsl:value-of select="/shop/comment/email"/>
</xsl:if>
</xsl:variable>
<xsl:variable name="phone">
<xsl:if test="/shop/comment/phone/node() and /shop/comment/parent_id/node() and /shop/comment/parent_id= $id">
<xsl:value-of select="/shop/comment/phone"/>
</xsl:if>
</xsl:variable>
<xsl:variable name="text">
<xsl:if test="/shop/comment/text/node() and /shop/comment/parent_id/node() and /shop/comment/parent_id= $id">
<xsl:value-of select="/shop/comment/text"/>
</xsl:if>
</xsl:variable>
<xsl:variable name="name">
<xsl:if test="/shop/comment/author/node() and /shop/comment/parent_id/node() and /shop/comment/parent_id= $id">
<xsl:value-of select="/shop/comment/author"/>
</xsl:if>
</xsl:variable>

<div class="comment">
<!--Отображение формы добавления комментария-->
<form action="{/shop/shop_item/url}" name="comment_form_0{$id}" method="post">
<!-- Авторизированным не показываем -->
<xsl:if test="/shop/siteuser_id = 0">

<div class="row">
	<div class="caption">Имя</div>
	<div class="field">
		<input type="text" size="70" name="author" value="{$name}"/>
	</div>
</div>

<div class="row">
	<div class="caption">E-mail</div>
	<div class="field">
		<input id="email{$id}" type="text" size="70" name="email" value="{$email}" />
		<div id="error_email{$id}"></div>
	</div>
</div>

<div class="row">
	<div class="caption">Телефон</div>
	<div class="field">
		<input type="text" size="70" name="phone" value="{$phone}"/>
	</div>
</div>
</xsl:if>

<div class="row">
<div class="caption">Тема</div>
<div class="field">
	<input type="text" size="70" name="subject" value="{$subject}"/>
</div>
</div>

<div class="row">
<div class="caption">Комментарий</div>
<div class="field">
	<textarea name="text" cols="68" rows="5" class="mceEditor"><xsl:value-of select="$text"/></textarea>
</div>
</div>

<div class="row">
<div class="caption">Оценка</div>
<div class="field stars">
	<select name="grade">
		<option value="1">Poor</option>
		<option value="2">Fair</option>
		<option value="3">Average</option>
		<option value="4">Good</option>
		<option value="5">Excellent</option>
	</select>
</div>
</div>

<!-- Обработка CAPTCHA -->
<xsl:if test="//captcha_id != 0 and /shop/siteuser_id = 0">
<div class="row">
	<div class="caption"></div>
	<div class="field">
		<img id="comment_{$id}" class="captcha" src="/captcha.php?id={//captcha_id}{$id}&amp;height=30&amp;width=100" title="Контрольное число" name="captcha"/>

		<div class="captcha">
			<img src="/images/refresh.png" /> <span onclick="$('#comment_{$id}').updateCaptcha('{//captcha_id}{$id}', 30); return false">Показать другое число</span>
		</div>
	</div>
</div>

<div class="row">
	<div class="caption">
		Контрольное число<sup><font color="red">*</font></sup>
	</div>
	<div class="field">
		<input type="hidden" name="captcha_id" value="{//captcha_id}{$id}"/>
		<input type="text" name="captcha" size="15"/>
	</div>
</div>
</xsl:if>

<xsl:if test="$id != 0">
<input type="hidden" name="parent_id" value="{$id}"/>
</xsl:if>

<div class="row">
<div class="caption"></div>
<div class="field">
	<input id="submit_email{$id}" type="submit" name="add_comment" value="Опубликовать" class="button" />
</div>
</div>
</form>
</div>
</xsl:template>

<!-- Шаблон для скидки -->
<xsl:template match="shop_discount">
<div class="shop_discount">
<xsl:value-of select="name"/><xsl:text> </xsl:text>
<span>
<xsl:choose>
<xsl:when test="type = 0">
	<xsl:value-of select="percent"/>%
</xsl:when>
<xsl:otherwise>
	<xsl:value-of select="amount"/><xsl:text> </xsl:text><xsl:value-of select="/shop/shop_currency/name"/>
</xsl:otherwise>
</xsl:choose>
</span>
</div>
</xsl:template>

<!-- Шаблон выводит хлебные крошки -->
<xsl:template match="shop_group" mode="breadCrumbs">
<xsl:variable name="parent_id" select="parent_id"/>

<!-- Выбираем рекурсивно вышестоящую группу -->
<xsl:apply-templates select="//shop_group[@id=$parent_id]" mode="breadCrumbs"/>

<xsl:if test="parent_id=0">
<a href="{/shop/url}" hostcms:id="{/shop/@id}" hostcms:field="name" hostcms:entity="shop">
<xsl:value-of select="/shop/name"/>
</a>
</xsl:if>

<span><xsl:text> → </xsl:text></span>

<a href="{url}" hostcms:id="{@id}" hostcms:field="name" hostcms:entity="shop_group">
<xsl:value-of select="name"/>
</a>
</xsl:template>

<!-- Склонение после числительных -->
<xsl:template name="declension">

<xsl:param name="number" select="number"/>

<!-- Именительный падеж -->
<xsl:variable name="nominative"><xsl:text>просмотр</xsl:text></xsl:variable>

<!-- Родительный падеж, единственное число -->
<xsl:variable name="genitive_singular"><xsl:text>просмотра</xsl:text></xsl:variable>

<xsl:variable name="genitive_plural"><xsl:text>просмотров</xsl:text></xsl:variable>
<xsl:variable name="last_digit"><xsl:value-of select="$number mod 10"/></xsl:variable>
<xsl:variable name="last_two_digits"><xsl:value-of select="$number mod 100"/></xsl:variable>

<xsl:choose>
<xsl:when test="$last_digit = 1 and $last_two_digits != 11">
<xsl:value-of select="$nominative"/>
</xsl:when>
<xsl:when test="$last_digit = 2 and $last_two_digits != 12
or $last_digit = 3 and $last_two_digits != 13
or $last_digit = 4 and $last_two_digits != 14">
<xsl:value-of select="$genitive_singular"/>
</xsl:when>
<xsl:otherwise>
<xsl:value-of select="$genitive_plural"/>
</xsl:otherwise>
</xsl:choose>
</xsl:template>
</xsl:stylesheet>