/* Native gallery enhancement. No new Slick initialization, unslick, AJAX or purchase handlers. */
(function () {
  'use strict';
  var galleryStates = new WeakMap();
  var initializedSpecs = new WeakSet();
  var sequence = 0;
  var icons = {
    prev:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 6-6 6 6 6"/></svg>',
    next:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m10 6 6 6-6 6"/></svg>',
    close:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>',
    zoom:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5M7.5 10.5h6M10.5 7.5v6"/></svg>'
  };
  function reducedMotion() { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
  function createButton(className, label, icon) {
    var button = document.createElement('button');
    button.type = 'button'; button.className = className;
    button.setAttribute('aria-label', label); button.title = label;
    if (icon) button.innerHTML = icons[icon];
    return button;
  }
  function nativeSlick(state) {
    var jq = window.jQuery;
    if (!jq || !jq.fn || !jq.fn.slick || !state.gallery.classList.contains('slick-initialized')) return null;
    try { return jq(state.gallery).slick('getSlick'); } catch (ignored) { return null; }
  }
  function originalNodes(container, selector) {
    return Array.prototype.filter.call(container.querySelectorAll(selector), function (node) {
      return !node.closest('.slick-cloned');
    });
  }
  function slidePhoto(slide) {
    return slide.getAttribute('data-ks-slide-kind') === 'info' ? null : slide.querySelector('img');
  }
  function photoSource(image) {
    if (!image) return null;
    var link = image.closest('a[href]');
    var source = image.getAttribute('src');
    var sourceBefore = image.getAttribute('data-ks-photo-source');
    var full = !sourceBefore || sourceBefore === source ? image.getAttribute('data-ks-photo-full') : '';
    var raw = full || image.getAttribute('data-zoom-src') ||
      (link ? link.getAttribute('href') : '') || image.currentSrc || source;
    if (!raw) return null;
    try {
      var url = new URL(raw, document.baseURI);
      return /^(https?:|blob:)$/.test(url.protocol) ? url.href : null;
    } catch (ignored) { return null; }
  }
  function attachHoverZoom(state) {
    if (!window.matchMedia) return;
    var canHover = window.matchMedia('(hover: hover) and (pointer: fine)');
    var overlay = null;
    var frame = 0;
    var point = null;
    var activeImage = null;
    var activeSource = '';
    var detail = null;

    function reset() {
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
      point = null;
      activeImage = null;
      activeSource = '';
      detail = null;
      if (overlay) overlay.remove();
      overlay = null;
    }

    function paint() {
      frame = 0;
      var image = point.image;
      var slide = state.slides[state.index];
      if (!slide || slidePhoto(slide) !== image || !image.naturalWidth || !image.naturalHeight) {
        reset();
        return;
      }
      var bounds = image.getBoundingClientRect();
      var windowBounds = slide.getBoundingClientRect();
      var fit = Math.min(bounds.width / image.naturalWidth, bounds.height / image.naturalHeight);
      if (fit <= 0) return;
      var width = image.naturalWidth * fit;
      var height = image.naturalHeight * fit;
      var x = bounds.left + (bounds.width - width) / 2;
      var y = bounds.top + (bounds.height - height) / 2;
      var cursorX = Math.min(width, Math.max(0, point.x - x));
      var cursorY = Math.min(height, Math.max(0, point.y - y));
      var fullSource = photoSource(image);
      if (!fullSource) return;
      if (activeImage !== image || activeSource !== fullSource) {
        if (overlay) overlay.remove();
        overlay = null;
        activeImage = image;
        activeSource = fullSource;
        var original = new Image();
        detail = original;
        original.onload = function () {
          if (detail === original && point && !frame) frame = requestAnimationFrame(paint);
        };
        original.src = fullSource;
      }
      if (!detail || !detail.naturalWidth || !detail.naturalHeight) return;

      // Account for the real file and the screen density. A small preview must
      // never be drawn bigger than its source pixels merely to mimic zoom.
      var density = Math.max(1, window.devicePixelRatio || 1);
      var scale = Math.min(2.15, detail.naturalWidth / (width * density),
        detail.naturalHeight / (height * density));
      if (scale <= 1.06) {
        if (overlay) overlay.remove();
        overlay = null;
        return;
      }
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'ks-pdp-inplace-zoom';
        overlay.setAttribute('aria-hidden', 'true');
        overlay.style.backgroundImage = 'url(' + JSON.stringify(fullSource) + ')';
        slide.appendChild(overlay);
      }
      overlay.setAttribute('data-ks-zoom-scale', scale.toFixed(3));
      overlay.style.backgroundSize = (width * scale) + 'px ' + (height * scale) + 'px';
      overlay.style.backgroundPosition = (x - windowBounds.left + cursorX * (1 - scale)) +
        'px ' + (y - windowBounds.top + cursorY * (1 - scale)) + 'px';
    }

    state.resetHoverZoom = reset;
    state.gallery.addEventListener('pointermove', function (event) {
      if (!canHover.matches || event.pointerType !== 'mouse' || event.buttons || event.target.tagName !== 'IMG') {
        reset();
        return;
      }
      point = {image:event.target, x:event.clientX, y:event.clientY};
      if (!frame) frame = requestAnimationFrame(paint);
    }, {passive:true});
    state.gallery.addEventListener('pointerleave', reset, {passive:true});
    state.gallery.addEventListener('pointercancel', reset, {passive:true});
    state.gallery.addEventListener('pointerdown', reset, {passive:true});
    if (canHover.addEventListener) canHover.addEventListener('change', reset);
  }
  function updateGallery(state) {
    var slick = nativeSlick(state);
    if (slick) {
      state.mode = 'slick';
      state.index = ((slick.currentSlide || 0) % state.slides.length + state.slides.length) % state.slides.length;
    }
    state.root.setAttribute('data-ks-gallery-mode', state.mode);
    var changedSlide = state.renderedIndex !== state.index;
    if (changedSlide && state.resetHoverZoom) state.resetHoverZoom();
    state.renderedIndex = state.index;
    state.slides.forEach(function (slide, index) {
      var active = index === state.index;
      slide.classList.toggle('ks-pdp-slide-active', active);
      slide.setAttribute('role', 'group');
      slide.setAttribute('aria-roledescription', 'слайд');
      slide.setAttribute('aria-label', (index + 1) + ' из ' + state.slides.length);
      // Slick owns its outer slide's visibility. Never set hidden on native slides.
      if (state.mode === 'fallback') slide.setAttribute('aria-hidden', String(!active));
      else slide.removeAttribute('aria-hidden');
      var zoom = slide.querySelector('[data-ks-photo-zoom]');
      if (zoom) zoom.tabIndex = active ? 0 : -1;
    });
    state.root.querySelectorAll('[data-ks-gallery-thumb]').forEach(function (thumb) {
      var index = Number(thumb.getAttribute('data-ks-gallery-thumb'));
      var active = index === state.index;
      thumb.setAttribute('aria-pressed', String(active));
      thumb.tabIndex = active && !thumb.closest('.slick-cloned') ? 0 : -1;
    });
    // Focusing a thumbnail can scroll Slick's clipped viewport as well as its track.
    var thumbViewport = state.root.querySelector('.gallery-side .slick-list');
    if (thumbViewport && thumbViewport.scrollTop) thumbViewport.scrollTop = 0;
    var selectedThumb = state.railThumbs[state.index];
    if (changedSlide && selectedThumb && selectedThumb.parentElement.clientWidth) {
      var rail = selectedThumb.parentElement;
      var railBounds = rail.getBoundingClientRect();
      var thumbBounds = selectedThumb.getBoundingClientRect();
      if (thumbBounds.left < railBounds.left) rail.scrollLeft += thumbBounds.left - railBounds.left;
      else if (thumbBounds.right > railBounds.right) rail.scrollLeft += thumbBounds.right - railBounds.right;
      if (thumbBounds.top < railBounds.top) rail.scrollTop += thumbBounds.top - railBounds.top;
      else if (thumbBounds.bottom > railBounds.bottom) rail.scrollTop += thumbBounds.bottom - railBounds.bottom;
    }
    state.count.textContent = (state.index + 1) + ' / ' + state.slides.length;
    state.previous.disabled = state.next.disabled = state.slides.length < 2;
  }
  function scheduleGallery(state) {
    if (state.scheduled) return;
    state.scheduled = true;
    requestAnimationFrame(function () {
      state.scheduled = false;
      updateGallery(state);
    });
  }
  function goTo(state, nextIndex, focusThumb) {
    var count = state.slides.length;
    if (!count) return;
    var index = (nextIndex % count + count) % count;
    var slick = nativeSlick(state);
    if (slick) {
      state.mode = 'slick';
      if (slick.currentSlide !== index) window.jQuery(state.gallery).slick('slickGoTo', index, reducedMotion());
      state.index = index;
    } else {
      state.mode = 'fallback'; state.index = index;
    }
    // Roving thumbnail state is updated after Slick's own initADA completes.
    scheduleGallery(state);
    if (focusThumb) {
      var buttons = state.railThumbs.length ? state.railThumbs : state.thumbs;
      if (buttons[index]) { buttons[index].tabIndex = 0;buttons[index].focus({preventScroll:true}); }
    }
  }
  function makeLightbox(state) {
    if (state.dialog) return state.dialog;
    var dialog = document.createElement('dialog');
    dialog.className = 'ks-pdp-lightbox';
    dialog.id = state.id + '-zoom';
    dialog.setAttribute('aria-label', 'Фотографии товара');
    var head = document.createElement('div'); head.className = 'ks-pdp-lightbox__head';
    var title = document.createElement('p'); title.textContent = 'Фотографии товара';
    var close = createButton('', 'Закрыть просмотр фотографии', 'close');
    head.appendChild(title); head.appendChild(close);
    var figure = document.createElement('figure');
    var image = document.createElement('img'); image.decoding = 'async'; image.alt = '';
    var caption = document.createElement('figcaption');
    figure.appendChild(image); figure.appendChild(caption);
    var controls = document.createElement('div'); controls.className = 'ks-pdp-lightbox__controls';
    var previous = createButton('', 'Предыдущая фотография', 'prev');
    var next = createButton('', 'Следующая фотография', 'next');
    var count = document.createElement('p'); count.setAttribute('aria-live', 'polite'); count.setAttribute('aria-atomic', 'true');
    controls.appendChild(previous); controls.appendChild(count); controls.appendChild(next);
    dialog.appendChild(head); dialog.appendChild(figure); dialog.appendChild(controls);
    document.body.appendChild(dialog);
    state.dialog = dialog; state.dialogImage = image; state.dialogCaption = caption;
    state.dialogCount = count; state.dialogPrevious = previous; state.dialogNext = next;
    function move(offset) { showPhoto(state, state.photoIndex + offset); }
    close.addEventListener('click', function () { dialog.close(); });
    previous.addEventListener('click', function () { move(-1); });
    next.addEventListener('click', function () { move(1); });
    dialog.addEventListener('click', function (event) {
      if (event.target === dialog) {
        var rect = dialog.getBoundingClientRect();
        if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
      }
    });
    dialog.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight' || event.key === 'Home' || event.key === 'End') {
        event.preventDefault(); event.stopPropagation();
        if (event.key === 'Home') showPhoto(state, 0);
        else if (event.key === 'End') showPhoto(state, state.photos.length - 1);
        else move(event.key === 'ArrowLeft' ? -1 : 1);
      }
    });
    dialog.addEventListener('close', function () {
      if (!document.querySelector('.ks-pdp-lightbox[open]')) document.documentElement.classList.remove('ks-pdp-modal-open');
      if (state.photoTrigger && state.photoTrigger.isConnected) state.photoTrigger.focus({preventScroll:true});
    });
    return dialog;
  }
  function showPhoto(state, index) {
    var length = state.photos.length;
    if (!length) return;
    state.photoIndex = (index % length + length) % length;
    var photo = state.photos[state.photoIndex];
    var image = slidePhoto(photo.slide);
    var source = photoSource(image);
    if (!source) return;
    var alt = image.alt || 'Фотография товара ' + (state.photoIndex + 1);
    state.dialogImage.src = source;
    state.dialogImage.alt = alt;
    state.dialogCaption.textContent = alt;
    state.dialogCount.textContent = (state.photoIndex + 1) + ' / ' + length;
    state.dialogPrevious.disabled = state.dialogNext.disabled = length < 2;
  }
  function openPhoto(state, slide, trigger) {
    var index = state.photos.findIndex(function (photo) { return photo.slide === slide; });
    if (index < 0) return;
    var source = photoSource(slidePhoto(slide));
    if (!source) return;
    if (state.resetHoverZoom) state.resetHoverZoom();
    var dialog = makeLightbox(state);
    if (typeof dialog.showModal !== 'function') {
      window.open(source, '_blank', 'noopener');
      return;
    }
    state.photoTrigger = trigger;
    showPhoto(state, index);
    if (!dialog.open) dialog.showModal();
    document.documentElement.classList.add('ks-pdp-modal-open');
  }
  function enhanceGallery(root) {
    if (galleryStates.has(root)) return;
    var gallery = root.querySelector('.gallery');
    if (!gallery) return;
    var slides = originalNodes(gallery, '[data-ks-gallery-slide]');
    if (!slides.length) return;
    var id = gallery.id || ('ks-pdp-gallery-' + (root.getAttribute('data-ks-product-gallery') || ++sequence));
    gallery.id = id; gallery.tabIndex = 0;
    gallery.setAttribute('role', 'region'); gallery.setAttribute('aria-roledescription', 'галерея');
    gallery.setAttribute('aria-label', 'Фотографии и особенности модели');
    var state = {root:root,gallery:gallery,slides:slides,id:id,index:0,mode:'pending',thumbs:[],railThumbs:[],photos:[],scheduled:false};
    galleryStates.set(root, state);
    slides.forEach(function (slide, index) {
      var image = slidePhoto(slide);
      if (!image) return;
      var src = photoSource(image);
      if (!src) return;
      state.photos.push({slide:slide});
      if (!slide.querySelector('[data-ks-photo-zoom]')) {
        var zoom = createButton('ks-pdp-photo-zoom', 'Увеличить фотографию ' + (index + 1), 'zoom');
        zoom.setAttribute('data-ks-photo-zoom', '');
        var label = document.createElement('span'); label.textContent = 'Увеличить'; zoom.appendChild(label);
        slide.appendChild(zoom);
      }
    });
    var side = root.querySelector('.gallery-side');
    if (side) originalNodes(side, '.gallery-side__item').forEach(function (item, index) {
      var button = item.querySelector('button[data-ks-gallery-thumb]');
      if (!button) {
        button = createButton('ks-pdp-thumb', (slides[index] && slidePhoto(slides[index]) ? 'Фотография ' : 'Особенности модели, слайд ') + (index + 1));
        button.setAttribute('data-ks-gallery-thumb', String(index));
        while (item.firstChild) button.appendChild(item.firstChild);
        item.appendChild(button);
      }
      button.setAttribute('aria-controls', id);
      state.thumbs.push(button);
      button.addEventListener('click', function () {
        // In native mode focusOnSelect on gallery-side performs this navigation.
        // Calling slickGoTo here as well would repeat the native click handler.
        if (!nativeSlick(state)) goTo(state, index, false);
      });
    });
    if (state.thumbs.length) {
      var rail = document.createElement('div');
      rail.className = 'ks-pdp-mobile-thumbs ks-pdp-thumb-rail';
      rail.setAttribute('role', 'group');
      rail.setAttribute('aria-label', 'Выбор слайда галереи');
      state.thumbs.forEach(function (original,index) {
        var button = original.cloneNode(true);
        button.removeAttribute('id');
        button.querySelectorAll('[id]').forEach(function (node) {node.removeAttribute('id');});
        button.addEventListener('click',function () {goTo(state,index,false);});
        state.railThumbs.push(button); rail.appendChild(button);
      });
      root.appendChild(rail);
      root.setAttribute('data-ks-thumb-rail-ready', '');
    }
    var controls = root.querySelector('.ks-pdp-gallery-controls');
    if (!controls) {
      controls = document.createElement('div'); controls.className = 'ks-pdp-gallery-controls';
      var previous = createButton('', 'Предыдущий слайд', 'prev');
      previous.setAttribute('data-ks-gallery-prev', '');
      var next = createButton('', 'Следующий слайд', 'next'); next.setAttribute('data-ks-gallery-next', '');
      var count = document.createElement('p'); count.className = 'ks-pdp-gallery-count';
      count.setAttribute('data-ks-gallery-count', ''); count.setAttribute('aria-live', 'polite'); count.setAttribute('aria-atomic', 'true');
      controls.appendChild(previous); controls.appendChild(count); controls.appendChild(next); root.appendChild(controls);
    }
    state.previous = controls.querySelector('[data-ks-gallery-prev]');
    state.next = controls.querySelector('[data-ks-gallery-next]'); state.count = controls.querySelector('[data-ks-gallery-count]');
    if (!state.previous || !state.next || !state.count) return;
    state.previous.addEventListener('click', function () { goTo(state, state.index - 1, false); });
    state.next.addEventListener('click', function () { goTo(state, state.index + 1, false); });
    gallery.addEventListener('click', function (event) {
      var slide = event.target.closest('[data-ks-gallery-slide]');
      if (!slide || !gallery.contains(slide) || !slidePhoto(slide)) return;
      var trigger = event.target.closest('[data-ks-photo-zoom]');
      if (trigger || event.target.tagName === 'IMG') {
        event.preventDefault(); event.stopPropagation();
        openPhoto(state, slide, trigger || slide.querySelector('[data-ks-photo-zoom]') || gallery);
      }
    });
    root.addEventListener('keydown', function (event) {
      if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.target.closest('input,textarea,select,[contenteditable="true"]')) return;
      if (!event.target.closest('.gallery,.gallery-side,.ks-pdp-mobile-thumbs,.ks-pdp-gallery-controls')) return;
      var thumb = event.target.closest('[data-ks-gallery-thumb]');
      var key = event.key;
      if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(key)) return;
      if (!thumb && (key === 'ArrowUp' || key === 'ArrowDown')) return;
      event.preventDefault(); event.stopPropagation();
      var index = thumb ? Number(thumb.getAttribute('data-ks-gallery-thumb')) : state.index;
      if (key === 'Home') index = 0;
      else if (key === 'End') index = state.slides.length - 1;
      else index += (key === 'ArrowLeft' || key === 'ArrowUp') ? -1 : 1;
      goTo(state, index, Boolean(thumb));
    }, true);
    var pointer = null;
    gallery.addEventListener('pointerdown', function (event) {
      if (state.mode !== 'fallback' || event.pointerType === 'mouse' || !event.isPrimary) return;
      pointer = {x:event.clientX,y:event.clientY};
    }, {passive:true});
    gallery.addEventListener('pointerup', function (event) {
      if (!pointer || state.mode !== 'fallback') return;
      var dx = event.clientX-pointer.x, dy = event.clientY-pointer.y; pointer = null;
      if (Math.abs(dx)>50 && Math.abs(dx)>Math.abs(dy)*1.5) goTo(state,state.index+(dx<0?1:-1),false);
    }, {passive:true});
    gallery.addEventListener('pointercancel', function () { pointer = null; }, {passive:true});
    attachHoverZoom(state);
    if (window.jQuery && window.jQuery.fn && window.jQuery.fn.slick) {
      window.jQuery(gallery).on('init.ksPdp reInit.ksPdp afterChange.ksPdp setPosition.ksPdp', function () { scheduleGallery(state); });
      if (side) window.jQuery(side).on('init.ksPdp reInit.ksPdp afterChange.ksPdp', function () { scheduleGallery(state); });
    }
    function settle() {
      state.mode = nativeSlick(state) ? 'slick' : 'fallback';
      updateGallery(state);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(settle,0); }, {once:true});
    else setTimeout(settle,0);
    updateGallery(state);
  }
  function normalize(value) { return String(value).toLocaleLowerCase('ru').replace(/ё/g,'е').replace(/\s+/g,' ').trim(); }
  function enhanceSpecs(panel) {
    if (initializedSpecs.has(panel)) return;
    var search = panel.querySelector('[data-ks-spec-search]');
    var rows = Array.prototype.slice.call(panel.querySelectorAll('[data-ks-spec-row]'));
    if (!search || !rows.length) return;
    initializedSpecs.add(panel);
    var groups = Array.prototype.slice.call(panel.querySelectorAll('[data-ks-spec-group]'));
    var count = panel.querySelector('[data-ks-spec-count]');
    var empty = panel.querySelector('[data-ks-spec-empty]');
    var limit = Math.max(1,Number(panel.getAttribute('data-ks-spec-limit')) || 12);
    var expanded = false;
    var toggle = panel.querySelector('[data-ks-spec-toggle]');
    if (!toggle && rows.length>limit) {
      toggle = createButton('', 'Показать все характеристики');
      toggle.removeAttribute('title'); toggle.setAttribute('data-ks-spec-toggle',''); panel.appendChild(toggle);
    }
    if (count) { count.setAttribute('aria-live','polite');count.setAttribute('aria-atomic','true'); }
    var text = rows.map(function (row) {
      var cells=Array.prototype.map.call(row.querySelectorAll('dt,dd'),function (cell) {return cell.textContent;}).join(' ');
      return normalize(row.getAttribute('data-ks-spec-text') || cells || row.textContent);
    });
    function render() {
      var query = normalize(search.value);
      var terms = query ? query.split(' ') : [];
      var matching = 0;
      rows.forEach(function (row,index) {
        var match = terms.every(function (term) {return text[index].includes(term);});
        var visible = match && (query || expanded || matching<limit);
        if (match) matching++;
        row.hidden = !visible;
      });
      groups.forEach(function (group) { group.hidden = !group.querySelector('[data-ks-spec-row]:not([hidden])'); });
      if (count) count.textContent = query ? 'Найдено: ' + matching + ' из ' + rows.length : 'Всего характеристик: ' + rows.length;
      if (empty) empty.hidden = matching !== 0;
      if (toggle) {
        toggle.hidden = Boolean(query) || rows.length<=limit;
        toggle.setAttribute('aria-expanded',String(expanded));
        if (panel.id) toggle.setAttribute('aria-controls',panel.id);
        var label = expanded ? 'Свернуть характеристики' : 'Показать все характеристики (' + rows.length + ')';
        toggle.textContent = label; toggle.setAttribute('aria-label',label);
      }
    }
    search.addEventListener('input',render);
    search.addEventListener('search',render);
    if (toggle) toggle.addEventListener('click',function () { expanded=!expanded;render(); });
    render();
  }
  function openTab(link) {
    var id = link.getAttribute('data-ks-open-tab');
    if (!id || !/^[A-Za-z][\w:-]*$/.test(id)) return false;
    var panel = document.getElementById(id); var tabs = panel && panel.closest('.product-tabs');
    if (!tabs) return false;
    var anchors = Array.prototype.slice.call(tabs.querySelectorAll('.product-tabs__head a[href^="#"]'));
    var index = anchors.findIndex(function (anchor) { return anchor.getAttribute('href') === '#'+id; });
    if (index<0) return false;
    if (window.jQuery && window.jQuery.fn && window.jQuery.fn.tabs && tabs.classList.contains('ui-tabs')) {
      window.jQuery(tabs).tabs('option','active',index);
    } else {
      anchors[index].click();
      Array.prototype.forEach.call(tabs.querySelectorAll('.product-tabs__content'),function (item) {
        item.style.display=item===panel?'block':'none';
      });
    }
    requestAnimationFrame(function () {
      panel.scrollIntoView({block:'start',behavior:reducedMotion()?'auto':'smooth'});
    });
    return true;
  }
  function start() {
    document.querySelectorAll('[data-ks-product-gallery]').forEach(enhanceGallery);
    document.querySelectorAll('[data-ks-spec-search]').forEach(function (input) {
      var panel=input.closest('.product-tabs__content');if (panel) enhanceSpecs(panel);
    });
  }
  document.addEventListener('click',function (event) {
    var link=event.target.closest('[data-ks-open-tab]');
    if (link && openTab(link)) event.preventDefault();
  });
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
}());
