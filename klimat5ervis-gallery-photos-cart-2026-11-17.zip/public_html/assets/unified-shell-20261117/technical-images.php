<?php
// Include-only, read-only delivery adapter. It does not generate files or alter originals.
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

/** Return the first closing angle bracket outside quoted attribute values. */
function klimat_technical_images_20261117_tag_end($html, $start)
{
    $quote = '';
    $length = strlen($html);
    for ($i = $start + 1; $i < $length; $i++) {
        $character = $html[$i];
        if ($quote !== '') {
            if ($character === $quote) $quote = '';
        } elseif ($character === '"' || $character === "'") {
            $quote = $character;
        } elseif ($character === '>') {
            return $i;
        }
    }
    return FALSE;
}

/** Parse only a valid IMG opening tag while retaining every original attribute token. */
function klimat_technical_images_20261117_attributes($tag)
{
    $offset = 4; // strlen('<img'), independent of its letter case.
    $attributes = array();
    $pattern = '~\G(\s+)([^\x00-\x20"\x27<>/=]+)(?:\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\s"\x27=<>`]+)))?~s';
    while ($offset < strlen($tag)) {
        if (preg_match('~\G\s*/?>\z~s', $tag, $tail, 0, $offset)) {
            return array('attributes' => $attributes, 'tail' => $tail[0]);
        }
        if (!preg_match($pattern, $tag, $match, PREG_OFFSET_CAPTURE | PREG_UNMATCHED_AS_NULL, $offset)) return NULL;
        $value = NULL;
        for ($i = 3; $i <= 5; $i++) {
            if (isset($match[$i]) && $match[$i][1] >= 0) {
                $value = $match[$i][0];
                break;
            }
        }
        $attributes[] = array('raw' => $match[0][0], 'space' => $match[1][0],
            'name' => $match[2][0], 'lower' => strtolower($match[2][0]), 'value' => $value);
        $offset += strlen($match[0][0]);
    }
    return NULL;
}

/** Resolve only exact known source URLs and validate a complete delivery entry. */
function klimat_technical_images_20261117_entry($source)
{
    static $state = NULL;
    static $resolved = array();
    if (!function_exists('hash_file') || !function_exists('getimagesize')) return NULL;
    if ($state === NULL) {
        $state = array('root' => '', 'images' => array());
        $root = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
        $mapPath = __DIR__ . '/image-map.json';
        if (!$root || $root === DIRECTORY_SEPARATOR || is_link(__DIR__) || is_link($mapPath)
            || !is_file($mapPath) || @filesize($mapPath) > 2097152) return NULL;
        $raw = @file_get_contents($mapPath);
        $map = is_string($raw) ? json_decode($raw, TRUE) : NULL;
        if (!is_array($map) || ($map['schema'] ?? 0) !== 1 || !is_array($map['images'] ?? NULL)) return NULL;
        $state = array('root' => $root, 'images' => $map['images']);
    }
    if (array_key_exists($source, $resolved)) return $resolved[$source];
    $resolved[$source] = NULL;
    if (!isset($state['images'][$source]) || strpos($source, '/') !== 0 || strpos($source, '..') !== FALSE) return NULL;
    $entry = $state['images'][$source];
    if (!is_array($entry) || !in_array($entry['kind'] ?? '', array('product', 'category', 'icon'), TRUE)
        || !is_array($entry['source'] ?? NULL) || !is_array($entry['variants'] ?? NULL)) return NULL;
    $root = $state['root'];
    $original = $root . $source;
    // An edited original immediately falls back to the current CMS image instead
    // of showing an obsolete derivative with the same product URL.
    if (is_link($original) || !is_file($original) || realpath($original) !== $original
        || @filesize($original) !== ($entry['source']['bytes'] ?? -1)
        || !is_string($entry['source']['sha256'] ?? NULL)
        || !hash_equals($entry['source']['sha256'], (string) @hash_file('sha256', $original))) return NULL;
    $variants = array();
    foreach ($entry['variants'] as $variant) {
        if (!is_array($variant) || !is_int($variant['w'] ?? NULL) || !is_int($variant['h'] ?? NULL)
            || !is_int($variant['bytes'] ?? NULL) || $variant['w'] < 1 || $variant['h'] < 1
            || $variant['w'] > ($entry['source']['w'] ?? 0) || $variant['h'] > ($entry['source']['h'] ?? 0)
            || !is_string($variant['url'] ?? NULL)) return NULL;
        if ($variant['url'] === $source) {
            if ($variant['w'] !== $entry['source']['w'] || $variant['h'] !== $entry['source']['h']
                || $variant['bytes'] !== $entry['source']['bytes']) return NULL;
        } else {
            if (!preg_match('~^/assets/technical-images-20261117/[a-f0-9]{24}\.webp$~D', $variant['url'])) return NULL;
            $file = $root . $variant['url'];
            if (is_link($root . '/assets') || is_link($root . '/assets/technical-images-20261117')
                || is_link($file) || !is_file($file) || realpath($file) !== $file
                || @filesize($file) !== $variant['bytes']) return NULL;
            $dimensions = @getimagesize($file);
            if (!is_array($dimensions) || $dimensions[0] !== $variant['w'] || $dimensions[1] !== $variant['h']
                || ($dimensions[2] ?? 0) !== IMAGETYPE_WEBP) return NULL;
        }
        $variants[$variant['w']] = $variant;
    }
    if (!$variants) return NULL;
    ksort($variants, SORT_NUMERIC);
    $entry['variants'] = array_values($variants);
    return $resolved[$source] = $entry;
}

/** Update delivery attributes on one IMG; all other tokens remain byte-for-byte intact. */
function klimat_technical_images_20261117_tag($tag)
{
    $parsed = klimat_technical_images_20261117_attributes($tag);
    if (!is_array($parsed)) return $tag;
    $source = NULL;
    $sourceCount = 0;
    $hero = FALSE;
    foreach ($parsed['attributes'] as $attribute) {
        if ($attribute['lower'] === 'src') {
            $source = $attribute['value'];
            $sourceCount++;
        }
        // Leave JavaScript-managed lazy loaders alone.
        if ($attribute['lower'] === 'data-src' || $attribute['lower'] === 'data-srcset') return $tag;
        if ($attribute['lower'] === 'fetchpriority' && strtolower((string) $attribute['value']) === 'high') $hero = TRUE;
    }
    if ($sourceCount !== 1 || !is_string($source)) return $tag;
    $source = html_entity_decode($source, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $source = preg_replace('~^(?:https?:)?//klimat5ervis\.ru(?=/)~i', '', $source);
    $entry = klimat_technical_images_20261117_entry($source);
    if (!is_array($entry)) return $tag;
    $variants = $entry['variants'];
    $fallback = end($variants)['url'];
    $target = $entry['kind'] === 'product' ? ($hero ? 600 : 360) : ($entry['kind'] === 'category' ? 224 : 80);
    foreach ($variants as $variant) {
        if ($variant['w'] >= $target) {
            $fallback = $variant['url'];
            break;
        }
    }
    if ($entry['kind'] === 'category') {
        $sizes = '(min-width: 1440px) 112px, (max-width: 760px) 70px, 80px';
    } elseif ($entry['kind'] === 'icon') {
        $sizes = '40px';
    } elseif ($hero) {
        $sizes = '(max-width: 760px) calc(100vw - 80px), (max-width: 1439px) 42vw, 560px';
    } else {
        $sizes = '(max-width: 760px) calc((100vw - 70px) / 2), (max-width: 1100px) 30vw, 360px';
    }
    $srcset = array();
    foreach ($variants as $variant) $srcset[] = $variant['url'] . ' ' . $variant['w'] . 'w';
    $output = substr($tag, 0, 4);
    foreach ($parsed['attributes'] as $attribute) {
        if ($attribute['lower'] === 'src') {
            $output .= $attribute['space'] . $attribute['name'] . '="' . htmlspecialchars($fallback, ENT_QUOTES, 'UTF-8') . '"';
        } elseif ($attribute['lower'] === 'data-ks-photo-source'
            && html_entity_decode((string) $attribute['value'], ENT_QUOTES | ENT_HTML5, 'UTF-8') === $source) {
            $output .= $attribute['space'] . $attribute['name'] . '="' . htmlspecialchars($fallback, ENT_QUOTES, 'UTF-8') . '"';
        } elseif ($attribute['lower'] !== 'srcset' && $attribute['lower'] !== 'sizes') {
            $output .= $attribute['raw'];
        }
    }
    $output .= ' srcset="' . htmlspecialchars(implode(', ', $srcset), ENT_QUOTES, 'UTF-8') . '" sizes="'
        . htmlspecialchars($sizes, ENT_QUOTES, 'UTF-8') . '"' . $parsed['tail'];
    return $output;
}

/** Tokenize HTML without serializing the document or changing zoom links/inline scripts. */
function klimat_technical_images_20261117_html($html)
{
    if (!is_string($html) || $html === '') return $html;
    $output = '';
    $offset = 0;
    $length = strlen($html);
    while (($start = strpos($html, '<', $offset)) !== FALSE) {
        $output .= substr($html, $offset, $start - $offset);
        if (substr($html, $start, 4) === '<!--') {
            $end = strpos($html, '-->', $start + 4);
            if ($end === FALSE) return $output . substr($html, $start);
            $end += 2;
        } elseif (substr($html, $start, 9) === '<![CDATA[') {
            $end = strpos($html, ']]>', $start + 9);
            if ($end === FALSE) return $output . substr($html, $start);
            $end += 2;
        } else {
            $opening = preg_match('~\G<([A-Za-z][A-Za-z0-9:-]*)(?=[\x20\t\r\n\f/>])~', $html, $name, 0, $start);
            if (!$opening && !preg_match('~\G<(?:/[A-Za-z]|!|\?)~', $html, $unused, 0, $start)) {
                $output .= '<';
                $offset = $start + 1;
                continue;
            }
            $end = klimat_technical_images_20261117_tag_end($html, $start);
            if ($end === FALSE) return $output . substr($html, $start);
            if ($opening) {
                $type = strtolower($name[1]);
                if ($type === 'plaintext') return $output . substr($html, $start);
                if (in_array($type, array('script', 'style', 'textarea', 'title', 'xmp', 'iframe', 'noembed', 'noframes'), TRUE)) {
                    if (!preg_match('~</' . $type . '\s*>~i', $html, $close, PREG_OFFSET_CAPTURE, $end + 1)) return $output . substr($html, $start);
                    // Legacy double-escaped script syntax has an HTML tokenizer
                    // state beyond ordinary raw text. Fail closed rather than
                    // treating an inner </script> as the real element boundary.
                    if ($type === 'script') {
                        $body = substr($html, $end + 1, $close[0][1] - $end - 1);
                        if (strpos($body, '<!--') !== FALSE && preg_match('~<script(?=[\x20\t\r\n\f/>])~i', $body)) {
                            return $output . substr($html, $start);
                        }
                    }
                    $end = $close[0][1] + strlen($close[0][0]) - 1;
                } elseif ($type === 'img') {
                    $output .= klimat_technical_images_20261117_tag(substr($html, $start, $end - $start + 1));
                    $offset = $end + 1;
                    continue;
                }
            }
        }
        $output .= substr($html, $start, $end - $start + 1);
        $offset = $end + 1;
    }
    return $output . substr($html, $offset, $length - $offset);
}
