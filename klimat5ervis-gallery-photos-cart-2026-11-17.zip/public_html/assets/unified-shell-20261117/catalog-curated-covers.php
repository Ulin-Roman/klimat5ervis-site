<?php
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) { http_response_code(404); exit; }
/** Optional curated cover overrides. Only known image anchors are serialized. */
function klimat_catalog_curated_covers_20261117_html($html, $path = NULL, $manifest = NULL)
{
    if (!is_string($html) || !function_exists('klimat_product_cards_20261117_ranges') || !class_exists('DOMDocument')) return $html;
    if ($path === NULL) $path = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    if (!is_string($path) || !($path === '/' || strpos($path, '/category/') === 0 || strpos($path, '/search/') === 0) || preg_match('~^/category/(?:cart|info)(?:/|$)~', $path)) return $html;
    $root = realpath(defined('CMS_FOLDER') ? CMS_FOLDER : (isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : ''));
    if (!$root || $root === DIRECTORY_SEPARATOR) return $html;
    $read = static function ($file, $limit) {
        if (!is_file($file) || is_link($file) || filesize($file) >= $limit) return array();
        $raw = @file_get_contents($file, FALSE, NULL, 0, $limit);
        if (!is_string($raw) || strlen($raw) >= $limit) return array();
        $data = json_decode($raw, TRUE); return is_array($data) ? $data : array();
    };
    $dataDir = $root . '/assets/product-cards-20261117/data';
    // Decode the small legacy baseline once, never once per image tag.
    $legacy = $manifest === NULL ? $read($dataDir . '/products.json', 2097152) : $manifest;
    $entries = array();
    $entryFor = static function ($id) use (&$entries, $legacy, $manifest, $dataDir, $read) {
        if (array_key_exists($id, $entries)) return $entries[$id];
        $base = isset($legacy['products'][$id]) && is_array($legacy['products'][$id]) ? $legacy['products'][$id] : array();
        if ($manifest === NULL && !is_link($dataDir) && !is_link($dataDir . '/items')) {
            $record = $read($dataDir . '/items/' . $id . '.json', 262144);
            if (!empty($record['native_name']) && is_string($record['native_name']) && (!isset($record['item_id']) || ((is_int($record['item_id']) || is_string($record['item_id'])) && (string) $record['item_id'] === $id))) {
                if (!empty($base['native_name']) && klimat_product_cards_20261117_text($base['native_name']) !== klimat_product_cards_20261117_text($record['native_name'])) $base = array();
                $base = array_replace($base, $record);
            }
        }
        return $entries[$id] = $base;
    };
    $route = static function ($url) {
        if (!is_string($url) || $url === '') return '';
        $parsed = parse_url($url);
        if (!is_array($parsed) || isset($parsed['user']) || isset($parsed['pass']) || isset($parsed['query']) || isset($parsed['fragment'])) return '';
        if ((isset($parsed['scheme']) || isset($parsed['host'])) && (!isset($parsed['scheme'], $parsed['host']) || strtolower($parsed['scheme']) !== 'https' || strtolower($parsed['host']) !== 'klimat5ervis.ru' || (isset($parsed['port']) && $parsed['port'] !== 443))) return '';
        return isset($parsed['path']) && preg_match('~^/category/(?:[^/]+/)*[0-9]+/$~D', $parsed['path']) ? $parsed['path'] : '';
    };
    $imageInfo = static function ($url, $id) use ($root) {
        if (!is_string($url) || !preg_match('~^/assets/product-cards-20261117/images/' . preg_quote($id, '~') . '/[a-zA-Z0-9_-]+\.(webp|jpg|jpeg|png)$~D', $url, $match)) return NULL;
        $file = $root;
        foreach (explode('/', ltrim($url, '/')) as $part) { $file .= '/' . $part; if (is_link($file)) return NULL; }
        if (!is_file($file) || realpath($file) !== $file) return NULL;
        $info = @getimagesize($file);
        $type = $match[1] === 'jpg' ? 'jpeg' : $match[1];
        return $info && $info[0] > 0 && $info[1] > 0 && $info['mime'] === 'image/' . $type ? $info : NULL;
    };
    $search = strpos($path, '/search/') === 0;
    $ranges = klimat_product_cards_20261117_ranges($html, static function ($token) use ($search) {
        return $token['name'] === 'a' && (klimat_product_cards_20261117_tag_class($token['text'], 'product-image')
            || klimat_product_cards_20261117_tag_class($token['text'], 'mh-feature-image')
            || ($search && strpos($token['text'], '/category/') !== FALSE));
    });
    foreach (array_reverse($ranges) as $range) {
        $original = substr($html, $range['start'], $range['end'] - $range['start']);
        try {
            $parsed = klimat_product_cards_20261117_parse($original);
            if (!$parsed || $parsed['restore'] || strtolower($parsed['root']->tagName) !== 'a') continue;
            $anchor = $parsed['root']; $doc = $parsed['doc'];
            if ($anchor->hasAttribute('data-ks-curated-cover')) continue;
            $productPath = $route($anchor->getAttribute('href'));
            if ($productPath === '' || !preg_match('~/([0-9]+)/$~D', $productPath, $match)) continue;
            $id = $match[1]; $entry = $entryFor($id);
            if (empty($entry['native_name']) || !is_string($entry['native_name']) || empty($entry['images'][0]) || !is_array($entry['images'][0])) continue;
            if (!empty($entry['native_url']) && $route($entry['native_url']) !== $productPath) continue;
            $images = $anchor->getElementsByTagName('img');
            if ($images->length > 1) continue;
            $image = $images->length ? $images->item(0) : NULL;
            if ($image && ($image->hasAttribute('id') || $image->hasAttribute('data-src') || $image->hasAttribute('data-srcset'))) continue;
            if ($search && !klimat_product_cards_20261117_has_class($image, 'product-item__img')
                && !klimat_product_cards_20261117_has_class($anchor, 'product-image')) continue;
            $name = $image ? klimat_product_cards_20261117_text($image->getAttribute('alt')) : '';
            if ($name === '' && $image) $name = klimat_product_cards_20261117_text($image->getAttribute('title'));
            if ($name === '') $name = klimat_product_cards_20261117_text($anchor->getAttribute('aria-label'));
            if ($name !== '' && $name !== klimat_product_cards_20261117_text($entry['native_name'])) continue;
            if ($name === '' && (empty($entry['native_url']) || $route($entry['native_url']) !== $productPath)) continue;
            $placeholder = NULL; $unknown = FALSE;
            foreach ($anchor->childNodes as $child) {
                if ($child === $image || ($child instanceof DOMText && trim($child->nodeValue) === '')) continue;
                if (!$image && klimat_product_cards_20261117_has_class($child, 'image-empty') && $placeholder === NULL) { $placeholder = $child; continue; }
                $unknown = TRUE; break;
            }
            if ($unknown || (!$image && !$placeholder)) continue;
            $cover = $entry['images'][0];
            if (!isset($cover['src'], $cover['thumb']) || $cover['src'] === $cover['thumb']) continue;
            $fullInfo = $imageInfo($cover['src'], $id); $thumbInfo = $imageInfo($cover['thumb'], $id);
            if (!$fullInfo || !$thumbInfo) continue;
            $hero = klimat_product_cards_20261117_has_class($anchor, 'mh-feature-image');
            if (!$image) {
                $image = $doc->createElement('img'); $image->setAttribute('alt', $entry['native_name']);
                $image->setAttribute('loading', $hero ? 'eager' : 'lazy'); $image->setAttribute('decoding', 'async');
                if ($hero) $image->setAttribute('fetchpriority', 'high');
                $anchor->replaceChild($image, $placeholder);
            }
            $image->setAttribute('src', $hero ? $cover['src'] : $cover['thumb']);
            if ($image->getAttribute('alt') === '') $image->setAttribute('alt', $entry['native_name']);
            $sources = array($thumbInfo[0] => $cover['thumb'], $fullInfo[0] => $cover['src']); ksort($sources, SORT_NUMERIC);
            $srcset = array(); foreach ($sources as $width => $url) $srcset[] = $url . ' ' . $width . 'w';
            $image->setAttribute('srcset', implode(', ', $srcset));
            $image->setAttribute('sizes', $hero ? '(max-width:760px) calc(100vw - 48px), 520px' : '(max-width:480px) calc((100vw - 72px) / 2), (max-width:760px) calc((100vw - 64px) / 2), 360px');
            $image->setAttribute('width', (string) $fullInfo[0]); $image->setAttribute('height', (string) $fullInfo[1]);
            $anchor->setAttribute('data-ks-curated-cover', $id);
            $replacement = strtr($doc->saveHTML($anchor), $parsed['restore']);
            $html = substr_replace($html, $replacement, $range['start'], $range['end'] - $range['start']);
        } catch (Throwable $ignored) { /* Retain the existing cover and route. */ }
    }
    return $html;
}
