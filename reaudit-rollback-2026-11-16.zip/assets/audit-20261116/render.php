<?php
/** Front-end corrections only. No database writes, outbound calls or admin hooks. */
function klimat_canonical_url()
{
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (!is_string($path) || $path === '') { $path = '/'; }
    $query = array();
    parse_str((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY), $query);
    foreach (array_keys($query) as $key) {
        if (preg_match('/^(utm_|yclid$|gclid$|fbclid$|etext$|ybaip$|erid$|ysclid$)/i', $key)) {
            unset($query[$key]);
        }
    }
    ksort($query);
    return 'https://klimat5ervis.ru' . $path . (count($query) ? '?' . http_build_query($query) : '');
}

function klimat_seo_head()
{
    $canonical = htmlspecialchars(klimat_canonical_url(), ENT_QUOTES, 'UTF-8');
    echo '<link rel="canonical" href="' . $canonical . '">' . "\n";
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (preg_match('~^/(search|users)(/|$)|^/category/(cart|favorite|compare)(/|$)~', $path)) {
        echo '<meta name="robots" content="noindex,follow">' . "\n";
    }
    $schema = array(
        '@context' => 'https://schema.org',
        '@graph' => array(
            array('@type' => 'Organization', '@id' => 'https://klimat5ervis.ru/#organization',
                'name' => 'Климат-Сервис', 'url' => 'https://klimat5ervis.ru/',
                'telephone' => '+7-905-411-39-48', 'email' => 'klimat5ervis@yandex.ru',
                'logo' => 'https://klimat5ervis.ru/images/t8903001/img/logo.png',
                'address' => array('@type' => 'PostalAddress', 'addressLocality' => 'Москва',
                    'streetAddress' => 'ул. Перовская, дом 20', 'addressCountry' => 'RU')),
            array('@type' => 'WebSite', '@id' => 'https://klimat5ervis.ru/#website',
                'name' => 'Климат-Сервис', 'url' => 'https://klimat5ervis.ru/',
                'inLanguage' => 'ru-RU', 'publisher' => array('@id' => 'https://klimat5ervis.ru/#organization'))
        )
    );
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>' . "\n";
}

function klimat_page_metadata()
{
    ob_start(); Core_Page::instance()->showTitle(); $title = html_entity_decode(strip_tags(ob_get_clean()), ENT_QUOTES, 'UTF-8');
    ob_start(); Core_Page::instance()->showDescription(); $description = html_entity_decode(strip_tags(ob_get_clean()), ENT_QUOTES, 'UTF-8');
    if (trim($description) === '' || preg_match('/^Каталог(?: товаров)?[.!]?$/u', trim($description))) {
        $description = $title . ' — характеристики, фотографии и цена в интернет-магазине «Климат-Сервис». Доставка и установка в Москве и Московской области.';
    }
    if (preg_match('~/page-([2-9][0-9]*|1[0-9]+)/?~', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), $page)) {
        $title .= ' — Страница ' . (int) $page[1];
        $description .= ' Страница ' . (int) $page[1] . '.';
    }
    echo '<title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</title>' . "\n";
    echo '<meta name="description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">' . "\n";
}

function klimat_optimize_content($html)
{
    static $images = null;
    if ($images === null) {
        $images = json_decode(file_get_contents(__DIR__ . '/images.json'), true);
        if (!is_array($images)) { $images = array(); }
    }
    $hero = false;
    $html = preg_replace_callback('~<img\b[^>]*>~i', function ($match) use ($images, &$hero) {
        $tag = $match[0];
        if (!preg_match('~\bsrc\s*=\s*([\x22\x27])(.*?)\1~is', $tag, $source)) { return $tag; }
        $src = html_entity_decode($source[2], ENT_QUOTES, 'UTF-8');
        $key = strpos($src, 'data:image/') === 0 ? 'data:' . hash('sha256', $src) : preg_replace('~^https://klimat5ervis\.ru~', '', $src);
        if (isset($images[$key])) {
            $image = $images[$key];
            $tag = str_replace($source[0], 'src="' . htmlspecialchars($image['src'], ENT_QUOTES, 'UTF-8') . '"', $tag);
            $tag = preg_replace('~\s+(width|height)\s*=\s*([\x22\x27]).*?\2~i', '', $tag);
            $tag = preg_replace('~\s*/?>$~', ' width="' . (int) $image['width'] . '" height="' . (int) $image['height'] . '">', $tag);
            if (isset($image['alt'])) {
                $tag = preg_replace('~\s+alt\s*=\s*([\x22\x27]).*?\1~i', '', $tag);
                $tag = substr($tag, 0, -1) . ' alt="' . htmlspecialchars($image['alt'], ENT_QUOTES, 'UTF-8') . '">';
            }
        }
        if (!preg_match('~\balt\s*=~i', $tag)) { $tag = substr($tag, 0, -1) . ' alt="">'; }
        if (!preg_match('~\bdecoding\s*=~i', $tag)) { $tag = substr($tag, 0, -1) . ' decoding="async">'; }
        $firstHero = strpos($tag, 'offer-slider__img') !== false && !$hero;
        if ($firstHero) { $hero = true; $tag = substr($tag, 0, -1) . ' fetchpriority="high">'; }
        $productHero = strpos($tag, 'gallery__') !== false;
        if (!$firstHero && !$productHero && !preg_match('~\bloading\s*=~i', $tag)) {
            $tag = substr($tag, 0, -1) . ' loading="lazy">';
        }
        return $tag;
    }, $html);
    // Supplier descriptions can contain a second H1; retain the actual product heading.
    $html = preg_replace_callback('~(<div[^>]+id="tabs-1"[^>]*>)(.*?)(<div[^>]+id="tabs-2")~is', function ($m) {
        return $m[1] . preg_replace('~<(\/?)h1\b~i', '<$1h2', $m[2]) . $m[3];
    }, $html);
    // Give repeated quantity controls an accessible name without changing their behaviour.
    $html = preg_replace_callback('~<input\b[^>]*type="number"[^>]*>~i', function ($m) {
        return strpos($m[0], 'aria-label=') !== false ? $m[0] : preg_replace('~\s*/?>$~', ' aria-label="Количество товара">', $m[0]);
    }, $html);
    return $html;
}

/** Inline small layout styles to avoid six serial first-render requests. */
function klimat_inline_css($path)
{
    $file = $_SERVER['DOCUMENT_ROOT'] . $path;
    if (!is_file($file)) { return; }
    $css = file_get_contents($file);
    $base = dirname($path) . '/';
    $css = preg_replace_callback('~url\(([^)]*)\)~i', function ($m) use ($base) {
        $url = trim($m[1], " \t\n\r\0\x0B\"'");
        if ($url === '' || preg_match('~^(?:/|data:|https?:|#)~i', $url)) { return $m[0]; }
        return 'url("' . $base . $url . '")';
    }, $css);
    echo '<style>' . $css . '</style>' . "\n";
}
