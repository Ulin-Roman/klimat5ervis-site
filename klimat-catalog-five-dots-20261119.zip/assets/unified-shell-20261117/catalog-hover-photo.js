(function () {
    'use strict';

    var mouseAvailable = window.matchMedia('(any-hover: hover) and (any-pointer: fine)');
    var dotCount = 5;

    function safePhoto(url, itemId) {
        if (/^\/assets\/catalog-images-20261117\/[a-f0-9]{64}\.webp$/i.test(url)) return url;
        var curated = /^\/assets\/product-cards-20261117\/images\/(\d+)\/[\w-]+\.(?:avif|webp|jpe?g|png)$/i.exec(url);
        var native = /^\/upload\/shop_1\/(?:[\w-]+\/)*item_(\d+)\/(?:small_)?(?:item_image\1|shop_property_file_\d+_\d+)\.(?:avif|webp|jpe?g|png)$/i.exec(url);
        return (curated && curated[1] === itemId) || (native && native[1] === itemId) ? url : '';
    }

    function photosFromPage(html, itemId) {
        // This markup stays inert. Only the selected image is requested.
        var parsed = document.createElement('template');
        parsed.innerHTML = html;
        var gallery = parsed.content.querySelector('[data-ks-product-gallery="' + itemId + '"]');
        var frames = [''];
        if (!gallery) return frames;

        var photos = gallery.querySelectorAll('[data-ks-gallery-slide][data-ks-slide-kind="photo"] img');
        var thumbs = gallery.querySelectorAll('.gallery-side img');
        var coverSrc = photos[0] && photos[0].getAttribute('src');
        var coverThumb = thumbs[0] && thumbs[0].getAttribute('src');
        var seen = new Set([coverSrc, coverThumb]);
        for (var index = 1; index < photos.length && frames.length < dotCount; index++) {
            var photo = photos[index];
            var src = safePhoto(photo.getAttribute('src'), itemId);
            if (!src || seen.has(src) || /черт[её]ж|\bdiagram\b/i.test(photo.getAttribute('alt') || '')) continue;
            var thumb = thumbs.length === photos.length && safePhoto(thumbs[index].getAttribute('src'), itemId);
            frames.push(thumb && !seen.has(thumb) ? thumb : src);
            seen.add(src);
            if (thumb) seen.add(thumb);
        }
        return frames;
    }

    function enhance(link) {
        var image = link.querySelector(':scope > img[src]');
        var url = new URL(link.href);
        var route = /^\/category\/(?:[\w-]+\/)+(\d+)\/$/.exec(url.pathname);
        if (!image || !route || url.origin !== window.location.origin || url.search || url.hash) return;

        var coverSrc = image.getAttribute('src');
        var coverSrcset = image.getAttribute('srcset');
        var galleryRequest;
        var frames;
        var loadTimer;
        var pointerX = null;
        var requested = 0;
        var shown = 0;
        var clickSequence = 0;
        var images = new Map();

        var dots = document.createElement('div');
        dots.className = 'ks-catalog-photo-dots';
        dots.setAttribute('role', 'group');
        dots.setAttribute('aria-label', 'Фотографии товара');
        var buttons = [];

        function loadGallery() {
            if (galleryRequest) return galleryRequest;
            galleryRequest = fetch(url.href, { credentials: 'omit', redirect: 'error' })
                .then(function (response) {
                    if (!response.ok) throw new Error('Gallery unavailable');
                    return response.text();
                })
                .then(function (html) {
                    frames = html ? photosFromPage(html, route[1]) : [''];
                    buttons.forEach(function (button, index) { button.disabled = index >= frames.length; });
                    return frames;
                })
                .catch(function () { galleryRequest = undefined; return null; });
            return galleryRequest;
        }

        function setActive(index) {
            buttons[shown].setAttribute('aria-pressed', 'false');
            buttons[index].setAttribute('aria-pressed', 'true');
            shown = index;
        }

        function loadPhoto(src) {
            if (!images.has(src)) {
                images.set(src, new Promise(function (resolve) {
                    var preview = new Image();
                    preview.onload = function () { resolve(true); };
                    preview.onerror = function () { images.delete(src); resolve(false); };
                    preview.src = src;
                }));
            }
            return images.get(src);
        }

        function show(index) {
            if (requested === index) return;
            requested = index;
            if (shown === index) return;
            if (index === 0) {
                image.setAttribute('src', coverSrc);
                if (coverSrcset !== null) image.setAttribute('srcset', coverSrcset);
                setActive(0);
                return;
            }

            var src = frames[index];
            loadPhoto(src).then(function (loaded) {
                if (requested !== index || !link.isConnected) return;
                if (!loaded) { requested = shown; return; }
                image.removeAttribute('srcset');
                image.setAttribute('src', src);
                setActive(index);
            });
        }

        function showAtPointer() {
            var bounds = link.getBoundingClientRect();
            if (!bounds.width) return;
            var index = Math.floor((pointerX - bounds.left) / bounds.width * frames.length);
            show(Math.max(0, Math.min(frames.length - 1, index)));
        }

        function move(event) {
            if (!mouseAvailable.matches || event.pointerType !== 'mouse') return;
            pointerX = event.clientX;
            if (frames) {
                showAtPointer();
            } else if (loadTimer === undefined) {
                loadTimer = setTimeout(function () {
                    loadGallery().then(function (available) {
                        if (available && pointerX !== null) showAtPointer();
                    });
                }, 150);
            }
        }

        for (var index = 0; index < dotCount; index++) {
            var button = document.createElement('button');
            button.type = 'button';
            button.setAttribute('aria-label', 'Фото ' + (index + 1));
            button.setAttribute('aria-pressed', index === 0 ? 'true' : 'false');
            dots.appendChild(button);
            buttons.push(button);
        }
        link.after(dots);

        dots.addEventListener('click', function (event) {
            var index = buttons.indexOf(event.target);
            if (index < 0) return;
            var sequence = ++clickSequence;
            loadGallery().then(function (available) {
                if (available && sequence === clickSequence && index < available.length) show(index);
            });
        });
        link.addEventListener('pointerenter', move);
        link.addEventListener('pointermove', move);
        link.addEventListener('pointerleave', function (event) {
            if (event.pointerType !== 'mouse') return;
            pointerX = null;
            clearTimeout(loadTimer);
            loadTimer = undefined;
            show(0);
        });
    }

    document.querySelectorAll('main a.product-image').forEach(enhance);
}());
