(function () {
    'use strict';

    var mouseAvailable = window.matchMedia('(any-hover: hover) and (any-pointer: fine)');
    var selector = 'main a.product-image';
    var previews = new Map();
    var active;

    function safePhoto(url, itemId) {
        if (/^\/assets\/catalog-images-20261117\/[a-f0-9]{64}\.webp$/i.test(url)) return url;
        var curated = /^\/assets\/product-cards-20261117\/images\/(\d+)\/[\w-]+\.(?:avif|webp|jpe?g|png)$/i.exec(url);
        var native = /^\/upload\/shop_1\/(?:[\w-]+\/)*item_(\d+)\/(?:small_)?(?:item_image\1|shop_property_file_\d+_\d+)\.(?:avif|webp|jpe?g|png)$/i.exec(url);
        return (curated && curated[1] === itemId) || (native && native[1] === itemId) ? url : '';
    }

    function secondPhoto(html, itemId) {
        // Template contents are inert: only the chosen preview is loaded.
        var parsed = document.createElement('template');
        parsed.innerHTML = html;
        var gallery = parsed.content.querySelector('[data-ks-product-gallery="' + itemId + '"]');
        if (!gallery) return '';
        var photos = Array.from(gallery.querySelectorAll('[data-ks-gallery-slide][data-ks-slide-kind="photo"] img'));
        var thumbs = gallery.querySelectorAll('.gallery-side img');
        var cover = photos[0] && photos[0].getAttribute('src');
        for (var index = 1; index < photos.length; index++) {
            var src = safePhoto(photos[index].getAttribute('src'), itemId);
            if (!src || src === cover || /черт[её]ж|\bdiagram\b/i.test(photos[index].getAttribute('alt') || '')) continue;
            var thumb = thumbs.length === photos.length && safePhoto(thumbs[index].getAttribute('src'), itemId);
            return thumb && thumb !== thumbs[0].getAttribute('src') ? thumb : src;
        }
        return '';
    }

    function previewFor(url, itemId) {
        if (!previews.has(url)) {
            previews.set(url, fetch(url, { credentials: 'omit', redirect: 'error' })
                .then(function (response) { return response.ok ? response.text() : ''; })
                .then(function (html) { return html ? secondPhoto(html, itemId) : ''; })
                .catch(function () { previews.delete(url); return ''; }));
        }
        return previews.get(url);
    }

    function restoreCover() {
        if (!active) return;
        clearTimeout(active.timer);
        if (active.cover) {
            active.image.setAttribute('src', active.cover.src);
            if (active.cover.srcset !== null) active.image.setAttribute('srcset', active.cover.srcset);
        }
        active = null;
    }

    function showPreview(hover, url, itemId) {
        previewFor(url, itemId).then(function (source) {
            if (!source || active !== hover || source === hover.image.getAttribute('src')) return;
            var preview = new Image();
            preview.onload = function () {
                if (active !== hover || !hover.link.isConnected) return;
                var image = hover.image;
                hover.cover = { src: image.getAttribute('src'), srcset: image.getAttribute('srcset') };
                image.removeAttribute('srcset');
                image.setAttribute('src', source);
            };
            preview.src = source;
        });
    }

    document.addEventListener('pointerover', function (event) {
        if (!mouseAvailable.matches || event.pointerType !== 'mouse' || !(event.target instanceof Element)) return;
        var link = event.target.closest(selector);
        if (!link || (event.relatedTarget instanceof Node && link.contains(event.relatedTarget))) return;
        var url = new URL(link.href);
        var product = /^\/category\/(?:[\w-]+\/)+(\d+)\/$/.exec(url.pathname);
        var image = link.querySelector(':scope > img[src]');
        if (!product || url.origin !== window.location.origin || url.search || url.hash || !image) return;
        restoreCover();
        var hover = { link: link, image: image };
        active = hover;
        hover.timer = setTimeout(function () { showPreview(hover, url.href, product[1]); }, 150);
    });

    document.addEventListener('pointerout', function (event) {
        if (!active || event.pointerType !== 'mouse' || !active.link.contains(event.target)) return;
        if (!(event.relatedTarget instanceof Node && active.link.contains(event.relatedTarget))) restoreCover();
    });
    window.addEventListener('blur', restoreCover);
}());
