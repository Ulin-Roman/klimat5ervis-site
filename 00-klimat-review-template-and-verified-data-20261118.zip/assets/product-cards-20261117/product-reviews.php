<?php
/** External product reviews for the HostCMS product presentation adapter. */
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

function klimat_product_cards_20261117_review_overlay($id, $nativeName)
{
    if (!preg_match('~^[0-9]{1,12}$~D', (string) $id)) return array();
    $file = __DIR__ . '/data/reviews/' . $id . '.json';
    $limit = 65536;
    if (!is_file($file) || is_link($file)) return array();
    $size = @filesize($file);
    if ($size === FALSE || $size < 2 || $size >= $limit) return array();
    $raw = @file_get_contents($file, FALSE, NULL, 0, $limit);
    if (!is_string($raw) || strlen($raw) >= $limit) return array();
    $record = json_decode($raw, TRUE);
    if (!isset($record['model'], $record['sources']) || !is_string($record['model']) || !is_array($record['sources'])) return array();
    if ((!is_int($record['item_id'] ?? NULL) && !is_string($record['item_id'] ?? NULL)) || (string) $record['item_id'] !== (string) $id) return array();
    return klimat_product_cards_20261117_text($record['model']) === $nativeName ? $record['sources'] : array();
}

function klimat_product_cards_20261117_review_text($record, $key)
{
    return isset($record[$key]) && is_string($record[$key]) ? klimat_product_cards_20261117_text($record[$key]) : '';
}

function klimat_product_cards_20261117_review_count($value)
{
    if (!is_string($value) && !is_int($value)) return NULL;
    $count = filter_var($value, FILTER_VALIDATE_INT, array('options' => array('min_range' => 0)));
    return $count === FALSE ? NULL : $count;
}

function klimat_product_cards_20261117_review_rating($value, $scale)
{
    if (!is_numeric($value) || !is_numeric($scale)) return NULL;
    $rating = (float) $value;
    $scale = (float) $scale;
    return is_finite($rating) && $scale > 0 && $scale <= 10 && $rating > 0 && $rating <= $scale
        ? 5 * $rating / $scale
        : NULL;
}

function klimat_product_cards_20261117_review_key($text)
{
    $text = trim(preg_replace('~[\p{P}\p{Z}\s]+~u', ' ', $text) ?? $text);
    return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
}

function klimat_product_cards_20261117_normalize_review_source($row, $id, $overlay)
{
    if (!is_array($row)) return NULL;
    $name = klimat_product_cards_20261117_review_text($row, $overlay ? 'name' : 'source_name');
    $url = klimat_product_cards_20261117_url($row[$overlay ? 'url' : 'source_url'] ?? '');
    $date = $row[$overlay ? 'checked_on' : 'checked_at'] ?? '';
    if ($name === '' || !klimat_product_cards_20261117_verified(array('source_url' => $url, 'checked_at' => $date))) return NULL;

    if ($overlay) {
        $scope = $row['rating_scope'] ?? 'unknown';
    } else {
        $legacyExact = (string) $id === '7701' && $name === 'Технопарк' && !array_key_exists('exact_model_match', $row);
        $scope = ($row['exact_model_match'] ?? NULL) === TRUE || $legacyExact ? 'exact' : 'unknown';
    }
    $scope = in_array($scope, array('exact', 'series'), TRUE) ? $scope : 'unknown';
    $scale = $row['rating_scale'] ?? ($overlay ? 5 : NULL);
    $exact = $scope === 'exact';
    $rating = $exact ? klimat_product_cards_20261117_review_rating($row['rating'] ?? NULL, $scale) : NULL;
    $reviews = $exact ? klimat_product_cards_20261117_review_count($row['review_count'] ?? NULL) : NULL;
    $ratings = $exact ? klimat_product_cards_20261117_review_count($row['rating_count'] ?? NULL) : NULL;
    $note = klimat_product_cards_20261117_review_text($row, $overlay ? 'note' : 'scope_note');
    $summary = $exact ? klimat_product_cards_20261117_review_text($row, 'summary') : '';
    $rawEntries = $row[$overlay ? 'entries' : 'review_summaries'] ?? array();
    $entries = array();
    if ($exact && is_array($rawEntries)) foreach ($rawEntries as $entry) {
        if (!is_array($entry)) continue;
        $text = klimat_product_cards_20261117_review_text($entry, 'summary');
        if ($text === '') continue;
        $entryUrl = klimat_product_cards_20261117_url($entry['source_url'] ?? '');
        $entries[] = array(
            'summary' => $text,
            'author' => klimat_product_cards_20261117_review_text($entry, 'person'),
            'date' => klimat_product_cards_20261117_review_text($entry, 'date'),
            'date_display' => klimat_product_cards_20261117_review_text($entry, 'date_display'),
            'rating' => klimat_product_cards_20261117_review_rating($entry['rating'] ?? NULL, $scale),
            'url' => $entryUrl !== '' ? $entryUrl : $url
        );
    }
    if ($rating === NULL && !$reviews && !$ratings && !$entries && $summary === '' && $note === '') return NULL;

    return array(
        'name' => $name, 'url' => $url, 'checked_at' => $date, 'scope' => $scope,
        'rating' => $rating, 'reviews' => $reviews, 'ratings' => $ratings,
        'note' => $note, 'summary' => $summary, 'entries' => $entries,
        'pros' => $exact && is_array($row['pros'] ?? NULL) ? $row['pros'] : array(),
        'cons' => $exact && is_array($row['cons'] ?? NULL) ? $row['cons'] : array()
    );
}

/** Retain curated records and show new sources independently. Counts can overlap across platforms. */
function klimat_product_cards_20261117_review_data($id, $entry, $overlay)
{
    $groups = array('exact' => array(), 'other' => array());
    $themes = array('pros' => array(), 'cons' => array());
    $seen = array();
    $normalized = array();
    $primary = NULL;
    $curated = isset($entry['external_reviews']) && is_array($entry['external_reviews']) ? $entry['external_reviews'] : array();
    foreach (array($curated, $overlay) as $type => $rows) foreach ($rows as $row) {
        $source = klimat_product_cards_20261117_normalize_review_source($row, $id, $type === 1);
        if ($source === NULL) continue;
        $host = preg_replace('~^www\.~i', '', strtolower(parse_url($source['url'], PHP_URL_HOST)));
        $path = rtrim((string) parse_url($source['url'], PHP_URL_PATH), '/');
        $key = $host . $path;
        if (isset($normalized[$key])) {
            $prior = $normalized[$key];
            if ($type === 0 || ($prior['scope'] === 'exact' && $source['scope'] !== 'exact') || $prior['checked_at'] > $source['checked_at']) continue;
        }
        $normalized[$key] = $source;
    }
    foreach ($normalized as $source) {
        $exact = $source['scope'] === 'exact';
        if ($exact) {
            $uniqueEntries = array();
            foreach ($source['entries'] as $review) {
                $key = klimat_product_cards_20261117_review_key($review['summary']);
                if ($key === '' || isset($seen[$key])) continue;
                $seen[$key] = TRUE;
                $uniqueEntries[] = $review;
            }
            $source['entries'] = $uniqueEntries;
            foreach (array('pros', 'cons') as $group) foreach ($source[$group] as $theme) {
                if (!is_string($theme)) continue;
                $theme = klimat_product_cards_20261117_text($theme);
                $key = klimat_product_cards_20261117_review_key($theme);
                if ($key !== '' && !isset($themes[$group][$key])) $themes[$group][$key] = $theme;
            }
        }
        $groups[$exact ? 'exact' : 'other'][] = $source;
        if (!$exact) continue;
        $strength = array(
            $source['rating'] !== NULL && ($source['reviews'] > 0 || $source['ratings'] > 0),
            $source['ratings'] !== NULL,
            $source['reviews'] ?? 0,
            $source['ratings'] ?? 0
        );
        if ($strength[0] && ($primary === NULL || $strength > $primary['strength'])) {
            $primary = $source;
            $primary['strength'] = $strength;
        }
    }
    return array('groups' => $groups, 'primary' => $primary, 'themes' => $themes);
}

function klimat_product_cards_20261117_reviews_quantity($count, $written = TRUE)
{
    $words = $written ? array('отзыв', 'отзыва', 'отзывов') : array('оценка', 'оценки', 'оценок');
    $last = $count % 10;
    $teen = $count % 100;
    $word = $teen >= 11 && $teen <= 14 ? $words[2] : ($last === 1 ? $words[0] : ($last >= 2 && $last <= 4 ? $words[1] : $words[2]));
    return $count . ' ' . $word;
}

function klimat_product_cards_20261117_reviews_score($doc, $rating, $showStars = TRUE)
{
    $score = klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-review-score');
    if ($showStars) {
        $stars = klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-rating-stars', '★★★★★');
        $stars->setAttribute('aria-hidden', 'true');
        $stars->setAttribute('style', '--ks-rating-fill:' . round(20 * $rating) . '%');
        $score->appendChild($stars);
    }
    $formatted = rtrim(rtrim(number_format($rating, 2, ',', ''), '0'), ',');
    $value = klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-rating-value', $formatted . '/5');
    $value->setAttribute('aria-label', $formatted . ' из 5');
    $score->appendChild($value);
    return $score;
}

function klimat_product_cards_20261117_reviews_link($doc, $primary)
{
    $link = klimat_product_cards_20261117_el($doc, 'a', 'ks-pdp-reviews-link');
    $link->setAttribute('href', '#tabs-ks-reviews');
    $link->setAttribute('data-ks-open-tab', 'tabs-ks-reviews');
    if ($primary !== NULL) {
        klimat_product_cards_20261117_class($link, 'ks-pdp-reviews-link--rated');
        $link->appendChild(klimat_product_cards_20261117_reviews_score($doc, $primary['rating']));
        $details = array($primary['name']);
        if ($primary['ratings'] !== NULL) $details[] = klimat_product_cards_20261117_reviews_quantity($primary['ratings'], FALSE);
        $link->appendChild(klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-review-link-detail', implode(' · ', $details)));
    }
    $link->appendChild(klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-review-link-label', 'Отзывы'));
    return $link;
}

function klimat_product_cards_20261117_reviews_source_link($doc, $class, $label, $url)
{
    $link = klimat_product_cards_20261117_el($doc, 'a', $class, $label);
    $link->setAttribute('href', $url);
    $link->setAttribute('target', '_blank');
    $link->setAttribute('rel', 'noopener noreferrer');
    return $link;
}

function klimat_product_cards_20261117_reviews_date($doc, $iso, $display = '')
{
    if (preg_match('~^(\d{4})-(\d{2})-(\d{2})$~D', $iso, $date) && checkdate((int) $date[2], (int) $date[3], (int) $date[1])) {
        $time = klimat_product_cards_20261117_el($doc, 'time', '', $date[3] . '.' . $date[2] . '.' . $date[1]);
        $time->setAttribute('datetime', $iso);
        return $time;
    }
    return $display !== '' ? klimat_product_cards_20261117_el($doc, 'span', '', $display) : NULL;
}

function klimat_product_cards_20261117_reviews_source($doc, $source)
{
    $section = klimat_product_cards_20261117_el($doc, 'section', 'ks-pdp-review-source');
    $head = klimat_product_cards_20261117_el($doc, 'header', 'ks-pdp-review-source-head');
    $heading = klimat_product_cards_20261117_el($doc, 'h3');
    $heading->appendChild(klimat_product_cards_20261117_reviews_source_link($doc, '', $source['name'], $source['url']));
    $head->appendChild($heading);
    if ($source['scope'] !== 'exact' && $source['note'] === '') {
        $badge = $source['scope'] === 'series' ? 'Отзывы по серии' : 'Вариант не подтверждён';
        $head->appendChild(klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-review-scope', $badge));
    }
    $section->appendChild($head);

    $counts = array();
    if ($source['ratings'] !== NULL) $counts[] = klimat_product_cards_20261117_reviews_quantity($source['ratings'], FALSE);
    if ($source['reviews'] !== NULL) $counts[] = klimat_product_cards_20261117_reviews_quantity($source['reviews']);
    if ($source['rating'] !== NULL || $counts) {
        $stat = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-review-stats');
        if ($source['rating'] !== NULL) $stat->appendChild(klimat_product_cards_20261117_reviews_score($doc, $source['rating']));
        if ($counts) $stat->appendChild(klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-review-counts', implode(' · ', $counts)));
        $section->appendChild($stat);
    }
    if ($source['summary'] !== '') $section->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-summary', $source['summary']));
    if ($source['note'] !== '') $section->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-source-note', $source['note']));

    if ($source['entries']) {
        $entries = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-review-paraphrases');
        foreach ($source['entries'] as $entry) {
            $article = klimat_product_cards_20261117_el($doc, 'article', 'ks-pdp-review-paraphrase');
            $details = klimat_product_cards_20261117_el($doc, 'header', 'ks-pdp-review-entry-head');
            $author = $entry['author'] !== '' ? $entry['author'] : 'Отзыв покупателя';
            $details->appendChild(klimat_product_cards_20261117_el($doc, 'h4', '', $author));
            if ($entry['rating'] !== NULL) $details->appendChild(klimat_product_cards_20261117_reviews_score($doc, $entry['rating'], FALSE));
            $date = klimat_product_cards_20261117_reviews_date($doc, $entry['date'], $entry['date_display']);
            if ($date !== NULL) $details->appendChild($date);
            $article->appendChild($details);
            $article->appendChild(klimat_product_cards_20261117_el($doc, 'p', '', $entry['summary']));
            if ($entry['url'] !== $source['url']) {
                $article->appendChild(klimat_product_cards_20261117_reviews_source_link($doc, 'ks-pdp-review-original', 'Читать оригинал', $entry['url']));
            }
            $entries->appendChild($article);
        }
        $section->appendChild($entries);
    }

    $footer = klimat_product_cards_20261117_el($doc, 'footer', 'ks-pdp-review-source-foot');
    $label = $source['scope'] === 'exact' ? 'Все отзывы на площадке' : 'Смотреть на площадке';
    $link = klimat_product_cards_20261117_reviews_source_link($doc, 'ks-pdp-review-original', $label, $source['url']);
    $link->setAttribute('aria-label', $label . ' «' . $source['name'] . '»');
    $footer->appendChild($link);
    $updated = klimat_product_cards_20261117_el($doc, 'span', 'ks-pdp-review-date', 'Проверено ');
    $updated->appendChild(klimat_product_cards_20261117_reviews_date($doc, $source['checked_at']));
    $footer->appendChild($updated);
    $section->appendChild($footer);
    return $section;
}

function klimat_product_cards_20261117_reviews_panel($doc, $head, $root, $reviews)
{
    $primary = $reviews['primary'];
    $label = 'Отзывы';
    if ($primary !== NULL && $primary['reviews'] > 0) $label .= ' (' . $primary['reviews'] . ')';
    $item = klimat_product_cards_20261117_el($doc, 'li');
    $link = klimat_product_cards_20261117_el($doc, 'a', '', $label);
    $link->setAttribute('href', '#tabs-ks-reviews');
    $item->appendChild($link);
    $head->appendChild($item);

    $panel = klimat_product_cards_20261117_el($doc, 'div', 'product-tabs__content ks-pdp-reviews');
    $panel->setAttribute('id', 'tabs-ks-reviews');
    $panel->appendChild(klimat_product_cards_20261117_el($doc, 'h2', '', 'Рейтинг и отзывы покупателей'));
    $exact = $reviews['groups']['exact'];
    $other = $reviews['groups']['other'];
    if ($exact) {
        $intro = 'Данные внешних площадок.';
        if (array_filter(array_column($exact, 'entries'))) $intro .= ' Отзывы приведены в кратком пересказе.';
        $panel->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-intro', $intro));
        if ($reviews['themes']['pros'] || $reviews['themes']['cons']) {
            $themes = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-review-themes');
            foreach (array('pros' => 'Достоинства', 'cons' => 'Недостатки') as $group => $heading) {
                if (!$reviews['themes'][$group]) continue;
                $card = klimat_product_cards_20261117_el($doc, 'section', 'ks-pdp-review-theme');
                $card->appendChild(klimat_product_cards_20261117_el($doc, 'h3', '', $heading));
                $list = klimat_product_cards_20261117_el($doc, 'ul');
                foreach ($reviews['themes'][$group] as $theme) {
                    $list->appendChild(klimat_product_cards_20261117_el($doc, 'li', '', $theme));
                }
                $card->appendChild($list);
                $themes->appendChild($card);
            }
            $panel->appendChild($themes);
        }
        foreach ($exact as $source) $panel->appendChild(klimat_product_cards_20261117_reviews_source($doc, $source));
    } else {
        $panel->appendChild(klimat_product_cards_20261117_el($doc, 'p', 'ks-pdp-review-empty', 'Пока нет подтверждённых отзывов об этой модели.'));
    }
    if ($other) {
        $related = klimat_product_cards_20261117_el($doc, 'div', 'ks-pdp-review-related');
        foreach ($other as $source) $related->appendChild(klimat_product_cards_20261117_reviews_source($doc, $source));
        $panel->appendChild($related);
    }
    $root->appendChild($panel);
}
