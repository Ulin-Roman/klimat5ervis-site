<?php
// Change the two fixed booleans only after the canonical-route QA is complete.
if (!defined('HOSTCMS')) { http_response_code(404); exit; }
return array('enabled' => TRUE, 'preview_enabled' => TRUE);
