<?php
/** Canonical-route presentation adapter. Native bootstrap/config/checkout remain in place. */
if (!defined('HOSTCMS')) { http_response_code(404); exit; }
require_once __DIR__ . '/production-transform.php';

function klimat_prod_20261117_try_render()
{
    if (!defined('CURRENT_SITE') || (int) CURRENT_SITE !== 2 || !class_exists('Core_Page', FALSE)
        || !function_exists('klimat_page_metadata') || !function_exists('klimat_seo_head')) return FALSE;
    $configPath = __DIR__ . '/config.php';
    if (!is_file($configPath) || is_link($configPath)) return FALSE;
    $config = require $configPath;
    if (!is_array($config) || !isset($config['enabled'], $config['preview_enabled'])
        || !is_bool($config['enabled']) || !is_bool($config['preview_enabled'])) return FALSE;
    $preview = isset($_GET['ks_front_preview']) && $_GET['ks_front_preview'] === '1';
    if (!$config['enabled'] && !($preview && $config['preview_enabled'])) return FALSE;
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
    $route = klimat_prod_20261117_route($uri, $_GET, $method);
    if ($route === NULL) return FALSE;
    $page = Core_Page::instance();
    if (!is_object($page->structure) || (int) $page->structure->site_id !== 2 || $page->response->getStatus() !== 200) return FALSE;
    $structurePath = (string) $page->structure->getPath();
    $expectedStructure = array('home'=>'/','catalog'=>'/category/','company'=>'/company/',
        'delivery'=>'/delivery/','contacts'=>'/kontakty/');
    if ($structurePath !== $expectedStructure[$route]) return FALSE;
    // Keep the existing native product presentation and its fast-order/favorite
    // integrations. Catalog lists still use the new presentation below.
    if ($route === 'catalog' && $page->object instanceof Shop_Controller_Show
        && (int) $page->object->item > 0) return FALSE;
    $sourcePath = __DIR__ . '/sources/' . $route . '.php';
    if (!is_file($sourcePath) || is_link($sourcePath)) return FALSE;
    $page->staticCache(FALSE);
    $baseLevel = ob_get_level();
    $previousDisplay = ini_get('display_errors');
    ini_set('display_errors', '0');
    try {
        // Capture the existing page's metadata before a second display controller is built.
        ob_start();
        klimat_page_metadata();
        ob_start(); $page->showKeywords(); $keywords = ob_get_clean();
        echo '<meta name="keywords" content="' . htmlspecialchars(html_entity_decode(strip_tags($keywords), ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8') . '">';
        klimat_seo_head();
        $metadata = ob_get_clean();
        if (!defined('KLIMAT_PRODUCTION_PRESENTATION_20261117')) define('KLIMAT_PRODUCTION_PRESENTATION_20261117', TRUE);
        ob_start();
        (static function ($ksPresentationSourcePath) {
            require $ksPresentationSourcePath;
        })($sourcePath);
        if (ob_get_level() !== $baseLevel + 1) throw new RuntimeException('Unbalanced presentation buffer');
        $html = ob_get_clean();
        if ($page->response->getStatus() >= 400) throw new RuntimeException('Native route unavailable');
        $analyticsPath = __DIR__ . '/analytics.html';
        $cookiePath = __DIR__ . '/cookie.html';
        if (!is_file($analyticsPath) || is_link($analyticsPath) || !is_file($cookiePath) || is_link($cookiePath)) {
            throw new RuntimeException('Missing shared presentation');
        }
        $analytics = file_get_contents($analyticsPath);
        $cookie = file_get_contents($cookiePath);
        if (!is_string($analytics) || !is_string($cookie)) throw new RuntimeException('Shared presentation unavailable');
        // Its existing inline messenger script looks up this notice immediately.
        // Put the unchanged notice before that script, so the offset observer attaches.
        if (strpos($html, 'id="ks-cookie-notice"') !== FALSE) throw new RuntimeException('Unexpected duplicate cookie notice');
        $widgetCount = 0;
        $html = preg_replace_callback('~<div\b[^>]*\bid\s*=\s*([\x22\x27])ks-messenger-widget\1[^>]*>~i', static function ($match) use ($cookie, &$widgetCount) {
            $widgetCount++; return $cookie . $match[0];
        }, $html);
        if ($widgetCount !== 1) throw new RuntimeException('Missing messenger presentation');
        $secondary = '<div class="production-footer-nav wrap"><nav aria-label="Дополнительные разделы">'
            . '<a href="/company/">О компании</a><a href="/offers/">Акции</a><a href="/blog/">Блог</a>'
            . '<a href="/category/favorite/">Избранное</a><a href="/return/">Возврат</a>'
            . '<a href="/politics/">Пользовательское соглашение</a>'
            . '<button class="ks-cookie-settings" type="button" data-cookie-open>О файлах cookie</button></nav></div>';
        $extras = '<link rel="stylesheet" href="/assets/production-front-20261117/production-extras.css">'
            . $secondary
            . '<script defer src="/assets/footer-20261116/cookie-notice.js?v=1"></script>'
            . ($preview ? '' : $analytics);
        $html = klimat_prod_20261117_html($html, $metadata, $uri, $preview, $extras);
        if ($preview) $html = preg_replace('~(<body\b[^>]*>)~i', '$1<div class="production-preview-badge" role="note">Тест новой версии</div>', $html, 1);
    } catch (Throwable $exception) {
        while (ob_get_level() > $baseLevel) ob_end_clean();
        // Native error statuses remain errors; otherwise the unmodified template is the fallback.
        http_response_code($page->response->getStatus());
        return FALSE;
    } finally {
        ini_set('display_errors', $previousDisplay === FALSE ? '0' : $previousDisplay);
    }
    // The header includes the current cart count. Never share/cache this HTML across visitors.
    $headers = array('Cache-Control'=>'private, no-store, max-age=0','Pragma'=>'no-cache');
    if ($preview) $headers['X-Robots-Tag'] = 'noindex, nofollow, noarchive';
    foreach ($headers as $name => $value) {
        $page->response->header($name, $value);
        header($name . ': ' . $value);
    }
    echo $html;
    return TRUE;
}
