<?php
/** Pure presentation/route helpers. They neither execute HostCMS nor write state. */
if (!defined('HOSTCMS')) { http_response_code(404); exit; }

function klimat_prod_20261117_path($uri)
{
    if (!is_string($uri) || strlen($uri) > 8192 || preg_match('/[\x00-\x20\x7F]/', $uri)) return NULL;
    $parts = parse_url($uri);
    if ($parts === FALSE || (isset($parts['host']) && !isset($parts['scheme']))
        || (isset($parts['scheme']) && (!in_array(strtolower($parts['scheme']), array('http','https'), TRUE)
        || !isset($parts['host']) || strtolower($parts['host']) !== 'klimat5ervis.ru'
        || isset($parts['port']) || isset($parts['user']) || isset($parts['pass'])))) return NULL;
    $raw = parse_url($uri, PHP_URL_PATH);
    if (!is_string($raw) || $raw === '' || $raw[0] !== '/' || strpos($raw, '//') === 0
        || preg_match('~%(?:2f|5c|00)~i', $raw)) return NULL;
    $path = rawurldecode($raw);
    if (!preg_match('//u', $path) || strpos($path, '//') !== FALSE || strpos($path, '%') !== FALSE
        || preg_match('~[\x00-\x20\x7F\\\\]~', $path) || preg_match('~(?:^|/)\.{1,2}(?:/|$)~', $path)) return NULL;
    return $path;
}

function klimat_prod_20261117_route($uri, array $query, $method = 'GET')
{
    if ($method !== 'GET' && $method !== 'HEAD') return NULL;
    $path = klimat_prod_20261117_path($uri);
    if ($path === NULL || count($query) > 32) return NULL;
    $allowed = array('q','sort','min','max','page','brand','inverter','wifi','capacity','ks_front_preview');
    foreach ($query as $key => $value) {
        if (!is_string($key) || !is_string($value) || strlen($value) > 2048) return NULL;
        $tracking = preg_match('/^(?:utm_[a-z0-9_]+|yclid|gclid|fbclid|etext|ybaip|erid|ysclid|_openstat)$/i', $key);
        if (!in_array($key, $allowed, TRUE) && !$tracking) return NULL;
    }
    if (isset($query['ks_front_preview']) && $query['ks_front_preview'] !== '1') return NULL;
    $exact = array('/'=>'home','/company/'=>'company','/delivery/'=>'delivery','/kontakty/'=>'contacts');
    if (isset($exact[$path])) {
        foreach (array('q','sort','min','max','page','brand','inverter','wifi','capacity') as $field) {
            if (array_key_exists($field, $query)) return NULL;
        }
        return $exact[$path];
    }
    if (strpos($path, '/category/') !== 0) return NULL;
    $relative = substr($path, strlen('/category/'));
    $first = strtolower(explode('/', $relative)[0]);
    if (in_array($first, array('cart','favorite','compare','payment','checkout','callback'), TRUE)) return NULL;
    return 'catalog';
}

function klimat_prod_20261117_canonical($uri)
{
    // Keep native paths and real query values; omit preview/tracking and empty/default controls.
    $path = parse_url($uri, PHP_URL_PATH);
    if (!is_string($path) || $path === '') $path = '/';
    $query = array();
    parse_str((string) parse_url($uri, PHP_URL_QUERY), $query);
    foreach (array_keys($query) as $key) {
        if ($key === 'ks_front_preview' || preg_match('/^(utm_|yclid$|gclid$|fbclid$|etext$|ybaip$|erid$|ysclid$)/i', $key)) {
            unset($query[$key]);
            continue;
        }
        if (in_array($key, array('q','sort','min','max','page','brand','inverter','wifi','capacity'), TRUE)
            && is_string($query[$key]) && trim($query[$key]) === '') unset($query[$key]);
        elseif ($key === 'sort' && is_string($query[$key]) && trim($query[$key]) === 'name') unset($query[$key]);
    }
    ksort($query);
    return 'https://klimat5ervis.ru' . $path . ($query ? '?' . http_build_query($query) : '');
}

function klimat_prod_20261117_href($value, $preview)
{
    if (!is_string($value) || $value === '' || $value[0] === '#') return $value;
    $decoded = html_entity_decode($value, ENT_QUOTES, 'UTF-8');
    $parts = parse_url($decoded);
    if ($parts === FALSE || !isset($parts['path'])) return $decoded;
    if (isset($parts['scheme']) && (!in_array(strtolower($parts['scheme']), array('http','https'), TRUE)
        || !isset($parts['host']) || strtolower($parts['host']) !== 'klimat5ervis.ru'
        || isset($parts['port']) || isset($parts['user']) || isset($parts['pass']))) return $decoded;
    if (isset($parts['host']) && !isset($parts['scheme'])) return $decoded;
    if ($parts['path'] === '' || $parts['path'][0] !== '/') return $decoded;
    $path = $parts['path'];
    $map = array('/modern-catalog/'=>'/category/','/modern-cart/'=>'/category/cart/',
        '/modern-home/'=>'/','/modern-company/'=>'/company/',
        '/modern-delivery/'=>'/delivery/','/modern-contacts/'=>'/kontakty/');
    foreach ($map as $from => $to) {
        if ($path === rtrim($from, '/') || strpos($path, $from) === 0) {
            $path = $to . ltrim(substr($path, strlen(rtrim($from, '/'))), '/');
            break;
        }
    }
    $query = array();
    if (isset($parts['query'])) parse_str($parts['query'], $query);
    if ($preview && klimat_prod_20261117_route($path, $query, 'GET') !== NULL) $query['ks_front_preview'] = '1';
    $url = (isset($parts['scheme']) ? $parts['scheme'] . '://' . $parts['host'] : '') . $path;
    if ($query) $url .= '?' . http_build_query($query);
    if (isset($parts['fragment'])) $url .= '#' . $parts['fragment'];
    return $url;
}

function klimat_prod_20261117_filtered_catalog($uri)
{
    $path = parse_url($uri, PHP_URL_PATH);
    if (!is_string($path) || strpos($path, '/category/') !== 0) return FALSE;
    $query = array();
    parse_str((string) parse_url($uri, PHP_URL_QUERY), $query);
    foreach (array('q','min','max','brand','inverter','wifi','capacity') as $key) {
        if (isset($query[$key]) && is_string($query[$key]) && trim($query[$key]) !== '') return TRUE;
    }
    return isset($query['sort']) && is_string($query['sort'])
        && trim($query['sort']) !== '' && trim($query['sort']) !== 'name';
}

function klimat_prod_20261117_metadata($metadata, $uri, $preview)
{
    $canonical = htmlspecialchars(klimat_prod_20261117_canonical($uri), ENT_QUOTES, 'UTF-8');
    $canonicalTag = '<link rel="canonical" href="' . $canonical . '">';
    $found = 0;
    $metadata = preg_replace_callback('~<link\b[^>]*>~i', static function ($m) use ($canonicalTag, &$found) {
        if (preg_match('~\brel\s*=\s*([\x22\x27])canonical\1~i', $m[0])) { $found++; return $found === 1 ? $canonicalTag : ''; }
        return $m[0];
    }, $metadata);
    if (!$found) $metadata .= "\n" . $canonicalTag;
    $robots = $preview ? 'noindex,nofollow,noarchive'
        : (klimat_prod_20261117_filtered_catalog($uri) ? 'noindex,follow' : NULL);
    if ($robots !== NULL) {
        $metadata = preg_replace('~<meta\b(?=[^>]*\bname\s*=\s*([\x22\x27])robots\1)[^>]*>~i', '', $metadata);
        $metadata .= "\n<meta name=\"robots\" content=\"" . $robots . "\">";
    }
    return $metadata;
}

/** XML serializers may shorten empty HTML containers; browsers do not close them. */
function klimat_prod_20261117_normalize_html($html)
{
    if (!is_string($html)) return $html;
    $void = array('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr');
    $foreignDepth = 0;
    // Raw-text opening tags must not be self-closing: <script src="..."/> is a tag to expand.
    $tokens = '~<!--[\s\S]*?-->|<(script|style|textarea|title)\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*(?<!/)>'
        . '[\s\S]*?</\1\s*>|<(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>~i';
    $result = preg_replace_callback($tokens, static function ($match) use ($void, &$foreignDepth) {
        $tag = $match[0];
        if (strpos($tag, '<!--') === 0 || (isset($match[1]) && $match[1] !== '')) return $tag;
        if (!preg_match('~^<(/?)([A-Za-z][A-Za-z0-9:-]*)\b~', $tag, $parts)) return $tag;
        $name = strtolower($parts[2]);
        $closing = $parts[1] === '/';
        $selfClosing = preg_match('~/\s*>$~', $tag);
        if ($name === 'svg' || $name === 'math') {
            if ($closing) $foreignDepth = max(0, $foreignDepth - 1);
            elseif (!$selfClosing) $foreignDepth++;
            return $tag;
        }
        if ($foreignDepth || $closing || !$selfClosing || strpos($name, ':') !== FALSE || in_array($name, $void, TRUE)) return $tag;
        return preg_replace('~/\s*>$~', '>', $tag, 1) . '</' . $parts[2] . '>';
    }, $html);
    if (!is_string($result)) throw new RuntimeException('HTML container normalization failed');
    return $result;
}


function klimat_prod_20261117_html($html, $metadata, $uri, $preview, $extras)
{
    if (!is_string($html) || strlen($html) > 6000000 || !preg_match('~<head\b~i', $html)
        || !preg_match('~<body\b~i', $html) || !preg_match('~<title\b[^>]*>\s*[^<]+~i', $metadata)) {
        throw new RuntimeException('Incomplete storefront presentation');
    }
    $html = klimat_prod_20261117_normalize_html($html);
    $metadata = klimat_prod_20261117_metadata($metadata, $uri, $preview);
    $count = 0;
    $html = preg_replace_callback('~(<head\b[^>]*>)([\s\S]*?)(</head\s*>)~i', static function ($m) use ($metadata, &$count) {
        if (++$count !== 1) throw new RuntimeException('Multiple head sections');
        $head = preg_replace('~<title\b[^>]*>[\s\S]*?</title\s*>~i', '', $m[2]);
        $head = preg_replace('~<meta\b(?=[^>]*\bname\s*=\s*([\x22\x27])(?:description|keywords|robots)\1)[^>]*>~i', '', $head);
        $head = preg_replace('~<link\b(?=[^>]*\brel\s*=\s*([\x22\x27])canonical\1)[^>]*>~i', '', $head);
        $head = preg_replace('~<script\b(?=[^>]*\btype\s*=\s*([\x22\x27])application/ld\+json\1)[^>]*>[\s\S]*?</script\s*>~i', '', $head);
        return $m[1] . $head . "\n" . $metadata . "\n" . $m[3];
    }, $html);
    if ($count !== 1) throw new RuntimeException('Missing head section');
    // Only the template's own top notice is removed. Stored page content is not stripped.
    $html = preg_replace('~<div\b[^>]*\bclass=([\x22\x27])notice\1[^>]*>[\s\S]*?</div\s*>~i', '', $html, 1);
    $bodyEnds = 0;
    $opaqueOrBody = '~<!--[\s\S]*?-->|<(script|style|textarea)\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>'
        . '[\s\S]*?</\1\s*>|</body\s*>~i';
    $html = preg_replace_callback($opaqueOrBody, static function ($m) use ($extras, &$bodyEnds) {
        if (!preg_match('~^</body\s*>~i', $m[0])) return $m[0];
        $bodyEnds++; return $extras . $m[0];
    }, $html);
    if ($bodyEnds !== 1) throw new RuntimeException('Invalid body section');
    // Treat raw-text elements/comments as opaque, preserving inline script/style bytes.
    $tokens = '~<!--[\s\S]*?-->|<(script|style|textarea)\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>'
        . '[\s\S]*?</\1\s*>|<(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>~i';
    $html = preg_replace_callback($tokens, static function ($m) use ($preview) {
        $tag = $m[0];
        if (strpos($tag, '<!--') === 0 || preg_match('~^<(?:script|style|textarea)\b~i', $tag)) return $tag;
        if (preg_match('~^<link\b[^>]*\brel\s*=\s*([\x22\x27])canonical\1~i', $tag)) return $tag;
        $tag = preg_replace_callback('~(\s)(href|action)\s*=\s*([\x22\x27])([^\x22\x27]*)\3~i', static function ($a) use ($preview) {
            $url = klimat_prod_20261117_href($a[4], $preview);
            return $a[1] . $a[2] . '=' . $a[3] . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . $a[3];
        }, $tag);
        if ($preview && preg_match('~^<form\b~i', $tag)
            && (!preg_match('~\smethod\s*=\s*([\x22\x27])([^\x22\x27]*)\1~i', $tag, $method) || strtolower($method[2]) === 'get')
            && preg_match('~\saction\s*=\s*([\x22\x27])([^\x22\x27]*)\1~i', $tag, $action)) {
            $url = html_entity_decode($action[2], ENT_QUOTES, 'UTF-8'); $query = array();
            parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
            if (klimat_prod_20261117_route($url, $query, 'GET') !== NULL) $tag .= '<input type="hidden" name="ks_front_preview" value="1">';
        }
        return $tag;
    }, $html);
    if (!is_string($html)) throw new RuntimeException('Presentation transform failed');
    return $html;
}
