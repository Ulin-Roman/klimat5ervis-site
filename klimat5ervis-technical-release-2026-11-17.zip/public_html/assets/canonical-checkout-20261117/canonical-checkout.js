/* Presentation only: native controls, submission and AJAX handlers remain in place. */
(function () {
  'use strict';
  // Both the shared head and legacy checkout markup may reference this file.
  if (window.klimatNativeCheckout20261117) return;
  window.klimatNativeCheckout20261117 = true;
  var initialized = new WeakSet();
  function isCheckout(form) {
    if (form.method.toLowerCase() !== 'post') return false;
    var target;
    try { target = new URL(form.getAttribute('action') || location.href, location.href); }
    catch (error) { return false; }
    return target.origin === location.origin && target.pathname === '/category/cart/' &&
      form.querySelector('.checkout__fields-list input[name="name"]') &&
      form.querySelector('.checkout__fields-list input[name="phone"]') &&
      form.querySelector('.checkout__fields-list input[name="email"]') &&
      form.querySelector('input[name="shop_delivery_condition_id"]') &&
      (form.querySelector('.formpayment') || form.querySelector('.ks-checkout-delivery'));
  }
  function nativeCents(raw) {
    if (typeof raw !== 'string' || !/^\d+(?:\.\d+)?$/.test(raw.trim())) return null;
    var amount = Number(raw);
    var cents = Math.round(amount * 100);
    return Number.isFinite(amount) && amount >= 0 && Number.isSafeInteger(cents) ? cents : null;
  }
  function formatNativeTotal(cents, summary) {
    if (!Number.isSafeInteger(cents) || cents < 0 || summary.getAttribute('data-ks-currency-ready') !== '1') return null;
    var sign = summary.getAttribute('data-ks-currency-sign');
    var position = summary.getAttribute('data-ks-currency-position');
    var decimal = summary.getAttribute('data-ks-currency-decimal');
    var thousands = summary.getAttribute('data-ks-currency-thousands');
    var hideZeros = summary.getAttribute('data-ks-currency-hide-zeros') === '1';
    if (!sign || (position !== '0' && position !== '1') || decimal === null || thousands === null) return null;
    // Same public formatting fields as Shop_Currency_Model::formatWithCurrency().
    var whole = String(Math.floor(cents / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, function () { return thousands; });
    var fraction = cents % 100;
    var amount = whole + (hideZeros && decimal !== '' && fraction === 0 ? '' : decimal + ('0' + fraction).slice(-2));
    return position === '0' ? amount + '\u202f' + sign : sign + amount;
  }
  function setText(node, value) {
    // Do not retrigger our child-list observer when the summary has not changed.
    if (node && node.textContent !== value) node.textContent = value;
  }
  function updateSummary(form) {
    var summary = form.querySelector('.ks-order-summary');
    if (!summary) return;
    var selected = form.querySelector('input[name="shop_delivery_condition_id"]:checked');
    setText(summary.querySelector('[data-ks-summary-delivery-name]'), selected ? selected.getAttribute('data-ks-delivery-name') || '' : '');
    setText(summary.querySelector('[data-ks-summary-delivery-price]'), selected ? selected.getAttribute('data-ks-delivery-display') || 'Не рассчитана' : 'Не выбрана');
    var base = nativeCents(summary.getAttribute('data-ks-native-subtotal'));
    var delivery = selected ? nativeCents(selected.getAttribute('data-ks-delivery-amount')) : null;
    var formatted = base !== null && delivery !== null && selected.getAttribute('data-ks-delivery-combinable') === '1'
      ? formatNativeTotal(base + delivery, summary) : null;
    var totalRow = summary.querySelector('[data-ks-summary-total-row]');
    if (totalRow) totalRow.hidden = formatted === null;
    setText(summary.querySelector('[data-ks-summary-total]'), formatted || '');
  }
  function decorate(form) {
    form.classList.add('ks-native-checkout');
    var fields = form.querySelector('.checkout__fields-list');
    if (fields) fields.classList.add('ks-checkout-contacts');
    var delivery = form.querySelector('input[name="shop_delivery_condition_id"]');
    if (delivery) {
      var deliveryBlock = delivery.closest('.checkout__options');
      if (deliveryBlock) deliveryBlock.classList.add('ks-checkout-delivery');
    }
    var payment = form.querySelector('.formpayment');
    if (payment) payment.classList.add('ks-checkout-payment');
    updateSummary(form);

  }
  function initialize(form) {
    if (initialized.has(form) || !isCheckout(form)) return;
    initialized.add(form);
    decorate(form);
    form.addEventListener('change', function (event) {
      if (event.target.matches('input[name="shop_delivery_condition_id"]')) updateSummary(form);
    });
    // Native .formpayment.load() may replace the payment markup after selecting delivery.
    // Observe appearance and the native summary only; never dispatch change/submit or start AJAX.
    var scheduled = false;
    new MutationObserver(function () {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(function () { scheduled = false; decorate(form); });
    }).observe(form, {childList: true, subtree: true});
    if (typeof ResizeObserver === 'function') {
      new ResizeObserver(function (entries) {
        entries.forEach(function (entry) { form.classList.toggle('ks-checkout-narrow', entry.contentRect.width < 760); });
      }).observe(form);
    }
  }
  function start() { document.querySelectorAll('form').forEach(initialize); }
  function watchCheckout() {
    start();
    // Native AJAX may add a checkout form after the document is already ready.
    var queued = false;
    new MutationObserver(function (changes) {
      var checkoutAdded = changes.some(function (change) {
        return Array.prototype.some.call(change.addedNodes, function (node) {
          return node.nodeType === 1 && (node.matches('form, .checkout__fields-list, .ks-order-summary, .formpayment') ||
            node.querySelector('form, .checkout__fields-list, .ks-order-summary, .formpayment'));
        });
      });
      if (!checkoutAdded || queued) return;
      queued = true;
      requestAnimationFrame(function () { queued = false; start(); });
    }).observe(document.body, {childList: true, subtree: true});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watchCheckout, {once: true});
  else watchCheckout();
}());
