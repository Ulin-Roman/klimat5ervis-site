<?php
if (!defined('HOSTCMS')) { http_response_code(404); exit; }
/** Add high-density choices to the three verified editorial cover pairs only. */
function klimat_blog_image_html_20261117($html)
{
    if (!is_string($html)) return $html;
    $known = array(
        '/assets/sitewide-20261116/trends-600.webp' => '/assets/sitewide-20261116/trends.webp',
        '/assets/sitewide-20261116/office-600.webp' => '/assets/sitewide-20261116/office.webp',
        '/assets/sitewide-20261116/delivery-600.webp' => '/assets/sitewide-20261116/delivery.webp'
    );
    $root = defined('CMS_FOLDER') ? rtrim(CMS_FOLDER, '/\\') : '';
    $available = array();
    foreach ($known as $small => $large) {
        if ($root !== '' && is_file($root . $small) && is_file($root . $large)) $available[$small] = $large;
    }
    if (!$available) return $html;
    $pattern = '~<!--[\s\S]*?-->|<(script|style|textarea|title)\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>'
        . '[\s\S]*?</\1\s*>|<img\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>~i';
    $result = preg_replace_callback($pattern, static function ($match) use ($available) {
        $tag = $match[0];
        if (!preg_match('~^<img\b~i', $tag)
            || preg_match('~\s(?:srcset|data-src|data-srcset)\s*=~i', $tag)
            || !preg_match('~\ssrc\s*=\s*([\x22\x27])([^\x22\x27]*)\1~i', $tag, $src)) return $tag;
        $url = html_entity_decode($src[2], ENT_QUOTES, 'UTF-8');
        $url = preg_replace('~^https://klimat5ervis\.ru(?=/)~i', '', $url);
        if (!isset($available[$url])) return $tag;
        $attributes = ' srcset="' . htmlspecialchars($url . ' 600w, ' . $available[$url] . ' 1200w', ENT_QUOTES, 'UTF-8') . '"';
        if (!preg_match('~\ssizes\s*=~i', $tag)) {
            $attributes .= ' sizes="(max-width:760px) calc(100vw - 32px), 400px"';
        }
        return preg_replace('~\s*/?>$~', $attributes . '>', $tag, 1);
    }, $html);
    return is_string($result) ? $result : $html;
}
