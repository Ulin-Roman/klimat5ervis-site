(function () {
  'use strict';
  var header = document.querySelector('.modern-shared-header');
  if (!header || header.classList.contains('header-ready')) return;
  var toggle = header.querySelector('.header-menu-toggle');
  var nav = header.querySelector('.header-nav');
  function close(focus) {
    header.classList.remove('is-menu-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Открыть меню');
    if (focus) toggle.focus();
  }
  toggle.addEventListener('click', function () {
    var open = header.classList.toggle('is-menu-open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    if (open) nav.querySelector('a').focus();
  });
  nav.addEventListener('click', function (event) {
    if (event.target.closest('a')) close(false);
  });
  document.addEventListener('click', function (event) {
    if (!header.contains(event.target)) close(false);
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && header.classList.contains('is-menu-open')) close(true);
  });
  header.addEventListener('focusout', function (event) {
    if (event.relatedTarget && !header.contains(event.relatedTarget)) close(false);
  });
  window.addEventListener('resize', function () {
    if (window.innerWidth > 1100) close(false);
  });
  header.classList.add('header-ready');
}());
