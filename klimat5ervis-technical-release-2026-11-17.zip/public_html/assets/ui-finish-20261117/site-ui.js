(function () {
  'use strict';
  function init() {
    function messengerIcons() {
      var providers = {
        't.me': ['Telegram','/assets/header-20261116/telegram.svg'],
        'telegram.me': ['Telegram','/assets/header-20261116/telegram.svg'],
        'wa.me': ['WhatsApp','/assets/ui-finish-20261117/whatsapp.svg'],
        'api.whatsapp.com': ['WhatsApp','/assets/ui-finish-20261117/whatsapp.svg'],
        'max.ru': ['MAX','/assets/footer-20261116/max.webp']
      };
      document.querySelectorAll('a[href]').forEach(function (link) {
        if (link.querySelector('img,svg') || link.classList.contains('ks-messenger-link')) return;
        var url;
        try { url = new URL(link.href); } catch (ignore) { return; }
        var provider = providers[url.hostname];
        if (!provider) return;
        var text = link.textContent.trim();
        var paragraph = link.closest('p');
        if (paragraph && paragraph.textContent.trim() === text && paragraph.querySelectorAll('a').length === 1) {
          paragraph.classList.add('ks-messenger-paragraph');
        }
        var icon = document.createElement('img');
        icon.src = provider[1]; icon.width = 40; icon.height = 40; icon.alt = '';
        link.textContent = ''; link.appendChild(icon);
        link.classList.add('ks-messenger-link');
        link.setAttribute('aria-label','Написать в ' + provider[0]);
        link.title = provider[0];
      });
    }
    messengerIcons();
    // A contact row is horizontal only when its entire remaining content is
    // messenger links; phone, email, address and labelled rows remain intact.
    var messengerRows = Array.prototype.filter.call(document.querySelectorAll('.contacts__item'), function (item) {
      if (!item.querySelector('a.ks-messenger-link')) return false;
      var remainder = item.cloneNode(true);
      remainder.querySelectorAll('a.ks-messenger-link').forEach(function (link) { link.remove(); });
      return remainder.textContent.trim() === '' &&
        !remainder.querySelector('a,button,input,select,textarea,iframe,video,audio,img,svg,script,style');
    });
    messengerRows.forEach(function (item) { item.classList.add('ks-contact-messengers'); });
    // Consecutive messenger-only list items form one row, retaining link nodes
    // and their href/aria attributes. Mixed contact rows are never combined.
    messengerRows.forEach(function (item) {
      if (!item.parentNode) return;
      var next = item.nextElementSibling;
      while (next && next.classList.contains('ks-contact-messengers')) {
        var following = next.nextElementSibling;
        next.querySelectorAll('a.ks-messenger-link').forEach(function (link) { item.appendChild(link); });
        next.remove();
        next = following;
      }
    });
    if (document.getElementById('ks-back-to-top')) return;
    var button = document.createElement('button');
    button.id = 'ks-back-to-top';
    button.type = 'button';
    button.hidden = true;
    button.setAttribute('aria-label', 'Наверх страницы');
    button.title = 'Наверх';
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 14 6-6 6 6M12 8v12"/></svg>';
    document.body.appendChild(button);
    var notice = document.getElementById('ks-cookie-notice');
    var scheduled = false;
    function update() {
      scheduled = false;
      button.hidden = window.scrollY < 500;
      var offset = notice && !notice.hidden ? notice.getBoundingClientRect().height + 12 : 0;
      button.style.setProperty('--ks-top-offset', Math.max(0, offset) + 'px');
    }
    function schedule() {
      if (!scheduled) { scheduled = true; window.requestAnimationFrame(update); }
    }
    button.addEventListener('click', function () {
      var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      window.scrollTo({top:0,behavior:reduced ? 'auto' : 'smooth'});
      var home = document.querySelector('header a');
      if (home) home.focus({preventScroll:true});
    });
    window.addEventListener('scroll', schedule, {passive:true});
    window.addEventListener('resize', schedule);
    if (notice) new MutationObserver(schedule).observe(notice, {attributes:true,attributeFilter:['hidden','class']});
    update();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
}());
