<?php
/** Pure final-HTML metadata correction, compatible with PHP 7.4. No CMS reads or writes. */
if (!defined('HOSTCMS')) { http_response_code(404); exit; }

function technical_seo_20261117_tokens()
{
    // Comments and raw-text nodes are opaque. Title and H1 are whole tokens; only title in head can change.
    return '~<!--[\s\S]*?-->|<(script|style|textarea|title|h1)\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>'
        . '[\s\S]*?</\1\s*>|<(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>~i';
}

function technical_seo_20261117_attr($tag, $name)
{
    $pattern = '~\s' . preg_quote($name, '~') . '\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\s>]+))~i';
    if (!preg_match($pattern, $tag, $match)) return NULL;
    $raw = isset($match[3]) ? $match[3] : (isset($match[2]) ? $match[2] : $match[1]);
    return html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function technical_seo_20261117_set_attr($tag, $name, $value)
{
    $pattern = '~(\s)' . preg_quote($name, '~') . '\s*=\s*(?:"[^"]*"|\x27[^\x27]*\x27|[^\s>]+)~i';
    $escaped = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    return preg_replace_callback($pattern, static function ($match) use ($name, $escaped) {
        return $match[1] . $name . '="' . $escaped . '"';
    }, $tag, 1);
}

function technical_seo_20261117_clean_canonical($url)
{
    // Remove only the two exact parameter names; keep brand paths, remaining
    // parameters, their order/encoding and any fragment byte for byte.
    $hash = strpos($url, '#');
    $fragment = $hash === FALSE ? '' : substr($url, $hash);
    $withoutFragment = $hash === FALSE ? $url : substr($url, 0, $hash);
    $question = strpos($withoutFragment, '?');
    if ($question === FALSE) return $url;
    $base = substr($withoutFragment, 0, $question);
    $query = substr($withoutFragment, $question + 1);
    $remaining = array();
    $changed = FALSE;
    foreach (explode('&', $query) as $part) {
        $equals = strpos($part, '=');
        $name = urldecode($equals === FALSE ? $part : substr($part, 0, $equals));
        if ($name === '_openstat' || $name === 'ks_front_preview') { $changed = TRUE; continue; }
        $remaining[] = $part;
    }
    if (!$changed) return $url;
    $query = implode('&', $remaining);
    return $base . ($query === '' ? '' : '?' . $query) . $fragment;
}


function technical_seo_20261117_page_suffix($text)
{
    // Unicode letter boundary: PCRE \b without UCP is not reliable for Cyrillic.
    return preg_match('/(?<![\p{L}\p{N}_])Страница[\s\x{00A0}\x{202F}]+[0-9]+(?![0-9])/ui', $text) === 1;
}

function technical_seo_20261117_not_found($text)
{
    return preg_match('/^[\s\x{00A0}\x{202F}]*Запрашиваемый[\s\x{00A0}\x{202F}]+документ[\s\x{00A0}\x{202F}]+не[\s\x{00A0}\x{202F}]+найден[.!?]?[\s\x{00A0}\x{202F}]*$/ui', $text) === 1;
}


function technical_seo_20261117_bare_context($text, $heading)
{
    $text = preg_replace('/[\s\x{00A0}\x{202F}]+/u', ' ', $text);
    $heading = preg_replace('/[\s\x{00A0}\x{202F}]+/u', ' ', $heading);
    if (!is_string($text) || !is_string($heading) || trim($text) === '') return FALSE;
    $text = trim($text); $heading = trim($heading);
    // Match the complete H1 or its complete final words, never a Cyrillic substring.
    return preg_match('/(?<![\p{L}\p{N}_])' . preg_quote($text, '/') . '$/ui', $heading) === 1;
}

function technical_seo_20261117_context_description($heading)
{
    return $heading . ': модели, цены и характеристики в интернет-магазине «Климат-Сервис». Доставка и установка в Москве и Московской области.';
}

function technical_seo_20261117_filter_robots($content)
{
    $tokens = preg_split('/[\s,]+/', strtolower(trim($content)), -1, PREG_SPLIT_NO_EMPTY);
    if (in_array('none', $tokens, TRUE)
        || (in_array('noindex', $tokens, TRUE) && in_array('nofollow', $tokens, TRUE))) return $content;
    if (in_array('noindex', $tokens, TRUE) && !in_array('index', $tokens, TRUE)
        && !in_array('all', $tokens, TRUE)) return $content;
    $out = array('noindex', in_array('nofollow', $tokens, TRUE) ? 'nofollow' : 'follow');
    foreach ($tokens as $token) {
        if (!in_array($token, array('index','all','noindex','follow','nofollow'), TRUE)) $out[] = $token;
    }
    return implode(',', array_unique($out));
}

/**
 * $path accepts a pathname or the current request URI. With a pathname the
 * query is read from REQUEST_URI only if its pathname matches. Does not alter
 * response headers; a caller may keep the existing preview X-Robots-Tag policy.
 */
function technical_seo_finish($html, $path)
{
    if (!is_string($html) || strlen($html) > 6000000 || !is_string($path)) return $html;
    $pathname = parse_url($path, PHP_URL_PATH);
    if (!is_string($pathname) || $pathname === '' || $pathname[0] !== '/') return $html;
    $requestUri = strpos($path, '?') !== FALSE ? $path
        : (isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $path);
    $query = array();
    if (parse_url($requestUri, PHP_URL_PATH) === $pathname) {
        parse_str((string) parse_url($requestUri, PHP_URL_QUERY), $query);
    }
    $preview = isset($query['ks_front_preview']) && $query['ks_front_preview'] === '1';
    $page = 0;
    // Match the existing catalog renderer's supported page range; do not
    // decorate product pages or unrelated native pages based on URL alone.
    if (strpos($pathname, '/category/') === 0 && isset($query['page']) && is_string($query['page'])
        && preg_match('/^[1-9][0-9]{0,3}$/D', $query['page'])
        && (int) $query['page'] >= 2 && (int) $query['page'] <= 1000) {
        $page = (int) $query['page'];
    }

    $pattern = technical_seo_20261117_tokens();
    $hasListing = FALSE;
    $hasProducts = FALSE;
    $hasNativeList = FALSE;
    $hasNativeProducts = FALSE;
    $hasProductPage = FALSE;
    $listingHeading = '';
    if (strpos($pathname, '/category/') === 0 && preg_match_all($pattern, $html, $tokens)) {
        foreach ($tokens[0] as $token) {
            if (strpos($token, '<!--') === 0 || preg_match('~^<(?:script|style|textarea|title)\b~i', $token)) continue;
            $id = technical_seo_20261117_attr($token, 'id');
            if ($id === 'catalog-filters') $hasListing = TRUE;
            if ($id === 'tabs-1' || $id === 'tabs1') $hasProductPage = TRUE;
            $tokenClass = technical_seo_20261117_attr($token, 'class');
            $classes = $tokenClass === NULL ? array() : preg_split('/\s+/', trim($tokenClass));
            if (in_array('product-card', $classes, TRUE)) $hasProductPage = TRUE;
            if (in_array('product-catalog', $classes, TRUE)) $hasNativeList = TRUE;
            if (in_array('product-catalog__item', $classes, TRUE)) $hasNativeProducts = TRUE;
            if (preg_match('~^<article\b~i', $token)) {
                $class = technical_seo_20261117_attr($token, 'class');
                if ($class !== NULL && in_array('product', preg_split('/\s+/', trim($class)), TRUE)) $hasProducts = TRUE;
            }
            if ($listingHeading === '' && preg_match('~^<h1\b[^>]*>([\s\S]*?)</h1\s*>$~i', $token, $heading)) {
                $plain = html_entity_decode(strip_tags($heading[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $plain = preg_replace('/[\s\x{00A0}\x{202F}]+/u', ' ', $plain);
                if (is_string($plain) && trim($plain) !== '' && strlen($plain) <= 1000) $listingHeading = trim($plain);
            }
        }
    }
    if (!$hasListing) $page = 0;
    // A known inherited 404 metadata string is repaired only for a nonempty
    // modern catalog. Empty/unknown routes and real HTTP error responses stay errors.
    $status = http_response_code();
    if (is_int($status) && $status >= 400) $page = 0;
    $repairCatalog = $hasListing && $hasProducts && $listingHeading !== ''
        && !technical_seo_20261117_not_found($listingHeading)
        && (!is_int($status) || $status < 400);

    $relative = strpos($pathname, '/category/') === 0 ? substr($pathname, strlen('/category/')) : '';
    $first = strtolower(explode('/', $relative)[0]);
    $publicCatalogPath = strpos($pathname, '/category/') === 0
        && !in_array($first, array('cart','favorite','compare','payment','checkout','callback','info'), TRUE);
    $validStatus = !is_int($status) || $status < 400;
    $nativeListing = $publicCatalogPath && $hasNativeProducts && !$hasProductPage && $validStatus
        && $listingHeading !== '' && !technical_seo_20261117_not_found($listingHeading);
    $legacyFiltered = FALSE;
    if ($publicCatalogPath && !$hasProductPage && $validStatus && ($hasListing || $hasNativeList || $hasNativeProducts)) {
        foreach (array('shop_form','sorting','filter','price_from','price_to','producer_id') as $filterKey) {
            if (array_key_exists($filterKey, $query)) { $legacyFiltered = TRUE; break; }
        }
    }

    $inHead = FALSE;
    $headStarts = 0;
    $headEnds = 0;
    $robotsWritten = FALSE;
    $descriptionWritten = FALSE;
    $out = preg_replace_callback($pattern, static function ($match) use (&$inHead, &$headStarts, &$headEnds, &$robotsWritten, &$descriptionWritten, $preview, $page, $repairCatalog, $listingHeading, $nativeListing, $legacyFiltered) {
        $tag = $match[0];
        if (strpos($tag, '<!--') === 0 || preg_match('~^<(?:script|style|textarea)\b~i', $tag)) return $tag;
        if (preg_match('~^<head(?:\s|>)~i', $tag)) { $inHead = TRUE; $headStarts++; return $tag; }
        if (preg_match('~^</head\s*>~i', $tag)) {
            $headEnds++; $inHead = FALSE;
            $extraHead = '';
            if ($preview && !$robotsWritten) {
                $robotsWritten = TRUE;
                $extraHead .= '<meta name="robots" content="noindex,nofollow,noarchive">';
            } elseif ($legacyFiltered && !$robotsWritten) {
                $robotsWritten = TRUE;
                $extraHead .= '<meta name="robots" content="noindex,follow">';
            }
            if ($nativeListing && !$descriptionWritten) {
                $extraHead .= '<meta name="description" content="' . htmlspecialchars(technical_seo_20261117_context_description($listingHeading), ENT_QUOTES, 'UTF-8') . '">';
            }
            return $extraHead . $tag;
        }
        if (!$inHead) return $tag;
        if (preg_match('~^<link\b~i', $tag)) {
            $rel = technical_seo_20261117_attr($tag, 'rel');
            $href = technical_seo_20261117_attr($tag, 'href');
            if ($rel !== NULL && $href !== NULL && in_array('canonical', preg_split('/\s+/', strtolower(trim($rel))), TRUE)) {
                $clean = technical_seo_20261117_clean_canonical($href);
                if ($clean !== $href) return technical_seo_20261117_set_attr($tag, 'href', $clean);
            }
            return $tag;
        }
        if (preg_match('~^<meta\b~i', $tag)) {
            $name = technical_seo_20261117_attr($tag, 'name');
            if ($preview && $name !== NULL && strtolower($name) === 'robots') {
                if ($robotsWritten) return '';
                $robotsWritten = TRUE;
                return '<meta name="robots" content="noindex,nofollow,noarchive">';
            }
            if ($legacyFiltered && $name !== NULL && strtolower($name) === 'robots') {
                $robotsWritten = TRUE;
                $content = technical_seo_20261117_attr($tag, 'content');
                $content = $content === NULL ? '' : $content;
                $restricted = technical_seo_20261117_filter_robots($content);
                return $restricted === $content ? $tag : '<meta name="robots" content="' . htmlspecialchars($restricted, ENT_QUOTES, 'UTF-8') . '">';
            }
            if ($name !== NULL && strtolower($name) === 'description') $descriptionWritten = TRUE;
            if (($page || $repairCatalog || $nativeListing) && $name !== NULL && strtolower($name) === 'description') {
                $description = technical_seo_20261117_attr($tag, 'content');
                $changed = FALSE;
                if ($nativeListing && ($description === NULL || preg_match('/^[\s\x{00A0}\x{202F}]*$/u', $description)
                    || technical_seo_20261117_bare_context($description, $listingHeading))) {
                    $description = technical_seo_20261117_context_description($listingHeading);
                    if (technical_seo_20261117_attr($tag, 'content') === NULL) return '<meta name="description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">';
                    $changed = TRUE;
                }
                if ($repairCatalog && $description !== NULL && technical_seo_20261117_not_found($description)) {
                    $description = $listingHeading . ': модели, цены и характеристики в интернет-магазине «Климат-Сервис». Доставка и установка в Москве и Московской области.';
                    $changed = TRUE;
                }
                if ($page && $description !== NULL && trim($description) !== '' && !technical_seo_20261117_page_suffix($description)) {
                    $description = rtrim($description);
                    $description .= (preg_match('/[.!?…]$/u', $description) ? ' ' : '. ') . 'Страница ' . $page . '.';
                    $changed = TRUE;
                }
                if ($changed) return technical_seo_20261117_set_attr($tag, 'content', $description);
            }
            return $tag;
        }
        if (($page || $repairCatalog || $nativeListing) && preg_match('~^(<title\b[^>]*>)([\s\S]*?)(</title\s*>)$~i', $tag, $title)) {
            $plain = html_entity_decode(strip_tags($title[2]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $body = $title[2];
            if ($nativeListing && technical_seo_20261117_bare_context($plain, $listingHeading)) {
                $plain = $listingHeading . ' — Климат-Сервис';
                $body = htmlspecialchars($plain, ENT_QUOTES, 'UTF-8');
            }
            if ($repairCatalog && technical_seo_20261117_not_found($plain)) {
                $plain = $listingHeading . ' — Климат-Сервис';
                $body = htmlspecialchars($plain, ENT_QUOTES, 'UTF-8');
            }
            if ($page && trim($plain) !== '' && !technical_seo_20261117_page_suffix($plain)) $body = rtrim($body) . ' — Страница ' . $page;
            return $title[1] . $body . $title[3];
        }
        return $tag;
    }, $html);
    return is_string($out) && $headStarts === 1 && $headEnds === 1 ? $out : $html;
}
