(function () {
  'use strict';
  var header = document.querySelector('.modern-shared-header');
  if (!header || header.classList.contains('header-ready')) return;
  function labelTools() {
    [['.ks-shell-cart-slot','Корзина'],['.ks-shell-favorite-slot','Избранное']].forEach(function (entry) {
      var slot=header.querySelector(entry[0]);
      if (!slot) return;
      slot.querySelectorAll('a').forEach(function (link) { link.setAttribute('aria-label',entry[1]); link.title=entry[1]; });
    });
  }
  labelTools();
  header.querySelectorAll('.ks-shell-cart-slot,.ks-shell-favorite-slot').forEach(function (slot) { new MutationObserver(labelTools).observe(slot,{childList:true,subtree:true}); });
  var toggle = header.querySelector('.header-menu-toggle');
  var nav = header.querySelector('.header-nav');
  function close(focus) {
    header.classList.remove('is-menu-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Открыть меню');
    if (focus) toggle.focus();
  }
  toggle.addEventListener('click', function () {
    var open = header.classList.toggle('is-menu-open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    if (open) nav.querySelector('a').focus();
  });
  nav.addEventListener('click', function (event) {
    if (event.target.closest('a')) close(false);
  });
  document.addEventListener('click', function (event) {
    if (!header.contains(event.target)) close(false);
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && header.classList.contains('is-menu-open')) close(true);
  });
  header.addEventListener('focusout', function (event) {
    if (event.relatedTarget && !header.contains(event.relatedTarget)) close(false);
  });
  window.addEventListener('resize', function () {
    if (window.innerWidth > 1100) close(false);
  });
  header.classList.add('header-ready');
}());
