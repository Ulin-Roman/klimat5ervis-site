(function(jQuery){
	// Функции без создания коллекции
	jQuery.extend({

		addIntoCartComplex: function(path, objForm){
			// проверяем карточку
			if ( $('.product-card').length) {

				if ($('.complex__item').length || $('.product-card__price_complect').length) {
					$.clientRequest({path: path + '?' + objForm.serialize(), 'callBack': $.addIntoCartCallback, context: $('#little_cart')});
					if (!$('body').hasClass('fancybox-active')) { $.fancybox.open( { src  : '/category/info/addcartinfo/', type : 'ajax' } );	 }	
					return false;
				} else {
					// This method is called without an event argument. Always return
					// false to the inline purchase handler and show a local message.
					$.fancybox.open({
						src: '<div class="ks-complect-message" role="alert"><h2>Выберите комплектацию</h2><p>Добавьте хотя бы один компонент комплекта перед добавлением в корзину.</p></div>',
						type: 'html'
					});
					return false;
				}
			// остальные страницы
			} else {
				$.clientRequest({path: path + '?' + objForm.find('input').serialize(), 'callBack': $.addIntoCartCallback, context: $('#little_cart')});
				if (!$('body').hasClass('fancybox-active')) { $.fancybox.open( { src  : '/category/info/addcartinfo/', type : 'ajax' } );	 }	
				return false;
			}
		},
	});
})(jQuery);

$(document).on("click", "#complex_form .nice-number button", function() {
	$(this).siblings('input.product-card__quantity').trigger('change');
});

$(document).on("click", ".product-card__buttons .nice-number button", function() {
	$(this).siblings('input.product-card__quantity').trigger('change');
});

$(document).on("click", ".product-item__add-to-cart .nice-number button", function() { 
	$(this).siblings('input.product-item__quantity').trigger('change');  
});

(function() {
	// еcли составной продукт
	if($('.product-card__price').length && $('.complex__item').length) {

		if($('.product-card__price_complect').length) {

			// для комплексных товаров с размерами
			var mainPrice = $('.product-card__price_complect').find('strong');
			$('.complex__item').each(function(index, el) {
				var priceForOne = parseInt($(this).find('.complex_price .price').data('price')),
					totalPrice = parseInt($(this).find('.complex_price .price').data('price')) * $(this).find('input.product-card__quantity').val();
				$(this).data('itemprice', priceForOne);
				$(this).find('.complex_price').find('.price strong').text(totalPrice.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
			});
			_countSizeSumm();

			// обработчик на изменение составляющих заказа
			$('#complex_form .product-card__quantity').on('change', function() {
				var count = $(this).val(),
					itemPrice = $(this).closest('.complex__item').find('.price').find('strong'),
					currentPrice = $(this).closest('.complex__item').data('itemprice');
				itemPrice.text((currentPrice * count).toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
				_countSizeSumm();
	        });

			// обработчик на изменение размера
			$('.product-card__groups li label').on('click', function() {
				$('.complex__item').each(function(index, el) {
					var priceForOne = parseInt($(this).find('.complex_price .price').data('price')),
						totalPrice = parseInt($(this).find('.complex_price .price').data('price')) * $(this).find('input.product-card__quantity').val();
					$(this).data('itemprice', priceForOne);
					$(this).find('.complex_price').find('.price strong').text(totalPrice.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
				});
				var items = $('#complex_form').find('.complex_price').find('.price strong'),
					summ = 0;
				items.each(function(index, el) {
					var i = parseInt($(el).text().replace(/\s/g, ""));
					summ += i;
				});
				summ += parseInt(String($(this).closest('li').data('price')).replace(/\s/g, ""));
				mainPrice.text(summ.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
				$('.product-card__price del').text('');

	        });

			// обработчик на удаление составляющих заказа
			$('.complex__item__remove').on('click', function(event) {
				event.preventDefault();
				$(this).closest('.complex__item').remove();
				_countSizeSumm();
	        });

		} else {

			var mainPrice = $('.product-card__price').find('strong');
			$('.complex__item').each(function(index, el) {
				var priceForOne = parseInt($(this).find('.complex_price .price').data('price')),
					totalPrice = parseInt($(this).find('.complex_price .price').data('price')) * $(this).find('input.product-card__quantity').val();
				$(this).data('itemprice', priceForOne);
				$(this).find('.complex_price').find('.price strong').text(totalPrice.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
			});
			_countSumm();

			// обработчик на изменение составляющих заказа
			$('#complex_form .product-card__quantity').on('change', function() {
				var count = $(this).val(),
					itemPrice = $(this).closest('.complex__item').find('.price').find('strong'),
					currentPrice = $(this).closest('.complex__item').data('itemprice');
				
				itemPrice.text((currentPrice * count).toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
				_countSumm();
	        });

			// обработчик на изменение количества комплектов заказа
			$('.product-card__buttons .product-card__quantity').on('change', function() {
				_itemRecount.call(this);
	            _countSumm();
	        });

			// обработчик на удаление составляющих заказа
			$('.complex__item__remove').on('click', function(event) {
				event.preventDefault();
				$(this).closest('.complex__item').remove();
				_countSumm();
	        });
        }
	} 


	function _itemRecount () {
		var allqnt = $(this).val();

		$('.complex__item').each(function(index, el) {
			var count = parseInt($(el).find('.product-card__quantity').data('defoultcount'))*allqnt,
				itemPrice = $(el).find('.price').find('strong'),
				currentPrice = $(el).data('itemprice');
			$(el).find('.product-card__quantity').val(count);
			itemPrice.text((currentPrice * count).toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
		});
	}

	function _countSumm () {
		var items = $('#complex_form').find('.complex_price').find('.price strong'),
			summ = 0;
		items.each(function(index, el) {
			var i = parseInt($(el).text().replace(/\s/g, ""));
			summ += i;
		});
		mainPrice.text(summ.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
		$('.product-card__price del').text('');
	}


	function _countSizeSumm () {
		var items = $('#complex_form').find('.complex_price').find('.price strong'),
			summ = 0;
		items.each(function(index, el) {
			var i = parseInt($(el).text().replace(/\s/g, ""));
			summ += i;
		});
		summ += parseInt($('.product-card__price').find('strong').text().replace(/\s/g, ""));
		mainPrice.text(summ.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
		$('.product-card__price del').text('');
	}
})();

///////////////////// каталог товаров

(function() {
	$('.product-catalog div.formdiv input[type="number"]').each(function(index, el) {
		var defqnt = parseInt($(el).val());
		$(el).data('defqnt', defqnt);
	});

	// обработчик на изменение количества комплектов
	$('.product-item__add-to-cart .product-item__quantity').on('change', function() {   
		if($(this).closest('.product-catalog__item').find('div.formdiv').length) { 

			$(this).closest('.product-catalog__item').find('div.formdiv input[type="number"]').each(function(index, el) {  

				var itemqnt = parseInt($(el).data('defqnt')*$(el).closest('.product-catalog__item').find('.product-item__quantity').val());
				$(el).val(itemqnt);
			});
		}
    });
})();