
// Быстрый заказ (модальное окно)
function fastorder(item,count) {
$.fancybox.open({
	src  : '/category/cart/?fastorder=1&fastorderitem=' + item + '&fastordercount=' + count,
	type : 'ajax'
});
}

$(document).ready(function() {

// Выбор способа доставки и оплаты в корзине
$('body').on('click', '.shop_delivery', function(){ 
$.loadingScreen('show');
$('.formpayment').load('/category/cart/', { shop_delivery_condition_id: $('input[name="shop_delivery_condition_id"]:checked').val(), step: '3' });
});

// Отправка формы быстрого заказа
$('body').on('click', '#fastorder_form #fastorder_form_button', function(){ 
$.loadingScreen('show');
$('.fastorder_form_result').load('/category/cart/', { fastorder: '1', fo_name: document.getElementById('fo_name').value,fo_phone: document.getElementById('fo_phone').value,fo_item: document.getElementById('fo_item').value,fo_count: document.getElementById('fo_count').value});
});

// Отправка формы обратного звонка
$('body').on('click', '#callbackform #callbackform_button', function(){ 
$.loadingScreen('show');
$('.callbackform_result').load('/kontakty/callback/', { name_callback: document.getElementById('name_callback').value, phone_callback: document.getElementById('phone_callback').value, Submit: document.getElementById('callbackform_button_value').value});
});

// Отправка формы авторизации
$('body').on('click', '#userautform #userautform_button', function(){ 
$.loadingScreen('show');
$('.userautform_result').load('/users/', { AjaxАuthorization: '1', location: '/users/', login: document.getElementById('login').value, password: document.getElementById('password').value, remember: document.getElementById('remember').value,  apply: document.getElementById('userautform_button_value').value});
});

 

///////////////////////////////////////////////////////////////////////////////
// Ajax пересчет товаров в корзине при изменении кол-ва 
///////////////////////////////////////////////////////////////////////////////
 	
		var timeOut;
		function cooldowner(arg){
	clearTimeout(timeOut);
			timeOut = setTimeout(function(){arg.change()}, 5);
			return(timeOut);
		}
		$('body').on('click', '.increase_quantity', function(){
			 var parPath = $(this).parents('.quant_bar').find(".quantity_input");
			increaseQuantity = parseInt($(parPath).val());
			if(!increaseQuantity){increaseQuantity = 0;}
			$(parPath).val(increaseQuantity + 1);
			cooldowner($(parPath));
			return false;
		});		
		$('body').on('click', '.decrease_quantity', function(){
			 var parPath = $(this).parents('.quant_bar').find(".quantity_input");
			decreaseQuantity = parseInt($(parPath).val());
			if (decreaseQuantity > 0){
				$(parPath).val(decreaseQuantity - 1);
				cooldowner($(parPath));
			}
			return false;
		});
	
		$('body').on('click', '.remove', function(){
			$(this).parents('tr').find(".quantity_input").val(0).change();
			return false
		});

		// AJAX пересчет
		var cart_path = "/category/cart/";

		$('body').on('change', "#cart [name^='quantity'], [name='coupon_text']", function(){
			$.loadingScreen('show');
			var formData = $("form[name='order']").serialize();
			$("#cart").load(
					cart_path,
					formData + "&ajaxget=cart"
					,
					function(){
						$.loadingScreen('hide');
					}
				);
		});	
		
		
	});



/////////////////////////////////////////////////////////////////////////
// Выбор цвета и размера товара на странице товара
/////////////////////////////////////////////////////////////////////////


// Загрузка размеров при клике на цвет

function changeitem(itemurl,itemimage) { 
$.loadingScreen('show');
// Загружаем размеры
$('.containeritem').load(itemurl, { AjaxProperties: '1' });
} 


$(document).ready(function(){

// Выделяем первый цвет на всех товарах
if ( $('.prod_color_act').length = 0) {
$('.button_color:first').addClass('prod_color_act');
}
// Выделяем первый размер
$('.prod_size:first input.group__field').attr("checked", "checked");

// Меняем цену (берем цену цвета) 
if ( $('.button_color').length > 0 ) {
$('.product-card__price').html('<ins><strong>' + $('.button_color:first').attr('data-price') + '</strong> руб.</ins><del>' + $('.button_color:first').attr('data-price-discount') + '</del>');
}

// Если изменили цвет
$('.prod_color').click(function(){
$('.prod_color').removeClass('prod_color_act');
$(this).addClass('prod_color_act');
// Меняем цену (берем цену цвета)
$('.product-card__price').html('<ins><strong>' + $(this).attr('data-price') + '</strong> руб.</ins><del>' + $(this).attr('data-price-discount') + '</del>');
});

// Если у первого отмеченного цвета есть картинка - делаем замену для главной картинки
if ( $('.prod_color_act').find('img').attr('data-img') ) {
let previd = '#oop' + $('.prod_color_act').find('img').attr('data-id');
var listItem = $('div.gallery div.gallery__item img'+previd);
// Выделяем нужную превью в каруселе
$('.gallery-side').slick('slickGoTo',  $('div.gallery div.gallery__item img').index(listItem));
}


///////////////////////////////////
// Если у товара есть размеры
//////////////////////////////////

if ( $('.prod_size').length > 0 ) {

// выставляем id первого в скрытое поле input и выделяем рамкой
$('.cartitemid').val( $('.prod_size:first>.input_id').val() );
$('.prod_size:first').addClass('prod_size_act');

// Меняем цену (берем цену размера если есть)
$('.product-card__price').html('<ins><strong>' + $('.prod_size:first').attr('data-price') + '</strong> руб.</ins><del>' + $('.prod_size:first').attr('data-price-discount') + '</del>');


// если изменили размер
$('.prod_size').click(function(){

// выставляем id выбранного размера в скрытое поле input и выделяем рамкой
$('.prod_size').removeClass('prod_size_act');
$('.cartitemid').val(  $(this).find('.input_id').val() );
$(this).addClass('prod_size_act');

// Меняем цену (берем цену размера если есть)
$('.product-card__price').html('<ins><strong>' + $(this).attr('data-price') + '</strong> руб.</ins><del>' + $(this).attr('data-price-discount') + '</del>');

});

} else if ( $('.prod_color').length > 0 ) {  
// если размеры не указаны
// Устанавливаем в input id товара  с цветом по умолчанию
$('.cartitemid').val( $('.prod_color_act').find('.input_id').val());
}
});